--*****************************************************************************
--* File: lua/modules/ui/game/avatars.lua
--* Author: Ted Snook
--* Summary: In Game Avatar Icons
--*
--* Copyright © 2005 Gas Powered Games, Inc.  All rights reserved.
--*****************************************************************************

local UIUtil = import('/lua/ui/uiutil.lua')
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')
local Bitmap = import('/lua/maui/bitmap.lua').Bitmap
local Button = import('/lua/maui/button.lua').Button
local Group = import('/lua/maui/group.lua').Group
local Checkbox = import('/lua/maui/checkbox.lua').Checkbox
local StatusBar = import('/lua/maui/statusbar.lua').StatusBar
local GameCommon = import('/lua/ui/game/gamecommon.lua')
local GameMain = import('/lua/ui/game/gamemain.lua')
local ToolTip = import('/lua/ui/game/tooltip.lua')
local TooltipInfo = import('/lua/ui/help/tooltips.lua').Tooltips
local Prefs = import('/lua/user/prefs.lua')
local Factions = import('/lua/factions.lua').Factions
local options = Prefs.GetFromCurrentProfile('options')
local DiskGetFileInfo = UIUtil.DiskGetFileInfo

local modPath = '/mods/SupremeScoreBoard/'
local modTextures = modPath..'textures/'
local modScripts  = modPath..'modules/'
local log  = import(modScripts..'ext.logging.lua')
local thisLua = debug.getinfo(1).source

--controls = {
--    avatars = {},
--    idleEngineers = false,
--    idleFactories = false,
--}
 
-- show/hide old score board
local orgShowUI = true
local orgCreateAvatarUI = CreateAvatarUI
function CreateAvatarUI(parent)
    log.Trace('avatars.ORG CreateAvatarUI... ')
    orgCreateAvatarUI(parent)
    if not orgShowUI then HideUI() end

    --controls.parent = parent
	--
    --controls.avatarGroup = Group(controls.parent)
    --controls.avatarGroup.Depth:Set(100)
	--
    --controls.bgTop = Bitmap(controls.avatarGroup)
    --controls.bgBottom = Bitmap(controls.avatarGroup)
    --controls.bgStretch = Bitmap(controls.avatarGroup)
    --controls.collapseArrow = Checkbox(controls.parent)
    --controls.collapseArrow.OnCheck = function(self, checked)
    --    ToggleAvatars(checked)
    --end
    --ToolTip.AddCheckboxTooltip(controls.collapseArrow, 'avatars_collapse')
	--
    --controls.avatarGroup:DisableHitTest()
    --controls.bgTop:DisableHitTest()
    --controls.bgBottom:DisableHitTest()
    --controls.bgStretch:DisableHitTest()
	--
    --log.Trace('avatars.lua CreateAvatarUI... SetLayout')
    --SetLayout()
	--
    --if GetFocusArmy() ~= -1 then
    --    recievingBeatUpdate = true
    --    GameMain.AddBeatFunction(AvatarUpdate, true)
    --end
end

local orgToggleAvatars = ToggleAvatars
function ToggleAvatars(checked)
    log.Trace('avatars.lua ToggleAvatars... ')
    if orgShowUI then orgToggleAvatars() end 
end

--function SetLayout()
--    import(UIUtil.GetLayoutFilename('avatars')).SetLayout()
--end

local orgAvatarUpdate = AvatarUpdate
function AvatarUpdate()
    if orgShowUI then orgAvatarUpdate() end 
end
  
local orgContract = Contract
function Contract()
    log.Trace('avatars.lua Contract...  ') 
    if orgShowUI then orgContract() else HideUI() end 
end

local orgExpand = Expand
function Expand()
    if orgShowUI then orgExpand() else HideUI() end 
end

local orgInitialAnimation = InitialAnimation
function InitialAnimation()
    log.Trace('avatars.lua InitialAnimation...  ') 
    if orgShowUI then orgInitialAnimation() else HideUI() end
end

-- hides UI elements of the original avatars board
function HideUI()
    if controls and controls.bg then 
        --controls.bg.Right:Set(500)
        --controls.bg.Right:Set(-100)
        controls.bgTop:Hide()
        controls.bgBottom:Hide()
        controls.bgStretch:Hide()
        controls.collapseArrow:Hide() 
    end
end