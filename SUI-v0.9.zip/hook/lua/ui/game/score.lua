local modPath = '/mods/SupremeScoreBoard/'
local modTextures = modPath..'textures/'
local modScripts  = modPath..'modules/'
local log  = import(modScripts..'ext.logging.lua')
--currentScores = false  

-- show/hide old score board
local orgShowUI = false

local GameMain      = import('/lua/ui/game/gamemain.lua')

local orgCreateScoreUI = CreateScoreUI
function CreateScoreUI(parent) 
    log.Trace('score.ORG CreateScoreUI... ')
    orgCreateScoreUI(parent)
    if not orgShowUI then HideUI() end
end

local firstBeat = true

local orgOnBeat = _OnBeat
function _OnBeat() 
    --if firstBeat then
        --firstBeat = false
        log.Trace('score.ORG _OnBeat '  )
        GameMain.RemoveBeatFunction(_OnBeat)
    --end      
  --import(modPath .. 'modules/mciscore.lua').UpdateScoreData(newData)
end

local orgToggleScoreControl = ToggleScoreControl
function ToggleScoreControl(state)
    --LOG('SCORE ToggleScoreControl '  ) 
    if orgShowUI then orgToggleScoreControl() end
end

local orgExpand = Expand
function Expand()
    --LOG('SCORE Expand '  ) 
    if orgShowUI then orgExpand() else HideUI() end
end

local orgInitialAnimation = InitialAnimation
function InitialAnimation(state)
    --LOG('SCORE InitialAnimation ' ) 
    if orgShowUI then orgInitialAnimation() else HideUI() end
end
-- hides UI elements of the original score board
function HideUI()
    if controls and controls.bg then 
        --controls.bg.Right:Set(500)
        controls.bg.Right:Set(-100)
        controls.bg:Hide()
        controls.collapseArrow:Hide() 
    end
end