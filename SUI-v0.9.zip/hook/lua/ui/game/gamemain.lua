local modPath = '/mods/SupremeScoreBoard/'
local modTextures = modPath..'textures/'
local modScripts  = modPath..'modules/'
 
local orgCreateUI = CreateUI
function CreateUI(isReplay, parent)
    orgCreateUI(isReplay)
    LOG('SSB >>> CreateUI')

    local parent = import('/lua/ui/game/borders.lua').GetMapGroup()
      
    import(modScripts .. 'score_board.lua').CreateScoreUI(parent)
    
    --LOG('isReplay ' .. tostring(isReplsay))

    --import(modScripts .. 'UnitsOverlays.lua').CreateUI()

    --import(modScripts .. 'economy.lua').CreateEconomyBar(parent)

    --import(modScripts .. "init.lua").init(isReplay, import('/lua/ui/game/borders.lua').GetMapGroup())
     
    --ForkThread(import(modScripts..'scoreStats.lua').syncStats)
    
end


local orgOnFirstUpdate = OnFirstUpdate
function OnFirstUpdate()
    orgOnFirstUpdate()
    LOG('SSB >>> OnFirstUpdate')
    --if not SessionIsReplay() then
    --    import(modScripts..'UnitsFilter.lua').CreateUI()
    --end
end

--local orgSetLayout = SetLayout
--function SetLayout(layout)
--    orgSetLayout(layout)
--    
--    import(modScripts .. 'UnitsFilter.lua').SetLayout(layout)
--end

local Selector = import(modScripts .. 'UnitsSelector.lua')

local orgOnSelectionChanged = OnSelectionChanged
function OnSelectionChanged(oldSelection, newSelection, added, removed)
    if not Selector.IsHidden() then
        orgOnSelectionChanged(oldSelection, newSelection, added, removed)
    end
end

