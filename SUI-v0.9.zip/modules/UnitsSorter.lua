-- ##########################################################################################
--  File:    /LUA/modules/UnitsSorter.lua
--  Author:  HUSSAR
--  Summary:  
--  Copyright � 2017 HUSSAR - All rights reserved.
-- ##########################################################################################

-- This table contains blueprint's categories or IDs for ordering units in grid columns, e.g. 
-- Units matching first entry will be placed as first item in a column
-- If two units match the first entry then the next entry is used for comparing
local sortBy = {
    -- Order blueprints first by their TECH level and then WEAPON categories
    TECH = {
        'TECH1',
        'TECH2',
        'TECH3',
        'EXPERIMENTAL',
        'ORBITALSYSTEM',
        'SATELLITE',
        -- Additional sorting
        'SCOUT',
        'BOT',
        'DIRECTFIRE',
        'INDIRECTFIRE',
        'ARTILLERY',
        'ANTIAIR',
        'TRANSPORTATION',
        'GROUNDATTACK',
        'ANTINAVY',
        'SUBMERSIBLE',
        'SHIELD',
    },
    -- Order blueprints first by their WEAPON categories and then TECH level
    WEAPON = {
        'MINE',
        'DIRECTFIRE',
        'ANTIAIR',
        'TRANSPORTATION',
        'GROUNDATTACK',
        'ANTINAVY',
        'SUBMERSIBLE',
        'BOMBER',
        'INDIRECTFIRE',
        'ARTILLERY',
        'TECH1',
        'TECH2',
        'TECH3',
        'EXPERIMENTAL',
        'TACTICALMISSILEPLATFORM',
        'ANTIMISSILE',
        'NUKE',
    },
    ENGINEERING = { 
        'NAVAL',
        'ORBITAL',
        'AIR',
        'LAND',
        'GATE',
        'ENGINEERSTATION',
        'ENGINEER',
        'TECH1',
        'TECH2',
        'TECH3',
        'EXPERIMENTAL',
        'RESEARCH', -- FACTORY HQ
        'SUPPORTFACTORY',
        'POD',
        'SORTCONSTRUCTION',
    },
    ECO = { 
        'MASSEXTRACTION',
        'MASSSTORAGE',
        'MASSFABRICATION', 
        'ENERGYPRODUCTION',
        'ENERGYSTORAGE',
        'HYDROCARBON',
        'TECH1',
        'TECH2',
        'TECH3',
        'EXPERIMENTAL',
    },
    SUPPORT = { 
        'AIRSTAGINGPLATFORM',
        'RADAR',
        'OMNI',
        'OPTICS',
        'SONAR',
        'COUNTERINTELLIGENCE',
        'WALL',
        'SHIELD',
        'TECH1',
        'TECH2',
        'TECH3',
        'EXPERIMENTAL',
    },
    UPGRADES = { 
        'COMMAND',
        'SUBCOMMANDER',
        'UPGRADE', -- Created in UnitsAnalyzer
        'ISPREENHANCEDUNIT',
        -- NOTE this order ensure that ACU/SCU have similar upgrades next to each other
        'Overcharge',
        'EngineeringThroughput',
        'ResourceAllocation',
        'ResourceAllocationAdvanced',
        'Sacrifice',
        'SensorRangeEnhancer',
        'Teleporter',
        'SelfRepairSystem',
        'StealthGenerator',
        'CloakingGenerator',
        'ShieldHeavy',
        'ShieldGeneratorField',
        'Shield',
        'RegenAura',
        'AdvancedRegenAura',
        'SystemIntegrityCompensator',
        'HighExplosiveOrdnance',
        'EnhancedSensors',
        'Missile',
        'TacticalMissile',
        'TacticalNukeMissile',
        'DamageStablization', -- TODO fix a typo in ACU/SCU blueprints Stablization
        'DamageStabilization',
        'DamageStabilizationAdvanced',
        'BlastAttack',
        'RateOfFire',
        'CoolingUpgrade',
        'AdvancedCoolingUpgrade',
        'EMPCharge',
        'FocusConvertor',
        'CrysalisBeam',
        'HeatSink',
        'HeavyAntiMatterCannon',
        'StabilitySuppressant',
        'NaniteTorpedoTube',
        'MicrowaveLaserGenerator',
        'RadarJammer',
        'NaniteMissileSystem',
        'ChronoDampener',
        'EngineeringFocusingModule',
        'LeftPod',
        'RightPod',
        'Switchback',
        'AdvancedEngineering',
        'T3Engineering',
        'Pod',
    },
}
function GetSortBy()
    return sortBy
end
-- Compares two variables of any type, e.g. bp.Tech, bp.ID
-- @param a - 1st value
-- @param b - 2nd value
function CompareBy(a, b)
    local typeA, typeB = type(a), type(b)
    if typeA ~= typeB then -- Order by type
        return typeA < typeB
    elseif typeA == "number" and typeB == "number" then
        if math.abs(a - b) < 0.0001 then
            return 0
        else
            return a > b -- Numbers in decreasing order
        end
    elseif typeA == "string" or typeB == "string" then
        local A, B = string.upper(a), string.upper(b)
        if A == B then
            return 0
        else
            return A > B
        end
    elseif typeA == "boolean" and typeB == "boolean" then
        return a == true
    else
        return tostring(a) < tostring(b) -- Order by address
    end
end

-- Compares two unit blueprints using their CategoriesHash table and ID value
-- @param a - 1st blueprint
-- @param b - 2nd blueprint
-- @param sortCategories - table with sort categories
-- @param sortReversed - optional boolean for sorting in reversed order specified in sortCategories
function CompareOrder(a, b, sortCategories, sortReversed)

    if table.getsize(sortCategories) == 0 then
        return 0
    end

    local orderA = nil
    local orderB = nil
    local categoryA = nil
    local categoryB = nil

    -- Find sorting index using blueprint' Categories or IDs
    for orderIndex, category in sortCategories do
        local isMatching = a.CategoriesHash[category] or a.ID == category
        if orderA == nil and isMatching then
           orderA = orderIndex
           categoryA = category
        end
        local isMatching = b.CategoriesHash[category] or b.ID == category
        if orderB == nil and isMatching then
           orderB = orderIndex
           categoryB = category
        end

        if orderA and orderB then
            if orderA == orderB then
                orderA = nil
                orderB = nil
            else
                break
            end
        end
    end
    -- LOG('avatar Sorting '  .. tostring(orderA).. ' vs '  .. tostring(orderB).. ' ' 
    -- .. tostring(categoryA).. ' vs '  .. tostring(categoryB).. ' ' 
    -- ..  table.getsize(sortCategories) .. ' = ' .. table.concat(sortCategories, ',') )
    
    if orderA == orderB then
        return 0 -- if a and b have identical Categories and ID
    end

    if sortReversed then
        return orderA < orderB
    else
        return orderA > orderB
    end
end

function SortUnits(unitsByID, sortCategories, sortReversed)
    if not sortCategories then
       sortCategories = sortBy.TECH
    end

    if table.getsize(unitsByID) == 0 then
        return unitsByID
    end

    local sortedUnits = table.indexize(unitsByID)

    table.sort(sortedUnits, function(a,b)
        local order = CompareOrder(a,b, sortCategories, sortReversed)
        if order == 0 then
            order = CompareBy(a.Tech, b.Tech)
            if order == 0 then
                return tostring(a.uid) > tostring(b.uid)
            else
                return order
            end
        else
            return order
        end
    end)

    return table.reverse(sortedUnits)
end
--function sort(units)
--    table.sort(units, 
--        function(a,b) return a:GetHealth() < b:GetHealth() end)
--end
function SortUnitsByStatus(units)

    --if table.getsize(units) < 2 then
    --    return
    --end
    local sortedUnits = table.indexize(units)

    table.sort(sortedUnits, function(a,b)
        --local isIdle = a:IsIdle()   

        --if a.uid ~= b.uid then 
        --    return a.uid < b.uid 
        --else
            if a.missiles ~= b.missiles then
                return a.missiles > b.missiles 
            elseif a.isEngineering and not b.isEngineering then
                return false
            elseif not a.isEngineering and b.isEngineering then
                return true
            else
                --return a:GetHealth() < b:GetHealth()
                --if a.missiles ~= b.missiles then
                --    return a.missiles > b.missiles 
                --else
                    if a:GetHealth() ~= b:GetHealth() then
                        return a:GetHealth() < b:GetHealth()
                    else
                        return a.eid < b.eid
                    end
                --end 
                
            end
        --end
        
        -- local order = CompareOrder(a,b, sortCategories, sortReversed)
        -- if order == 0 then
        --     order = CompareBy(a.Tech, b.Tech)
        --     if order == 0 then
        --         return tostring(a.ID) > tostring(b.ID)
        --     else
        --         return order
        --     end
        -- else
        --     return order
        -- end
    end)
    --if table.getsize(units) > 2 then
    --
    --    for id, unit in sortedUnits do
    --        LOG('unit sorting '  .. unit.id .. ' ' .. unit.eid .. ' ' .. unit:GetHealth() .. ' ' .. unit.Name .. ' ' .. tostring(unit.isEngineering)  .. ' ' .. tostring(unit:GetWorkProgress()) )
    --    end
    --
    --end

    return sortedUnits
end