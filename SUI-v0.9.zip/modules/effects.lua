

function TogglePulsing(control, status, isReplay, isInfinite)

    if not status then 
        control:SetNeedsFrameUpdate(false)
        control.isPulsing = false
        control.isEnabled = false
        control:SetAlpha(0)
    else 
        --if control.isFinished == false then return end
        if control.isPulsing then return end
         
        control.isPulsing = true
        control.isEnabled = true
        control.cycles = 1 
        control.dir = 1
        control:SetAlpha(0)
        control:SetNeedsFrameUpdate(true)
        control.OnFrame = function(self, delta)
            --if not self.isPulsing then 
            --    self:SetNeedsFrameUpdate(false)
            --    return 
            --end
            local newAlpha = self:GetAlpha() + (delta * 3 * self.dir)
            if newAlpha > 1 then
               newAlpha = 1
               self.dir = -1
               self.cycles = self.cycles + 1
               if not isInfinite and self.cycles > 5 then
                  --self.isFinished = true
                  self:SetNeedsFrameUpdate(false)
                  self.isPulsing = false
               end
            elseif newAlpha < 0 then
                newAlpha = 0
                self.dir = 1
            end
            self:SetAlpha(newAlpha)
        end
    end 
end 