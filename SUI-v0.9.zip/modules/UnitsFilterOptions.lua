local Utils     = import('/lua/system/utils.lua')
local UIUtil    = import('/lua/ui/uiutil.lua')
local Tooltip   = import('/lua/ui/game/tooltip.lua')
local TooltipInfo = import('/lua/ui/help/tooltips.lua').Tooltips

local Popup     = import('/lua/ui/controls/popups/popup.lua').Popup
local Group     = import('/lua/maui/group.lua').Group
local Checkbox  = import('/lua/maui/checkbox.lua').Checkbox
local Bitmap    = import('/lua/maui/bitmap.lua').Bitmap
local Button    = import('/lua/maui/button.lua').Button
local Grid      = import('/lua/maui/grid.lua').Grid 
local Scrollbar = import('/lua/maui/scrollbar.lua').Scrollbar
local Control   = import('/lua/maui/control.lua').Control
local Window    = import('/lua/maui/window.lua').Window
local Border    = import('/lua/maui/border.lua').Border 
local Dragger   = import('/lua/maui/dragger.lua').Dragger
 
local StatusBar     = import('/lua/maui/statusbar.lua').StatusBar
local ItemList      = import('/lua/maui/itemlist.lua').ItemList
local EffectHelpers = import('/lua/maui/effecthelpers.lua')
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')

local Prefs         = import('/lua/user/prefs.lua')
local UIMain        = import('/lua/ui/uimain.lua')
local GameCommon    = import('/lua/ui/game/gamecommon.lua')
local GameMain      = import('/lua/ui/game/gamemain.lua')

local modPath = '/mods/SupremeScoreBoard/' 
local modScripts  = modPath..'modules/'
local modControls = modPath..'controls/'
local modTextures = modPath..'textures/'
local modInfo   = import(modPath..'mod_info.lua')
local log       = import(modScripts..'ext.logging.lua') 

local TogglePulsing = import(modScripts .. 'effects.lua').TogglePulsing
local Timer = import(modScripts .. 'timer.lua')
local SupremeWindow = import(modControls .. 'SupremeWindow.lua').SupremeWindow

function SetOptions()
end

local confgControls = { 'slider', 'toggle', 'Title' }

function GetStatesBoolean()
    return {
        states = {
            {help = "", text = "<LOC _On>",  key = true },
            {help = "", text = "<LOC _Off>", key = false },
        },
    }
end 

local specs = nil
local defaults = nil
local options = nil

function GetSpecs()
    return specs
end

function GetDefaults() 
    return defaults
end

function GetOptions() 
    return options
end

-- Initialize
function Initialize(GUI)
--TODO add option to disable mouse wheel

    -- define specification for configurable options
    GUI.specs = {
        {
            tip     = "Specifies transparency of window background in the avatar filter",
            title   = "Window Alpha", 
            key     = 'winAlpha', 
            tab     = 'Window',
            type    = 'slider',
            default = 0.6, custom = { min = 0.2, max = 1.0, inc = 0.1, }, 
        }, {
            tip     = "Toggles visibility of the unit's Background/Terrain in the avatar filter",
            title   = "Unit Background Visible", 
            key     = 'showUnitBackground', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }, {
            tip     = "Toggles visibility of the unit's Icon in the avatar filter",
            title   = "Unit Icon Visible", 
            key     = 'showUnitIcon', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }, {
            tip     = "Specifies size of the unit's Icon in the avatar filter. \n\n Note this determines the size of avatars",
            title   = "Unit Icon Size", 
            key     = 'unitSize',
            tab     = 'Avatars',
            type    = 'slider',
            default = 60, custom = { min = 20, max = 80, inc = 0, }, 
        },{
            tip     = "Toggles visibility of the unit's background in the avatar filter",
            title   = "Unit Counter Visible", 
            key     = 'showUnitCounter', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        },{
            tip     = "Specifies font size of the unit's Counter in the avatar filter",
            title   = "Unit Counter Font Size", 
            key     = 'counterFontSize',
            tab     = 'Avatars',
            type    = 'slider',
            default = 18, custom = { min = 10, max = 25, inc = 0, }, 
        }, {
            tip     = "Toggles visibility of the unit's Missiles in the avatar filter",
            title   = "Unit Missiles Visible", 
            key     = 'showUnitMissiles', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        },{
            tip     = "Specifies font size of the unit's Missiles in the avatar filter",
            title   = "Unit Missiles Font Size", 
            key     = 'missilesFontSize',
            tab     = 'Avatars',
            type    = 'slider',
            default = 18, custom = { min = 10, max = 25, inc = 0, }, 
        },  {
            tip     = "Toggles visibility of the unit's Idle Icon in the avatar filter",
            title   = "Unit Idle Icon Visible", 
            key     = 'showUnitIdle', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }, {
            tip     = "Specifies ratio of the Idle Icon to size of unit's avatar. \n\n Note the Idle Icon might overlap Strategic Icon if sum of these ratios is greater than 100%",
            title   = "Unit Idle Icon Ratio", 
            key     = 'unitIdlesIconRatio', 
            tab     = 'Avatars',
            type    = 'slider',
            default = 0.5, custom = { min = 0.1, max = 0.8, inc = 0.1, }, 
        }, {
            tip     = "Toggles visibility of the unit's Strategic Icon in the avatar filter",
            title   = "Unit Strategic Icon Visible", 
            key     = 'showUnitStrat', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }, {
            tip     = "Specifies ratio of the Strategic Icon to size of unit's avatar. \n\n Note the Idle Icon might overlap Strategic Icon if sum of these ratios is greater than 100%",
            title   = "Unit Strategic Icon Ratio", 
            key     = 'unitStratIconRatio', 
            tab     = 'Avatars',
            type    = 'slider',
            default = 0.4, custom = { min = 0.1, max = 0.8, inc = 0.1, }, 
        }, {
            tip     = "Toggles visibility of the unit's Progress Bar in the avatar filter. \n\n Note this applies only to engineers and factories",
            title   = "Unit Progress Bar Visible", 
            key     = 'showUnitProgressBar', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        },  {
            tip     = "Specifies size of the unit's Progress Bar in the avatar filter. \n\n Note this applies only to engineers and factories",
            title   = "Unit Progress Bar Size", 
            key     = 'unitProgressBarSize',
            tab     = 'Avatars',
            type    = 'slider',
            default = 4, custom = { min = 2, max = 10, inc = 0,  }, 
        }, {
            tip     = "Toggles visibility of the unit's Average Health Bar in the avatar filter",
            title   = "Unit Average Health Bar Visible", 
            key     = 'showUnitAvgHealthBar', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }, {
            tip     = "Toggles visibility of the unit's Minimum Health Bar in the avatar filter",
            title   = "Unit Minimum Health Bar Visible", 
            key     = 'showUnitMinHealthBar', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }, {
            tip     = "Specifies size of the unit's Health Bars in the avatar filter. \n\n Note this applies the Minimum Health Bar and Average Health Bar",
            title   = "Unit Health Bar Size", 
            key     = 'unitHealthBarSize',
            tab     = 'Avatars',
            type    = 'slider',
            default = 8, custom = { min = 2, max = 15, inc = 0,  }, 
        }, {
            tip     = "Toggles visibility of the unit's Tooltips in the avatar filter",
            title   = "Unit Tooltips Visible", 
            key     = 'showTooltips', 
            tab     = 'Avatars',
            type    = 'toggle', 
            default = true, custom = GetStatesBoolean(),
        }
    } 
    
    GUI.defaults = {}
    -- define not-configurable options
    GUI.defaults.counterFontName  = "Arial Bold"
    GUI.defaults.missilesFontName = "Arial Bold"
    GUI.defaults.groupWidth  = 5 -- 50
    GUI.defaults.groupHeight = 5 -- 50
    GUI.defaults.showButtonClose = true
    GUI.defaults.showButtonPin = false
    GUI.defaults.showButtonReset = true
    GUI.defaults.showButtonConfig = false

    -- propagate defaults of configurable options
    for _, spec in GUI.specs do
        if spec.set == nil then
           spec.set = SetOptions
        end
        GUI.defaults[spec.key] = spec.default
    end

    GUI.options = {}
    if GUI.id then
        GUI.options = Prefs.GetFromCurrentProfile(GUI.id) or {}
    else
        WARN('cannot initialize options with nil GUI.id')
    end
    -- initialize options to default if they do not exist (creating UI for the first time)
    for key, value in GUI.defaults do
         if GUI.options[key] == nil then
            GUI.options[key] = value
        end
    end

end
 

