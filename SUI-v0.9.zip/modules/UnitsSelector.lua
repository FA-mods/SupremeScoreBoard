local hidden_select = false

function IsHidden()
    return hidden_select == true
end

function Hidden(callback)
    local CommandMode = import('/lua/ui/game/commandmode.lua')
    local current_command = CommandMode.GetCommandMode()
    local old_selection = GetSelectedUnits() or {}

    hidden_select = true
    callback()
    SelectUnits(old_selection)
    CommandMode.StartCommandMode(current_command[1], current_command[2])
    hidden_select = false
end
