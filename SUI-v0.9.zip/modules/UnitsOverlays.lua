

local Bitmap        = import('/lua/maui/bitmap.lua').Bitmap
local ItemList      = import('/lua/maui/itemlist.lua').ItemList
local Group         = import('/lua/maui/group.lua').Group 
local Tooltip       = import('/lua/ui/game/tooltip.lua')
local TooltipInfo   = import('/lua/ui/help/tooltips.lua').Tooltips
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')
local Prefs         = import('/lua/user/prefs.lua')
local UIUtil        = import('/lua/ui/uiutil.lua')
local UIMain        = import('/lua/ui/uimain.lua')

local Utils         = import('/lua/system/utils.lua')
local GameCommon    = import('/lua/ui/game/gamecommon.lua')
local GameMain      = import('/lua/ui/game/gamemain.lua')

local modPath = '/mods/SupremeScoreBoard/' 
local modScripts  = modPath..'modules/'
local modControls = modPath..'controls/'
local modTextures = modPath..'textures/'
local modInfo   = import(modPath..'mod_info.lua')
local log       = import(modScripts..'ext.logging.lua') 
local Timer     = import(modScripts .. 'timer.lua')

local TogglePulsing = import(modScripts .. 'effects.lua').TogglePulsing

local armyUnits = nil
local engineers = {} 

GUI = { 
    isBusy = false,
    config = false,
    overlays = nil,
    options = {
        offsetMax = 18,
        fontSize = 13,
        fontName = "Arial Bold" , --"Arial Bold", --UIUtil.bodyFont
        show = {
            Commanders = false,
            EngineersT3 = true,
            EngineersT2 = true,
            EngineersT1 = true,
            FactoriesT3 = false,
            FactoriesT2 = false,
            FactoriesT1 = false,
            TML = true,
            SMD = true,
            SML = true,
            SMS = true, -- naval sub nukes
            MEX = true, 
        },  
        --extractors = {
        --    colorIdle = 'FFFF680B', -- '#FFF4857D 
        --    colorBusy = 'FFFFE405', -- '#FF7DF489
        --    colorDone = 'FF0DEF25', -- '#FF0DEF25
        --    colorFull = 'FFFFFEFC'  -- '#FFFFFEFC
        --},
        --missiles = {
        --    colorIdle = 'FFFF680B', -- '#FFFF0B0B 
        --    colorBusy = 'FFFFE405', -- '#FFFFE405
        --    colorDone = 'FF0DEF25', -- '#FFFFFEFC
        --    colorFull = 'FFFFFEFC'  -- '#FFFFFEFC
        --},
        colorIdle = 'FFFF680B', -- '#FFFF680B 
        colorBusy = 'FFFFE405', -- '#FFFFE405
        colorDone = 'FF0DEF25', -- '#FF0DEF25
        colorFull = 'FF0DEF25'  -- '#FF0DEF25 -- '#FFFFFEFC
    }
}
function CloseUI()
    GUI.isBusy = true
    GUI.isLive = false
    LOG('--- UnitsOverlays CloseUI ' .. table.getsize(GUI.overlays) )
    GameMain.RemoveBeatFunction(UpdateUI, 'UpdateUI') 
    
    for id, overlay in GUI.overlays or {} do
        if overlay then
            --overlay:Hide()
            overlay:Dispose() 
            --GUI.overlays[id]:Hide()
            --GUI.overlays[id]:Destroy() 
            --GUI.overlays[id] = nil
        end
        --if avatar then avatar:Destroy() avatar = nil end
    end
    GUI.overlays = nil 
end  
function CreateUI(parent)
    if GUI.overlays then
        CloseUI() -- cleanup old overlays
    end

    LOG('--- UnitsOverlays CreateUI' ) 
    --GUI.options.fontSize = 11
    --GUI.options.fontName = "Arial Bold" --UIUtil.bodyFont
    --GUI.options.offsetMax = 18

    GUI.overlays = {}
    GUI.isBusy = false
    GUI.isLive = true
    GUI.id = Random(10000,100000)
    GameMain.AddBeatFunction(UpdateUI, true, 'UpdateUI')
    --TODO use this  
    -- GameMain.AddBeatFunction(UpdateUI, true)

end 

local worldView = import('/lua/ui/game/worldview.lua').viewLeft


--TODO check if this is faster?
-- local views = import('/lua/ui/game/worldview.lua').GetWorldViews()
-- for _, view in views do
--    local coords = view:GetScreenPos(unit)
--    LOG("Unit 2D coordonates : " .. repr(coords))   
-- end

-- local V3pos  =  unit:GetPosition()
-- local views = import('/lua/ui/game/worldview.lua').GetWorldViews()
-- for _, view in views do
--    local coords = view:Project(V3pos)
--    LOG("Unit 2D coordonates : " .. repr(coords))   
-- end


function CreateOverlay(unit, options, group)
    --LOG('--- UnitsOverlays CreateOverlay ' .. group) 
    --local overlay = Bitmap(GetFrame(0))
    local overlay = Bitmap(worldView)
    overlay.id = unit.eid 
    overlay.group = group
    overlay.parent = GetFrame(0)
    overlay:SetSolidColor('92131313')-- '#92131313
    overlay.Width:Set(options.fontSize + 2)
    overlay.Height:Set(options.fontSize + 2)

    overlay.centerX = (overlay.Width() / 2.0) + 1
    overlay.centerY = (overlay.Height() / 2.0) + 1
    
    local renderPass =   UIUtil.UIRP_PostGlow 
    local unitPos = worldView:Project(unit:GetPosition()) 
    overlay.initX = (unitPos.x - overlay.centerX) 
    overlay.initY = (unitPos.y - overlay.centerY) - options.offsetMax  
    overlay:SetRenderPass(renderPass)
    
    --overlay.Left:Set(function() return overlay.initX end)
    --overlay.Top:Set(function() return overlay.initY end)

    --overlay:SetRenderPass(UIUtil.UIRP_UnderWorld) 
     --LOG('RenderPass ' .. tostring(UIUtil.UIRP_PostGlow) .. ' ' ..  tostring(UIUtil.UIRP_UnderWorld))

    --if unit.isMissleSilo then
        overlay.text = UIUtil.CreateText(overlay, '0', options.fontSize, options.fontName)
        overlay.text:SetColor('FFD9FF00')-- '#FFD9FF00
        overlay.text:SetAlpha(1)  
        --overlay.text:SetDropShadow(true)
        LayoutHelpers.AtCenterIn(overlay.text, overlay, 0, 0)
        --overlay.text:SetRenderPass(renderPass)
        --overlay.text:Hide()
    --else
    --    local icon = modTextures..'/ui/common/game/resource-panel/build-icon.dds'
    --    overlay:SetTexture(icon)
    --end

    local deltaX = 0
    local deltaY = 0
    local frame = 0

    overlay.Toggle = function(self, isVisible)
        if isVisible then
            self:Show()
            self.text:Show()
            self:SetNeedsFrameUpdate(true)
        else
            self:SetNeedsFrameUpdate(false)
            self:Hide()
            self.text:Hide()
        end
    end
    -- dispose of all Ui elements and stop frame updates
    overlay.Dispose = function(self, id)
        self:SetNeedsFrameUpdate(false)
        if self.text then
           self:OnDestroy()
        end
        self:Destroy()
        if GUI.overlays[id] then 
           GUI.overlays[id] = nil
        end 
    end

    overlay.OnFrame = function(self, delta)
        if unit:IsDead() then 
            self:Dispose(self.id)
        else 
            local zoom = GetCamera('WorldCamera'):GetZoom()
            
            local offset = options.offsetMax
            --if zoom > 800 or zoom < 50 then
            --    self:Hide()
            --    return
            --elseif zoom > 250 then
            --    self:Show()
            --    local zoomRange = 800 - 250
            --    local zoomDelta = 800 - zoom
            --    local zoomRatio = (zoomDelta / zoomRange)
            --    offset = options.offsetMax * zoomRatio 
            --end

            if zoom > 300 then
                offset = 0
            end 
            
            unitPos = worldView:Project(unit:GetPosition())
            local x = unitPos.x - self.centerX 
            --local y = unitPos.y - overlay.Height() / 2 -- - 14  
            local y = unitPos.y - self.centerY  - offset --(overlay.Height() / 2.0) -- options.offsetMax  
 
                self.Left:Set(x)
                self.Top:Set(y)
              --  self.initX = self.targetX  
             --   self.initY = self.targetY  
            --x = math.floor(x)
            --y = math.floor(y)
         --   deltaX = self.targetX - self.initX
         --   deltaY = self.targetY - self.initY

            -- if math.abs(deltaX) > 1 or 
            --    math.abs(deltaY) > 1 then
            --    
            --     --self.isAnimating = true
            --     self.Left:Set(self.initX + (deltaX / 2.0))
            --     self.Top:Set(self.initY + (deltaY / 2.0))
            -- 
            --     
            --     self.Left:Set(self.initX + (deltaX / 2.0))
            --     self.Top:Set(self.initY + (deltaY / 2.0))
            -- else
            --     
            --     self.Left:Set(x)
            --     self.Top:Set(y)
            -- end
            
            --    self.initX = self.targetX  
            --    self.initY = self.targetY  
            
         --   if math.abs(deltaX) > 1 or 
         --      math.abs(deltaY) > 1 then
         --
         --      LOG('OnFrame ' ..  frame .. ' '  .. tostring(deltaX) ..  ' | '  .. tostring(deltaY).. ' time ' .. repr(delta)  ) 
         --
         --       frame = 0
         --   else
         --       frame = frame + 1
         --   end

            --.. ' p=' .. repr(p[1]).. ' ' .. repr(p[2]) )
            --overlay.Left:Set(function() return worldView.Left() + pos.x - overlay.Width() / 2.0 end)
            --overlay.Top:Set(function() return worldView.Top() + pos.y - overlay.Height() / 2.0 end)

            --LayoutHelpers.AtLeftTopIn(overlay, worldView, x, y) 
        end
    end
    overlay:Toggle(false)
    return overlay
end

function DisposeOverlay(id)
    if GUI.overlays[id] then
       GUI.overlays[id]:Dispose(id)
    end
end

function IsValid(unit)
    if unit:IsDead() then
        return false
    elseif GUI.options.show.Commanders and unit.isCommander then
        return true
    elseif GUI.options.show.EngineersT1 and unit.isEngineer and unit.Tech == 'T1' and not unit.isCommander then
        return true
    elseif GUI.options.show.EngineersT2 and unit.isEngineer and unit.Tech == 'T2' and not unit.isCommander then
        return true
    elseif GUI.options.show.EngineersT3 and unit.isEngineer and unit.Tech == 'T3' and not unit.isCommander then
        return true
    elseif GUI.options.show.FactoriesT1 and unit.isFactory and unit.Tech == 'T1' then
        return true
    elseif GUI.options.show.FactoriesT2 and unit.isFactory and unit.Tech == 'T2' then
        return true
    elseif GUI.options.show.FactoriesT3 and unit.isFactory and unit.Tech == 'T3' then
        return true
    elseif GUI.options.show.SMD and EntityCategoryContains((categories.STRUCTURE * categories.ANTIMISSILE * (categories.TECH3 + categories.EXPERIMENTAL)), unit) then
        return true
    elseif GUI.options.show.SML and EntityCategoryContains((categories.STRUCTURE * categories.NUKE), unit) then
        return true
    elseif GUI.options.show.SMS and EntityCategoryContains((categories.NAVAL * categories.NUKE), unit) then
        return true
    elseif GUI.options.show.TML and EntityCategoryContains((categories.STRUCTURE * categories.TACTICALMISSILEPLATFORM), unit) then
        return true
    elseif GUI.options.show.MEX and EntityCategoryContains((categories.STRUCTURE * categories.MASSEXTRACTION), unit) then
        return true
    end
      
    return false
end
function UpdateExtractors(unit, id)
    if not GUI.overlays[id] then
        GUI.overlays[id] = CreateOverlay(unit, GUI.options, 'extractors') 
    end
    
    if GUI.overlays[id]:IsHidden() then 
       GUI.overlays[id]:Toggle(true)
    end

    if unit.Tech == 'T1' then
        GUI.overlays[id].text:SetText('I')
        if unit.isEngineering then 
            GUI.overlays[id].text:SetColor(GUI.options.colorBusy) -- '#FFFFE405
        else
            GUI.overlays[id].text:SetColor(GUI.options.colorIdle) -- '#FFFF7505
        end
    elseif unit.Tech == 'T2' then 
        GUI.overlays[id].text:SetText('II')
        if unit.isEngineering then 
            GUI.overlays[id].text:SetColor(GUI.options.colorBusy) -- '#FFFFE405
        else
            GUI.overlays[id].text:SetColor(GUI.options.colorIdle) -- '#FFFF7505
        end
    elseif unit.Tech == 'T3' then
        GUI.overlays[id].text:SetText('III')
        if unit.isEngineering then 
            GUI.overlays[id].text:SetColor(GUI.options.colorBusy) -- '#FFFFE405
        else
            GUI.overlays[id].text:SetColor(GUI.options.colorDone) -- '#FFFF7505
        end
    elseif unit.bp.CategoriesHash['EXPERIMENTAL'] then
        GUI.overlays[id]:Toggle(false)
    end
     

end
function UpdateMissiles(unit, id)

    if not GUI.overlays[id] then
        GUI.overlays[id] = CreateOverlay(unit, GUI.options, 'missiles') 
    end


    if unit.isEngineering then 

        if unit.missiles > 0 then 
            GUI.overlays[id].text:SetColor(GUI.options.colorDone) -- '#FF0DEF25
        else
            GUI.overlays[id].text:SetColor(GUI.options.colorBusy) -- '#FFFFE405
        end

        if GUI.overlays[id].missiles < unit.missiles then
            TogglePulsing(GUI.overlays[id].text, true, true) 
        else 
            --TogglePulsing(GUI.overlays[id].text, false) 
        end
        GUI.overlays[id].missiles = unit.missiles
        GUI.overlays[id].text:SetText(unit.missiles)

    elseif unit.missiles > 0 then -- idle with missiles
        if unit.missiles == unit.missilesMax then
            GUI.overlays[id].text:SetColor(GUI.options.colorFull) -- '#FFF7F4F2
        else
            GUI.overlays[id].text:SetColor(GUI.options.colorIdle) -- '#FFFF7505
        end

        if unit.missiles > GUI.overlays[id].missiles then
            TogglePulsing(GUI.overlays[id].text, true, true) 
        else 
            --TogglePulsing(GUI.overlays[id].text, false) 
        end
        
        GUI.overlays[id].missiles = unit.missiles
        GUI.overlays[id].text:SetText(unit.missiles)
    else -- idle without missiles
        GUI.overlays[id].text:SetColor(GUI.options.colorIdle) -- '#FFFF7505
        GUI.overlays[id].text:SetText('0')
    end

    if GUI.overlays[id]:IsHidden() then 
       GUI.overlays[id]:Toggle(true)
    end
end

function UpdateEngineers(unit, id)

    if not GUI.overlays[id] then
        GUI.overlays[id] = CreateOverlay(unit, GUI.options, 'engineers')
         
    end

    --GUI.overlays[id].text:SetText(unit.action .." " .. unit.id .." " .. tostring(unit.canEngineer) .." " .. tostring(unit.energyUsed) .." " .. tostring(unit.isEngineering)) 
    --GUI.overlays[id].text:SetText(unit.action .." " .. tostring(unit.missiles)) 
    --GUI.overlays[id].text:SetText(tostring(unit.isCommander) or "?") 
    --GUI.overlays[id]:Show()
     
    if unit.isEngineering then --unit:IsIdle() then
    
        GUI.overlays[id].missiles = unit.missiles
        --GUI.overlays[id].text:SetColor('FF23D912') -- '#FF23D912
        GUI.overlays[id]:Toggle(false)
    else
        if unit.isCommander then 
            GUI.overlays[id].text:SetText("C") 
        elseif unit.isEngineer then 
            GUI.overlays[id].text:SetText("E") 
        elseif unit.isFactory then 
            GUI.overlays[id].text:SetText("F")
        end

        if GUI.overlays[id]:IsHidden() then 
           GUI.overlays[id].text:SetColor(GUI.options.colorIdle) -- '#FFFF2505
           GUI.overlays[id]:Toggle(true)
        end
         
        --GUI.overlays[id].text:SetColor('FF4FD7F7') -- '#FF4FD7F7
    end
end
local testUID = '222xsl0301_Missile' --url0301_Stealth urs0304 uel0301_Engineer xrb0304 urb2305

function UpdateUI()
    if GUI.isBusy then return end
    --LOG('UpdateUI ')
    GUI.isBusy = true
 
    --Timer.Start('engineering')
    armyUnits = import(modScripts .. 'UnitsTracker.lua').GetUnits()

    for _, unit in armyUnits do  
     
    --if unit.id == testUID then
    --   LOG('UpdateUI ' .. unit.id .. ' ' .. tostring(unit.isEngineer) .. ' ' .. tostring(unit.isMissleSilo) .. ' ' .. tostring(unit.missiles))
    --   
    --end
        if unit.isBuilt and not unit.isDrone and not unit.isEngStation then
            local id = unit.eid
            if not IsValid(unit) then
               DisposeOverlay(id) 
            elseif unit.isMissleSilo and not unit.isCommander then 
                UpdateMissiles(unit, id)
            elseif unit.isMassExtractor then 
                UpdateExtractors(unit, id)
            elseif unit.isEngineer or 
                   --unit.isEngStation  or 
                   unit.isFactory then 

               --if unit.isMissleSilo and unit.missiles > 0 then 
               --    UpdateMissiles(unit, id)
               --else
                    UpdateEngineers(unit, id)
               -- end 
            end
        end
    end
    --local engineers2 = EntityCategoryFilterDown(categories.ENGINEER, armyUnits)
 --    LOG(--'engineering ' .. -- GUI.id .. 
 --    -- ' units ='   .. table.getsize(armyUnits) .. 
 --    ' engineering ='   .. table.getsize(engineers)  .. Timer.Stop('engineering') 
 --    --' engineers2 ='   .. table.getsize(engineers2)
 --    )
       
    GUI.isBusy = false
end
