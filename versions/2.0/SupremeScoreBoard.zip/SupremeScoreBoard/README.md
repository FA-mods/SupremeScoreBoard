# SupremeScoreBoard (UI) mod (v1.2)

This repository contains implementation of a mod for Supreme Commander FA game. This mod changes only User Interface of the game and it can be used in multiplayer games withouth affecting other players. This mod is fully compatiable with Forged Alliance Forever.

#Features
Refer to this <a href="http://forums.faforever.com/viewtopic.php?f=41&t=10887" target="_blank">post</a> on FAF forum.  

#Installation
1. Download "SupremeScoreBoard.zip" file 
2. Unzip the file to your "Mods" folder for Supreme Commander FA game, e.g.
C:\Users\USER_NAME\Documents\My Games\Gas Powered Games\Supreme Commander Forged Alliance\Mods\
3. Enable SupremeScoreBoard mod in Mod Manager (in Supreme Commander FA game)

or
 
Download this mod from the vault in <a href="http://www.faforever.com/downloads/#.VrY6vPkrIQ8" target="_blank">Forged Alliance Forever</a> client

#License
The  is a very permissive license for software and other scientific or artistic works that offers a great degree of freedom. In fact, it is probably the best license out there. 

#Contribution

All contributions are welcome, though I can't guarantee to pull all of them in. If you do want to contribute, please create a separate branch and a pull request for that. It'll be a bit easier for me to keep the repo tidy that way.
Thanks in advance.

#Contact Info
Shoot me a message on FAF forum or in FAF client <a href="http://forums.faforever.com/memberlist.php?mode=viewprofile&u=9827" target="_blank">chat</a>. My user name is "HUSSAR":


