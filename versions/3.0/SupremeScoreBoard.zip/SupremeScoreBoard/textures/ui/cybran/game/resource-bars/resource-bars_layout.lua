layout = {
	['mini-energy-bar_bmp'] = {left = 0, top = 0, width = 160, height = 16, leftOffset = 0, topOffset = 0, },
	['mini-energy-bar-back_bmp'] = {left = 0, top = 0, width = 160, height = 16, leftOffset = 0, topOffset = 0, },
	['mini-mass-bar_bmp'] = {left = 0, top = 0, width = 160, height = 16, leftOffset = 0, topOffset = 1, },
	['mini-mass-bar-back_bmp'] = {left = 0, top = 0, width = 160, height = 16, leftOffset = 0, topOffset = 0, },
}
