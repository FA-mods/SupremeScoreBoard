-- ################################################
--    Generic Window Class
-- ################################################
--   In order for this class to work, you MUST hook in a styles table in your product.
--   Here is an example:
-- local styles = {
--     backgrounds = {
--         notitle = {
--             tl = '/game/mini-map-brd01/mini-map_brd_ul.dds',
--             tr = '/game/mini-map-brd01/mini-map_brd_ur.dds',
--             tm = '/game/mini-map-brd01/mini-map_brd_horz_um.dds',
--             ml = '/game/mini-map-brd01/mini-map_brd_vert_l.dds',
--             m = '/game/mini-map-brd01/mini-map_brd_m.dds',
--             mr = '/game/mini-map-brd01/mini-map_brd_vert_r.dds',
--             bl = '/game/mini-map-brd01/mini-map_brd_ll.dds',
--             bm = '/game/mini-map-brd01/mini-map_brd_lm.dds',
--             br = '/game/mini-map-brd01/mini-map_brd_lr.dds',
--             borderColor = 'ff415055',
--         },
--         title = {
--             tl = '/game/options_brd/options_brd_ul.dds',
--             tr = '/game/options_brd/options_brd_ur.dds',
--             tm = '/game/options_brd/options_brd_horz_um.dds',
--             ml = '/game/options_brd/options_brd_vert_l.dds',
--             m = '/game/options_brd/options_brd_m.dds',
--             mr = '/game/options_brd/options_brd_vert_r.dds',
--             bl = '/game/options_brd/options_brd_ll.dds',
--             bm = '/game/options_brd/options_brd_lm.dds',
--             br = '/game/options_brd/options_brd_lr.dds',
--             borderColor = 'ff415055',
--         },
--     },
--     closeButton = {
--         up = '/dialogs/close_btn/close_btn_up.dds',
--         down = '/dialogs/close_btn/close_btn_down.dds',
--         over = '/dialogs/close_btn/close_btn_over.dds',
--         dis = '/dialogs/close_btn/close_btn_dis.dds',
--     },
--     pinButton = {
--         up = '/dialogs/pin/pin_up.dds',
--         upSel = '/dialogs/pin/pinned_up.dds',
--         over = '/dialogs/pin/pin_over.dds',
--         overSel = '/dialogs/pin/pinned_over.dds',
--         dis = '/dialogs/pin/pin_dis.dds',
--         disSel = '/dialogs/pin/pinned_dis.dds',
--     },
--     configButton = {
--         up = '/dialogs/config_btn/config_btn_up.dds',
--         down = '/dialogs/config_btn/config_btn_down.dds',
--         over = '/dialogs/config_btn/config_btn_over.dds',
--         dis = '/dialogs/config_btn/config_btn_dis.dds',
--     },
--     title = {
--         font = UIUtil.titleFont,
--         color = UIUtil.fontColor,
--         size = 14,
--     },
--     cursorFunc = UIUtil.GetCursor,
-- }
-- ################################################

local Group = import('/lua/maui/group.lua').Group
local Bitmap = import('/lua/maui/bitmap.lua').Bitmap
local Text = import('/lua/maui/text.lua').Text
local Button = import('/lua/maui/button.lua').Button
local Dragger = import('/lua/maui/dragger.lua').Dragger
local Checkbox = import('/lua/maui/checkbox.lua').Checkbox
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')
local Prefs = import('/lua/user/prefs.lua')
local UIUtil = import('/lua/ui/uiutil.lua')
local Tooltip   = import('/lua/ui/game/tooltip.lua')

 styles = import('/lua/maui/window.lua').styles

--styles = {
--    backgrounds = {
--        notitle = {
--            tl = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_ul.dds'),
--            tr = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_ur.dds'),
--            tm = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_horz_um.dds'),
--            ml = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_vert_l.dds'),
--            m = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_m.dds'),
--            mr = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_vert_r.dds'),
--            bl = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_ll.dds'),
--            bm = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_lm.dds'),
--            br = UIUtil.UIFile('/game/mini-map-brd01/mini-map_brd_lr.dds'),
--            borderColor = 'ff415055',
--        },
--        title = {
--            tl = UIUtil.UIFile('/game/options_brd/options_brd_ul.dds'),
--            tr = UIUtil.UIFile('/game/options_brd/options_brd_ur.dds'),
--            tm = UIUtil.UIFile('/game/options_brd/options_brd_horz_um.dds'),
--            ml = UIUtil.UIFile('/game/options_brd/options_brd_vert_l.dds'),
--            m = UIUtil.UIFile('/game/options_brd/options_brd_m.dds'),
--            mr = UIUtil.UIFile('/game/options_brd/options_brd_vert_r.dds'),
--            bl = UIUtil.UIFile('/game/options_brd/options_brd_ll.dds'),
--            bm = UIUtil.UIFile('/game/options_brd/options_brd_lm.dds'),
--            br = UIUtil.UIFile('/game/options_brd/options_brd_lr.dds'),
--            borderColor = 'ff415055',
--        },
--    },
--    closeButton = {
--        up = UIUtil.SkinnableFile('/game/menu-btns/close_btn_up.dds'),
--        down = UIUtil.SkinnableFile('/game/menu-btns/close_btn_down.dds'),
--        over = UIUtil.SkinnableFile('/game/menu-btns/close_btn_over.dds'),
--        dis = UIUtil.SkinnableFile('/game/menu-btns/close_btn_dis.dds'),
--    },
--    pinButton = {
--        up = UIUtil.SkinnableFile('/game/menu-btns/pin_btn_up.dds'),
--        upSel = UIUtil.SkinnableFile('/game/menu-btns/pinned_btn_up.dds'),
--        over = UIUtil.SkinnableFile('/game/menu-btns/pin_btn_over.dds'),
--        overSel = UIUtil.SkinnableFile('/game/menu-btns/pinned_btn_over.dds'),
--        dis = UIUtil.SkinnableFile('/game/menu-btns/pin_btn_dis.dds'),
--        disSel = UIUtil.SkinnableFile('/game/menu-btns/pinned_btn_dis.dds'),
--    },
--    configButton = {
--        up = UIUtil.SkinnableFile('/game/menu-btns/config_btn_up.dds'),
--        down = UIUtil.SkinnableFile('/game/menu-btns/config_btn_down.dds'),
--        over = UIUtil.SkinnableFile('/game/menu-btns/config_btn_over.dds'),
--        dis = UIUtil.SkinnableFile('/game/menu-btns/config_btn_dis.dds'),
--    },
--    title = {
--        font = UIUtil.titleFont,
--        color = UIUtil.fontColor,
--        size = 14,
--    },
--    cursorFunc = UIUtil.GetCursor,
--}
 

SupremeWindow = Class(Group) {
    __init = function(self, parent, title, icon, pin, config, lockSize, lockPosition, prefID, defaultLocation, textureTable, defaultOptions)
        
      --LOG('SupremeWindow ' .. tostring(prefID))
        --styles = { 
   -- styles.backgrounds.title.tl = UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_up.dds')
   -- styles.backgrounds.title.tr = UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_up.dds')
   -- styles.backgrounds.title.tm = UIUtil.UIFile('/game/options_brd/options_brd_horz_um.dds')
   -- styles.backgrounds.title.ml = UIUtil.UIFile('/game/options_brd/options_brd_vert_l.dds')
   -- styles.backgrounds.title.m  = UIUtil.UIFile('/game/options_brd/options_brd_m.dds')
   -- styles.backgrounds.title.mr = UIUtil.UIFile('/game/options_brd/options_brd_vert_r.dds')
   -- styles.backgrounds.title.bl = UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_up.dds')
   -- styles.backgrounds.title.bm = UIUtil.UIFile('/game/options_brd/options_brd_lm.dds')
   -- styles.backgrounds.title.br = UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_up.dds')
    --styles.backgrounds.title.borderColor = 'ff415055' #ff415055
 
        Group.__init(self, parent, 'window group')
                
        self:DisableHitTest()
        
        self._resizeGroup = Group(parent, 'window resize group')
        LayoutHelpers.FillParent(self._resizeGroup, self)
        self._resizeGroup.Depth:Set(function() return self.Depth() + 100 end)
        self._resizeGroup:DisableHitTest()

        self._pref = prefID
        self._borderSize = 8 -- 5
        self._cornerSize = 12 -- 8
        self._sizeLock = false
        self._lockPosition = lockPosition or false
        self._lockSize = lockSize or false
        self._xMin = 100
        self._yMin = 100

        self.options = self:LoadWindowOptions() or defaultOptions
                
        self:CheckWindowOptions(pin, config)

        if table.getsize(defaultLocation) == 4 then
            self.defaultLocation = defaultLocation
        else
            LOG( 'SupremeWindow defaultLocation missing' )
            self.defaultLocation = {
                Top = function() return (GetFrame(0).Height() / 2.0) - self._yMin end,
                Left = function() return (GetFrame(0).Width() / 2.0) - self._xMin end,
                Right = function() return (GetFrame(0).Width() / 2.0) + self._yMin end,
                Bottom = function() return (GetFrame(0).Height() / 2.0) + self._xMin end
              --  Top = function() return (GetFrame(0).Height() / 2.0) - 100  end,
              --  Left = function() return (GetFrame(0).Width() / 2.0) - 100 end,
              --  Right = function() return (GetFrame(0).Width() / 2.0) + 100  end,
              --  Bottom = function() return (GetFrame(0).Height() / 2.0) + 100 end
            }
        end

        self._windowGroup = Group(self, 'window texture group')
        LayoutHelpers.FillParent(self._windowGroup, self)
        self._windowGroup:DisableHitTest()
        

  --  styles.backgrounds.title.tl = UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_up.dds')
  --  styles.backgrounds.title.tr = UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_up.dds')
  --  styles.backgrounds.title.bl = UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_up.dds')
  --  styles.backgrounds.title.br = UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_up.dds')
  --       
  --  textureTable = {
  --      tl = UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_up.dds'),
  --      tr = UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_up.dds'),
  --      tm = UIUtil.UIFile('/game/chat_brd/chat_brd_horz_um.dds'),
  --      ml = UIUtil.UIFile('/game/chat_brd/chat_brd_vert_l.dds'),
  --       m = UIUtil.UIFile('/game/chat_brd/chat_brd_m.dds'),
  --      mr = UIUtil.UIFile('/game/chat_brd/chat_brd_vert_r.dds'),
  --      bl = UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_up.dds'),
  --      bm = UIUtil.UIFile('/game/chat_brd/chat_brd_lm.dds'),
  --      br = UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_up.dds'),
  --      borderColor = 'ff415055',
  --  }

        local texturekey = 'notitle'
        if textureTable then
            texturekey = prefID
            styles.backgrounds[prefID] = textureTable
        elseif title then
            texturekey = 'title'
            --LOG('SupremeWindow title' )
            --texturekey = prefID
            -- textureTable = {
            --     tl = UIUtil.UIFile('/game/chat_brd/chat_brd_ul.dds'),
            --     tr = UIUtil.UIFile('/game/chat_brd/chat_brd_ur.dds'),
            --     tm = UIUtil.UIFile('/game/chat_brd/chat_brd_horz_um.dds'),
            --     ml = UIUtil.UIFile('/game/chat_brd/chat_brd_vert_l.dds'),
            --     m  = UIUtil.UIFile('/game/chat_brd/chat_brd_m.dds'),
            --     mr = UIUtil.UIFile('/game/chat_brd/chat_brd_vert_r.dds'),
            --     bl = UIUtil.UIFile('/game/chat_brd/chat_brd_m.dds'),
            --     bm = UIUtil.UIFile('/game/chat_brd/chat_brd_m.dds'),
            --     br = UIUtil.UIFile('/game/chat_brd/chat_brd_m.dds'),
            --     borderColor = 'FF1CCB24', -- #FF1CCB24 #ff415055
            -- }
            --textureTable = {
            --    tl = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_ul.dds'),
            --    tr = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_ur.dds'),
            --    tm = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_horz_um.dds'),
            --    ml = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_vert_l.dds'),
            --    m  = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_m.dds'),
            --    mr = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_vert_r.dds'),
            --    bl = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_ll.dds'),
            --    bm = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_lm.dds'),
            --    br = UIUtil.SkinnableFile('/game/chat_brd/chat_brd_lr.dds'),
            --    borderColor = 'ff415055', -- #ff415055
            --}
            textureTable = {
                tl = UIUtil.SkinnableFile('/game/panel/panel_brd_ul.dds'),
                tr = UIUtil.SkinnableFile('/game/panel/panel_brd_ur.dds'),
                tm = UIUtil.SkinnableFile('/game/panel/panel_brd_horz_um.dds'),
                ml = UIUtil.SkinnableFile('/game/panel/panel_brd_vert_l.dds'),
                m  = UIUtil.SkinnableFile('/game/panel/panel_brd_m.dds'),
                mr = UIUtil.SkinnableFile('/game/panel/panel_brd_vert_r.dds'),
                bl = UIUtil.SkinnableFile('/game/panel/panel_brd_ll.dds'),
                bm = UIUtil.SkinnableFile('/game/panel/panel_brd_lm.dds'),
                br = UIUtil.SkinnableFile('/game/panel/panel_brd_lr.dds'),
                borderColor = 'ff415055', -- #ff415055
            }
            styles.backgrounds[texturekey] = textureTable
        end
         
        self.tl = Bitmap(self._resizeGroup)
        self.tr = Bitmap(self._resizeGroup)
        self.bl = Bitmap(self._resizeGroup)
        self.br = Bitmap(self._resizeGroup)
        self.tm = Bitmap(self._resizeGroup)
        self.bm = Bitmap(self._resizeGroup)
        self.ml = Bitmap(self._resizeGroup)
        self.mr = Bitmap(self._resizeGroup)
                
        --Set alpha of resize controls to 0 so that they still get resize events, but are not seen
        self.tl:SetAlpha(0)
        self.tr:SetAlpha(0)
        self.bl:SetAlpha(0)
        self.br:SetAlpha(0)
        self.tm:SetAlpha(0)
        self.bm:SetAlpha(0)
        self.ml:SetAlpha(0)
        self.mr:SetAlpha(0)
        
        self.tl.Height:Set(self._cornerSize)
        self.tl.Width:Set(self._cornerSize)
        self.tl.Top:Set(self.Top)
        self.tl.Left:Set(self.Left)
        
        self.tr.Height:Set(self._cornerSize)
        self.tr.Width:Set(self._cornerSize)
        self.tr.Top:Set(self.Top)
        self.tr.Right:Set(self.Right)
        
        self.bl.Height:Set(self._cornerSize)
        self.bl.Width:Set(self._cornerSize)
        self.bl.Bottom:Set(self.Bottom)
        self.bl.Left:Set(self.Left)
        
        self.br.Height:Set(self._cornerSize)
        self.br.Width:Set(self._cornerSize)
        self.br.Bottom:Set(self.Bottom)
        self.br.Right:Set(self.Right)
        
        self.tm.Height:Set(self._borderSize)
        self.tm.Left:Set(self.tl.Right)
        self.tm.Right:Set(self.tr.Left)
        self.tm.Top:Set(self.tl.Top)
        
        self.bm.Height:Set(self._borderSize)
        self.bm.Left:Set(self.bl.Right)
        self.bm.Right:Set(self.br.Left)
        self.bm.Top:Set(self.bl.Top)
        
        self.ml.Width:Set(self._borderSize)
        self.ml.Left:Set(self.tl.Left)
        self.ml.Top:Set(self.tl.Bottom)
        self.ml.Bottom:Set(self.bl.Top)
        
        self.mr.Width:Set(self._borderSize)
        self.mr.Right:Set(self.tr.Right)
        self.mr.Top:Set(self.tr.Bottom)
        self.mr.Bottom:Set(self.br.Top)
        
        self.tl:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.tr:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.bl:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.br:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.tm:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.bm:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.ml:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.mr:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        
        self.window_tl = Bitmap(self._windowGroup, styles.backgrounds[texturekey].tl)
        self.window_tr = Bitmap(self._windowGroup, styles.backgrounds[texturekey].tr)
        self.window_tm = Bitmap(self._windowGroup, styles.backgrounds[texturekey].tm)
        self.window_ml = Bitmap(self._windowGroup, styles.backgrounds[texturekey].ml)
        self.window_m  = Bitmap(self._windowGroup, styles.backgrounds[texturekey].m)
        self.window_mr = Bitmap(self._windowGroup, styles.backgrounds[texturekey].mr)
        self.window_bl = Bitmap(self._windowGroup, styles.backgrounds[texturekey].bl)
        self.window_bm = Bitmap(self._windowGroup, styles.backgrounds[texturekey].bm)
        self.window_br = Bitmap(self._windowGroup, styles.backgrounds[texturekey].br)
        
   --  self.window_tl.Left:Set(function() return self.Left() - 26 end)
   --  self.window_tl.Top:Set(function() return self.Top() - 6 end) 
   --  
   --  self.window_tr.Right:Set(function() return self.Right() + 22 end)
   --  self.window_tr.Top:Set(function() return self.Top() - 8 end) 
   --  
   --  self.window_bl.Left:Set(function() return self.Left() - 26 end)
   --  self.window_bl.Bottom:Set(function() return self.Bottom() + 8 end) 
   --  
   --  self.window_br.Right:Set(function() return self.Right() + 22 end)
   --  self.window_br.Bottom:Set(function() return self.Bottom() + 8 end) 

        
        self.window_tl.Top:Set(self.Top)
        self.window_tl.Left:Set(self.Left)
        
        self.window_tr.Top:Set(self.Top)
        self.window_tr.Right:Set(self.Right)
        
        self.window_bl.Bottom:Set(self.Bottom)
        self.window_bl.Left:Set(self.Left)
        
        self.window_br.Bottom:Set(self.Bottom)
        self.window_br.Right:Set(self.Right)

        
        self.window_tm.Left:Set(self.window_tl.Right)
        self.window_tm.Right:Set(self.window_tr.Left)
        self.window_tm.Top:Set(self.window_tl.Top)
        
        self.window_bm.Left:Set(self.window_bl.Right)
        self.window_bm.Right:Set(self.window_br.Left)
        self.window_bm.Top:Set(self.window_bl.Top)
        
        self.window_ml.Left:Set(self.window_tl.Left)
        self.window_ml.Top:Set(self.window_tl.Bottom)
        self.window_ml.Bottom:Set(self.window_bl.Top)
        
        self.window_mr.Right:Set(self.window_tr.Right)
        self.window_mr.Top:Set(self.window_tr.Bottom)
        self.window_mr.Bottom:Set(self.window_br.Top)
        
        self.window_m.Top:Set(self.window_tm.Bottom)
        self.window_m.Left:Set(self.window_ml.Right)
        self.window_m.Right:Set(self.window_mr.Left)
        self.window_m.Bottom:Set(self.window_bm.Top)
        
        local color = '4DBB0ED9'-- '#4DBB0ED9'
        if UIUtil.bodyColor then
            color = UIUtil.bodyColor
        end


        self.TitleGroup = Bitmap(self)
        --self.TitleGroup:SetSolidColor(styles.backgrounds[texturekey].borderColor)
        self.TitleGroup:SetSolidColor(color)  
        self.TitleGroup.Top:Set(function() return self.tm.Top() + 8 end)
        self.TitleGroup.Left:Set(function() return self.tl.Left() + 5 end)
        self.TitleGroup.Right:Set(function() return self.tr.Right() -5 end)
        
        self.TitleGroup:SetAlpha(0.3) 
        --self.TitleGroup = Group(self, 'window title group')
        --self.TitleGroup.Top:Set(function() return self.tm.Top() + 2 end)
        --self.TitleGroup.Left:Set(self.tl.Left)
        --self.TitleGroup.Right:Set(self.tr.Right)

        self.TitleGroup.Height:Set(30)
        self.TitleGroup.Depth:Set(function() return self._windowGroup.Depth() + 2 end)
        
      --  self.DragTL = Bitmap(self, UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_up.dds'))
      --  self.DragTR = Bitmap(self, UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_up.dds'))
      --  self.DragBL = Bitmap(self, UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_up.dds'))
      --  self.DragBR = Bitmap(self, UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_up.dds'))
      --
      --  self.DragTL.textures = {up = UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_up.dds'),
      --                        down = UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_down.dds'),
      --                        over = UIUtil.UIFile('/game/drag-handle/drag-handle-ul_btn_over.dds')}
      --      
      --  self.DragTR.textures = {up = UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_up.dds'),
      --                        down = UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_down.dds'),
      --                        over = UIUtil.UIFile('/game/drag-handle/drag-handle-ur_btn_over.dds')}
      --      
      --  self.DragBL.textures = {up = UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_up.dds'),
      --                        down = UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_down.dds'),
      --                        over = UIUtil.UIFile('/game/drag-handle/drag-handle-ll_btn_over.dds')}
      --      
      --  self.DragBR.textures = {up = UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_up.dds'),
      --                        down = UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_down.dds'),
      --                        over = UIUtil.UIFile('/game/drag-handle/drag-handle-lr_btn_over.dds')}
      
        self.DragTL = Bitmap(self, UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ul_btn_up.dds'))
        self.DragTR = Bitmap(self, UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ur_btn_up.dds'))
        self.DragBL = Bitmap(self, UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ll_btn_up.dds'))
        self.DragBR = Bitmap(self, UIUtil.SkinnableFile('/game/drag-handle/drag-handle-lr_btn_up.dds'))

        self.DragTL.textures = {up = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ul_btn_up.dds'),
                              down = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ul_btn_down.dds'),
                              over = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ul_btn_over.dds')}
            
        self.DragTR.textures = {up = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ur_btn_up.dds'),
                              down = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ur_btn_down.dds'),
                              over = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ur_btn_over.dds')}
            
        self.DragBL.textures = {up = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ll_btn_up.dds'),
                              down = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ll_btn_down.dds'),
                              over = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-ll_btn_over.dds')}
            
        self.DragBR.textures = {up = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-lr_btn_up.dds'),
                              down = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-lr_btn_down.dds'),
                              over = UIUtil.SkinnableFile('/game/drag-handle/drag-handle-lr_btn_over.dds')}

        self.DragTL.Left:Set(function() return self.Left() - 26 end)
        self.DragTL.Top:Set(function() return self.Top() - 6 end)
        self.DragTL.Depth:Set(220)
        self.DragTL:DisableHitTest()
        
        self.DragTR.Right:Set(function() return self.Right() + 22 end)
        self.DragTR.Top:Set(function() return self.Top() - 8 end)
        self.DragTR.Depth:Set(self.DragTL.Depth)
        self.DragTR:DisableHitTest()
        
        self.DragBL.Left:Set(function() return self.Left() - 26 end)
        self.DragBL.Bottom:Set(function() return self.Bottom() + 8 end)
        self.DragBL.Depth:Set(self.DragTL.Depth)
        self.DragBL:DisableHitTest()
        
        self.DragBR.Right:Set(function() return self.Right() + 22 end)
        self.DragBR.Bottom:Set(function() return self.Bottom() + 8 end)
        self.DragBR.Depth:Set(self.DragTL.Depth)
        self.DragBR:DisableHitTest()

        self.controlMap = {
             tl = {self.DragTL},
             tr = {self.DragTR},
             bl = {self.DragBL},
             br = {self.DragBR},
             mr = {self.DragBR,self.DragTR},
             ml = {self.DragBL,self.DragTL},
             tm = {self.DragTL,self.DragTR},
             bm = {self.DragBL,self.DragBR},
        } 

        self.UpdateTexture = function(controlID, texture)
             --LOG('UpdateTexture ' .. tostring(controlID) .. ' =  '  .. tostring(texture))
             if not controlID then return end
             if not self.controlMap[controlID] then return end 
             
             for _, control in self.controlMap[controlID] do
                 if control.textures and 
                    control.textures[texture] then 
                    control:SetTexture(control.textures[texture])
                 end
             end
        end

        if icon then
            self._titleIcon = Bitmap(self.TitleGroup, icon)
            LayoutHelpers.AtLeftTopIn(self._titleIcon, self.TitleGroup, 2, 2)
        end
        
        self._title = Text(self.TitleGroup)
        if title then
            self._title:SetFont(styles.title.font, styles.title.size)
            self._title:SetColor(styles.title.color)
            self._title:SetText(LOC(title))
        end
        if icon then
            self._title.Left:Set(function() return self._titleIcon.Right() + 5 end)
            LayoutHelpers.AtVerticalCenterIn(self._title, self._titleIcon)
        else
            LayoutHelpers.AtLeftTopIn(self._title, self.TitleGroup, 20, 7)
        end
        
        local x = 5
        local y = 5
        local tooltip = {text = 'Tooltip', body = '' }
        
        if self.options.showButtonClose then 
            self._closeBtn = Button(self.TitleGroup, 
                styles.closeButton.up, 
                styles.closeButton.down, 
                styles.closeButton.over, 
                styles.closeButton.dis)
            tooltip = {text = 'Close Window', body = 'Closes and saves current location/options of this window ' }
            Tooltip.AddControlTooltip(self._closeBtn, tooltip)
            LayoutHelpers.AtRightTopIn(self._closeBtn, self.TitleGroup, x, y)
            x = x + 20
            self._closeBtn.OnClick = function(control)
                self:SaveWindowLocation()
                self:OnClose(control)
            end
        end

        if self.options.showButtonPin then -- pin then
            self._pinBtn = Checkbox(self.TitleGroup,
                styles.pinButton.up,
                styles.pinButton.upSel,
                styles.pinButton.over,
                styles.pinButton.overSel,
                styles.pinButton.dis,
                styles.pinButton.disSel)
            --LayoutHelpers.LeftOf(self._pinBtn, self._closeBtn)
            tooltip = {text = 'Toggle Window', body = 'Toggles automatic hiding of this window ' }
            Tooltip.AddControlTooltip(self._pinBtn, tooltip)
            LayoutHelpers.AtRightTopIn(self._pinBtn, self.TitleGroup, x, y)
            x = x + 20
            
            self._pinBtn.OnCheck = function(control, checked)
                self:OnPinCheck(checked)
            end
        end
        
        if self.options.showButtonConfig then -- config then
            self._configBtn = Button(self.TitleGroup,
                styles.configButton.up,
                styles.configButton.down,
                styles.configButton.over,
                styles.configButton.dis)
            --if self.options.showButtonPin then -- pin then
            --    LayoutHelpers.LeftOf(self._configBtn, self._pinBtn)
            --else
            --    LayoutHelpers.LeftOf(self._configBtn, self._closeBtn)
            --end

            tooltip = {text = 'Configure Window', body = 'Configures various options of this window ' }
            Tooltip.AddControlTooltip(self._configBtn, tooltip)
            LayoutHelpers.AtRightTopIn(self._configBtn, self.TitleGroup, x, y)
            x = x + 20

            self._configBtn.OnClick = function(control)
                self:OnConfigClick()
            end
        end

        if self.options.showButtonReset then 
            self._resetBtn = Button(self.TitleGroup, 
                UIUtil.SkinnableFile('/game/menu-btns/default_btn_up.dds'),
                UIUtil.SkinnableFile('/game/menu-btns/default_btn_down.dds'),
                UIUtil.SkinnableFile('/game/menu-btns/default_btn_over.dds'),
                UIUtil.SkinnableFile('/game/menu-btns/default_btn_dis.dds'))
            tooltip = {text = 'Reset Window', body = 'Reset and location and layout of this window ' }
            Tooltip.AddControlTooltip(self._resetBtn, tooltip)
            LayoutHelpers.AtRightTopIn(self._resetBtn, self.TitleGroup, x, y)
            x = x + 20

            self._resetBtn.OnClick = function(control)
                for index, position in self.defaultLocation do
                    local i = index
                    local pos = position
                    self[i]:Set(pos)
                end

                self:SaveWindowLocation()
                --self:OnClose(control)
            end
        end

        --self.ClientGroup = Group(self, 'window client group')
        self.ClientGroup = Bitmap(self)
        self.ClientGroup.Top:Set(self.TitleGroup.Bottom)
        self.ClientGroup.Left:Set(self.ml.Right)
        self.ClientGroup.Height:Set(function() return self.bm.Top() - self.TitleGroup.Bottom() end)
        self.ClientGroup.Width:Set(function() return self.mr.Left() - self.ml.Right() end)
        self.ClientGroup.Right:Set(self.mr.Left)
        self.ClientGroup.Bottom:Set(self.bm.Top)
        self.ClientGroup.Depth:Set(function() return self.window_m.Depth() + 1 end)
        
        self.ClientGroup:SetSolidColor('B2121212')-- '#B4121212'
        self.ClientGroup:SetAlpha(0.4) 

        self.ClientGroup.HandleEvent = function(control, event)
            if event.Type == "WheelRotation" then  
                return self:OnMouseWheel(event) 
            end
            return false
        end

        self.StartSizing = function(event, xControl, yControl)
            local drag = Dragger()
            local x_max = true
            local y_max = true
            if event.MouseX < self.tl.Right() then
                x_max = false
            end
            if event.MouseY < self.tl.Bottom() then
                y_max = false
            end
            drag.OnMove = function(dragself, x, y)
                if xControl then
                    local newX
                    if x_max then
                        newX = math.min(math.max(x, self.Left() + self._xMin), parent.Right())
                        newX = math.max(newX, self.Left() + self._title.Width() + self._closeBtn.Width() + (2*self.window_tl.Width()))
                    else
                        newX = math.min(math.max(x, 0), self.Right() - self._xMin)
                    end
                    xControl:Set(newX)
                end
                if yControl then
                    local newY 
                    if y_max then
                        newY = math.min(math.max(y, self.Top() + self._yMin), parent.Bottom())
                        newY = math.max(newY, self.Top() + self.window_bm.Height() + self.window_tm.Height())
                    else
                        newY = math.min(math.max(y, 0), self.Bottom() - self._yMin)
                    end
                    yControl:Set(newY)
                end
                self:OnResize(x, y, not self._sizeLock)
                if not self._sizeLock then
                    self._sizeLock = true
                end
            end
            drag.OnRelease = function(dragself)
                self._sizeLock = false
                self._resizeGroup:SetAlpha(0, true)
                GetCursor():Reset()
                drag:Destroy()
                self:SaveWindowLocation()
                self:OnResizeSet()
            end
            drag.OnCancel = function(dragself)
                self._sizeLock = false
                GetCursor():Reset()
                drag:Destroy()
            end
            PostDragger(self:GetRootFrame(), event.KeyCode, drag)
        end
                
        self.RolloverHandler = function(control, event, xControl, yControl, cursor, controlID)
 
            if self._lockSize then return false end
            if not self._sizeLock then
                if event.Type == 'MouseEnter' then
                    
                    self.UpdateTexture(controlID, 'over')

                    --self._resizeGroup:SetAlpha(1, true)
                    GetCursor():SetTexture(styles.cursorFunc(cursor))
                elseif event.Type == 'MouseExit' then
                
                    self.UpdateTexture(controlID, 'up')

                    --self._resizeGroup:SetAlpha(0, true)
                    GetCursor():Reset()
                elseif event.Type == 'ButtonPress' then
                
                    self.UpdateTexture(controlID, 'down')
                    self.StartSizing(event, xControl, yControl)

                elseif event.Type == "WheelRotation" then  
                    self:OnMouseWheel(event) 
                end
                return true
            end
        end

        self.br.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, self.Right, self.Bottom, 'NW_SE', 'br')
        end
        self.bl.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, self.Left, self.Bottom, 'NE_SW', 'bl')
        end
        self.bm.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, nil, self.Bottom, 'N_S', 'bm')
        end
        self.tr.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, self.Right, self.Top, 'NE_SW', 'tr')
        end
        self.tl.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, self.Left, self.Top, 'NW_SE', 'tl')
        end
        self.tm.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, nil, self.Top, 'N_S', 'tm')
        end
        self.mr.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, self.Right, nil, 'W_E', 'mr')
        end
        self.ml.HandleEvent = function(control, event)
            return self.RolloverHandler(control, event, self.Left, nil, 'W_E', 'ml')
        end
        
        self.TitleGroup.HandleEvent = function(control, event)
            --LOG('SupremeWindow TitleGroup '  .. event.Type)
            if not self._sizeLock then
                if event.Type == "WheelRotation" then  
                    return self:OnMouseWheel(event) 
                elseif event.Type == 'ButtonPress' then
                    if self._lockPosition then return end
                    local drag = Dragger()
                    local offX = event.MouseX - self.Left()
                    local offY = event.MouseY - self.Top()
                    local height = self.Height()
                    local width = self.Width()
                    drag.OnMove = function(dragself, x, y)
                        self.Left:Set(math.min(math.max(x-offX, parent.Left()), parent.Right() - self.Width()))
                        self.Top:Set(math.min(math.max(y-offY, parent.Top()), parent.Bottom() - self.Height()))
                        local tempRight = self.Left() + width
                        local tempBottom = self.Top() + height
                        self.Right:Set(tempRight)
                        self.Bottom:Set(tempBottom)
                        self:OnMove(x, y, not self._sizeLock)
                        if not self._sizeLock then
                            GetCursor():SetTexture(styles.cursorFunc('MOVE_WINDOW'))
                            self._sizeLock = true
                        end
                    end
                    drag.OnRelease = function(dragself)
                        self._sizeLock = false
                        GetCursor():Reset()
                        drag:Destroy()
                        self:SaveWindowLocation()
                        self:OnMoveSet()
                    end
                    drag.OnCancel = function(dragself)
                        self._sizeLock = false
                        GetCursor():Reset()
                        drag:Destroy()
                    end
                    PostDragger(self:GetRootFrame(), event.KeyCode, drag)
                end
                return false
            end

        end
        
        self.HandleEvent = function(control, event)
            --LOG('SupremeWindow event '  .. event.Type)
            --if event.Type == 'WheelRotation' then
            --    self:OnMouseWheel(event.WheelRotation)
            --end

            return false
        end
        self.OnHide = function(control, hidden)
            control._resizeGroup:SetHidden(hidden)
            control:OnHideWindow(control, hidden)
        end
        
        local OldHeightOnDirty = parent.Height.OnDirty
        local OldWidthOnDirty = parent.Width.OnDirty
        parent.Height.OnDirty = function(var)
            if self.Bottom() > parent.Bottom() then
                local Height = math.min(self.Height(), parent.Height())
                self.Bottom:Set(parent.Bottom)
                self.Top:Set(self.Bottom() - Height)
            end
            if OldHeightOnDirty then
               OldHeightOnDirty(var)
            end
            self:SaveWindowLocation()
        end
        parent.Width.OnDirty = function(var)
            if self.Right() > parent.Right() then
                local Width = math.min(self.Width(), parent.Width())
                self.Right:Set(parent.Right)
                self.Left:Set(self.Right() - Width)
            end
            if OldWidthOnDirty then
               OldWidthOnDirty(var)
            end
            self:SaveWindowLocation()
        end
        
        local location = self:LoadWindowLocation() --Prefs.GetFromCurrentProfile(prefID..'_location')
        --local location = { 
        --    top = 450,
        --    left = 2000,
        --    right = 2000 + 500,
        --    bottom = 450 + 500
        --}
        --table.print(location, 'location')
        if location then
            --LOG( 'SupremeWindow Location is loaded' ) 
            local parentWidth = parent.Right() - parent.Left()
            local parentHeight = parent.Bottom() - parent.Top()

            location.height = location.bottom - location.top
            location.width = location.right - location.left

          --  LOG('L=' .. tostring(parent.Left()) .. ' R=' .. tostring(parent.Right() ).. 
          --     ' T=' .. tostring(parent.Top()).. ' B='.. tostring(parent.Bottom())  .. ' H='.. parentHeight  .. ' W='.. parentWidth )
          --  
          --  LOG('L=' .. tostring(location.left) .. ' R=' .. tostring(location.right ).. 
          --     ' T=' .. tostring(location.top).. ' B='.. tostring(location.bottom)  .. ' H=' ..location.height  .. ' W=' ..location.width )

            if location.width > parentWidth then
               location.width = parentWidth / 4.0 
            end

            if location.height > parentHeight then
               location.height = parentHeight / 4.0 
            end
            
            -- ensure location is within parent's horizontal boundaries
            if location.left > parent.Right() or 
               location.right > parent.Right() then
               location.left = parent.Right() - 10 - location.width
               location.right = parent.Right() - 10
            elseif location.left < parent.Left() or 
                   location.right < parent.Left() then 
               location.left = parent.Left() + 10
               location.right = parent.Left() + 10 + location.width
            end
            -- ensure location is within parent's vertical boundaries
            if location.top > parent.Bottom() or 
               location.bottom > parent.Bottom() then
               location.top = parent.Bottom() - 10 - location.height
               location.bottom = parent.Bottom() - 10
            elseif location.top < parent.Top() or 
                   location.bottom < parent.Top() then 
               location.top = parent.Top() + 10
               location.bottom = parent.Top() + 10 + location.height
            end

            self.Top:Set(location.top)
            self.Left:Set(location.left)
            self.Right:Set(location.right)
            self.Bottom:Set(location.bottom)
            
           -- LOG('L=' .. tostring(self.Left()) .. ' R=' .. tostring(self.Right() ).. 
           --    ' T=' .. tostring(self.Top()).. ' B='.. tostring(self.Bottom())  .. ' H=' .. tostring(self.Bottom() - self.Top() ) .. ' W=' .. tostring(self.Right() - self.Left() ))
        elseif self.defaultLocation then
        
            --LOG( 'SupremeWindow Location is default' )

            self.Left:Set(self.defaultLocation.Left)
            self.Top:Set(self.defaultLocation.Top)
            self.Bottom:Set(self.defaultLocation.Bottom)
            self.Right:Set(self.defaultLocation.Right)
        end
    end,

        --    ApplyTextures = function(self, textures) 
    ApplyWindowTextures = function(self, textures) 
        if textures.tl then self.window_tl:SetTexture(textures.tl) end
        if textures.tr then self.window_tr:SetTexture(textures.tr) end
        if textures.tm then self.window_tm:SetTexture(textures.tm) end

        if textures.ml then self.window_ml:SetTexture(textures.ml) end
        if textures.m  then self.window_m:SetTexture(textures.m  ) end
        if textures.mr then self.window_mr:SetTexture(textures.mr) end

        if textures.bl then self.window_bl:SetTexture(textures.bl) end -- else self.window_bl:Hide() end
        if textures.bm then self.window_bm:SetTexture(textures.bm) end -- else self.window_bm:Hide() end
        if textures.br then self.window_br:SetTexture(textures.br) end -- else self.window_br:Hide() end

        if textures.borderColor then
            self.tl:SetSolidColor(textures.borderColor)
            self.tr:SetSolidColor(textures.borderColor)
            self.bl:SetSolidColor(textures.borderColor)
            self.br:SetSolidColor(textures.borderColor)
            self.tm:SetSolidColor(textures.borderColor)
            self.bm:SetSolidColor(textures.borderColor)
            self.ml:SetSolidColor(textures.borderColor)
            self.mr:SetSolidColor(textures.borderColor)
        end
    end,

    ApplyWindowOpacity = function(self, settings) 

        if not settings then return end
        if settings.tl then self.window_tl:SetAlpha(settings.tl) end
        if settings.tr then self.window_tr:SetAlpha(settings.tr) end
        if settings.tm then self.window_tm:SetAlpha(settings.tm) end

        if settings.ml then self.window_ml:SetAlpha(settings.ml) end
        if settings.m  then  self.window_m:SetAlpha(settings.m  ) end
        if settings.mr then self.window_mr:SetAlpha(settings.mr) end

        if settings.bl then self.window_bl:SetAlpha(settings.bl) end -- else self.window_bl:Hide() end
        if settings.bm then self.window_bm:SetAlpha(settings.bm) end -- else self.window_bm:Hide() end
        if settings.br then self.window_br:SetAlpha(settings.br) end -- else self.window_br:Hide() end
    end,
    
    GetWindowLocation = function(self)
        return {top = self.Top(), left = self.Left(), right = self.Right(), bottom = self.Bottom()}
    end,

    SaveWindowLocation = function(self)
        if self._pref then
            --LOG('SupremeWindow '  .. self._pref .. '--- saving location ' )
            --Prefs.SetToCurrentProfile(self._pref, {top = self.Top(), left = self.Left(), right = self.Right(), bottom = self.Bottom()})
            --Prefs.SetToCurrentProfile(self._pref..'_location', {top = self.Top(), left = self.Left(), right = self.Right(), bottom = self.Bottom()})
            --Prefs.SetToCurrentProfile(self._pref..'_location', self:GetWindowLocation())
            Prefs.SetToCurrentProfile(self._pref, self:GetWindowLocation())
        end
    end,
    
    LoadWindowLocation = function(self)
        local location = nil
        if self._pref then
            --LOG('SupremeWindow '  .. self._pref .. '--- loading location ' )
            --location = Prefs.GetFromCurrentProfile(self._pref..'_location')
            location = Prefs.GetFromCurrentProfile(self._pref)
        end
        return location
    end,

    SaveWindowOptions = function(self)
        if self._pref and self.options then
            --LOG('SupremeWindow '  .. self._pref .. '--- saving options ' )
            Prefs.SetToCurrentProfile(self._pref..'_options', self.options)
        end
    end,

    LoadWindowOptions = function(self)
        local options = nil
        if self._pref then
            --LOG('SupremeWindow '  .. self._pref .. '--- loading options ' )
            options = Prefs.GetFromCurrentProfile(self._pref..'_options')
        end
        return options
    end,

    CheckWindowOptions = function(self, pin, config)
        if not self.options then
            self.options = {} 
        end
        -- check if options have settings for visibility of buttons
        if self.options.showButtonClose == nil then 
           self.options.showButtonClose = true 
        end

        if self.options.showButtonReset == nil then 
           self.options.showButtonReset = true 
        end

        if self.options.showButtonPin == nil then 
           self.options.showButtonPin = pin or false 
        end

        if self.options.showButtonConfig == nil then 
           self.options.showButtonConfig = config or false 
        end

        --table.print(self.options, 'SupremeWindow options')
    end,
     
    GetClientGroup = function(self)
        return self.ClientGroup
    end,

    ToggleDraggers = function(self, DragTL, DragTR, DragBL, DragBR)

        local draggers = {self.DragTL, self.DragTR, self.DragBL, self.DragBR}
        local status = {DragTL, DragTR, DragBL, DragBR}

        for i, dragger in draggers do
            if status[i] then 
                dragger:Hide()
            else
                dragger:Show() 
            end
        end 
        

     --    self.DragTL:Hide()
     --   self.DragTR:Hide()
     --   self.DragBL:Hide()
     --   self.DragBR:Hide()

        --if left then
        --    self.tl:Hide()
        --    self.bl:Hide()
        --end
        --self.tr:Hide()
        --self.bl:Hide()
        --self.br:Hide()
        --self.tm:Hide()
        --self.bm:Hide()
        --self.ml:Hide()
        --self.mr:Hide()
    end,

    SetSizeLock = function(control, locked)
        self._lockSize(locked)
    end,
    
    SetPositionLock = function(control, locked)
        self._lockPosition(locked)
    end,
    
    SetMinimumResize = function(control, xDimension, yDimension)
        control._xMin = xDimension or 100
        control._yMin = yDimension or 100
    end,
    
    SetWindowAlpha = function(control, alpha)
        control._windowGroup:SetAlpha(alpha, true)
        control.TitleGroup:SetAlpha(alpha * 0.3)  
    end,

    SetBackgroundAlpha = function(control, alpha) 
        control.ClientGroup:SetAlpha(alpha)  
    end,

    SetTitle = function(control,text)
        control._title:SetText(LOC(text))
    end,
    
    IsPinned = function(control)
        if control._pinBtn then
            return control._pinBtn:IsChecked()
        else
            return false
        end
    end,
        
    OnDestroy = function(control)
        control._resizeGroup:Destroy()
    end,
    --
    -- The following are functions that can be overloaded
    --
    OnResize = function(control, x, y, firstFrame) end,
    OnResizeSet = function(control) end,
    
    OnMove = function(control, x, y, firstFrame) end,
    OnMoveSet = function(control) end,
    
    OnPinCheck = function(control, checked) end,
    OnConfigClick = function(control) end,
    
    OnMouseWheel = function(control, event) end,
    
    OnClose = function(control) end,
    OnHideWindow = function(control, hidden) end,
}