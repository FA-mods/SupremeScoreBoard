local modPath = '/mods/SupremeScoreBoard/'
local modTextures = modPath..'textures/'
local modScripts  = modPath..'modules/'

local Selector   = import(modScripts .. 'UnitsSelector.lua')
local ScoreBoard = import(modScripts .. 'score_board.lua')
