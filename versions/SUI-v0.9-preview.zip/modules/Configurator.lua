
local Utils         = import('/lua/system/utils.lua')
local UIUtil        = import('/lua/ui/uiutil.lua')
local Tooltip       = import('/lua/ui/game/tooltip.lua')
local TooltipInfo   = import('/lua/ui/help/tooltips.lua').Tooltips
local Popup         = import('/lua/ui/controls/popups/popup.lua').Popup

local Group         = import('/lua/maui/group.lua').Group
local Checkbox      = import('/lua/maui/checkbox.lua').Checkbox
local Bitmap        = import('/lua/maui/bitmap.lua').Bitmap
local Button        = import('/lua/maui/button.lua').Button
--local Grid          = import('/lua/maui/grid.lua').Grid 
local Scrollbar     = import('/lua/maui/scrollbar.lua').Scrollbar
local Control       = import('/lua/maui/control.lua').Control
--local Window        = import('/lua/maui/window.lua').Window
local Border        = import('/lua/maui/border.lua').Border 
local Dragger       = import('/lua/maui/dragger.lua').Dragger
local StatusBar     = import('/lua/maui/statusbar.lua').StatusBar
local ItemList      = import('/lua/maui/itemlist.lua').ItemList
local EffectHelpers = import('/lua/maui/effecthelpers.lua')
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')

local Prefs         = import('/lua/user/prefs.lua')
local UIMain        = import('/lua/ui/uimain.lua')
local GameCommon    = import('/lua/ui/game/gamecommon.lua')
local GameMain      = import('/lua/ui/game/gamemain.lua')  


local modPath = '/mods/SupremeScoreBoard/' 
local modScripts  = modPath..'modules/'
local modControls = modPath..'controls/'
local modTextures = modPath..'textures/'
local Timer = import(modScripts .. 'timer.lua')
local Window = import(modControls .. 'SupremeWindow.lua').SupremeWindow
local Grid = import(modControls .. 'SupremeGrid.lua').SupremeGrid

GUI = {
    config = false,  
    buttons = false,    
    margin = 5,    
}

local Slider        = import('/lua/maui/slider.lua').Slider
local IntegerSlider = import('/lua/maui/slider.lua').IntegerSlider
local Combo         = import('/lua/ui/controls/combo.lua').Combo

-- this will hold the working set of options, which won't be valid until applied
local currentOptionsSet = false

local optionsCurrent = false

-- contains a map of current option controls keyed by their option keys
local optionKeyToControlMap = false

function CreateSlider(parent, optionItemData)
    local group = Group(parent)
    --group.Width:Set(parent.Width)
    group.Height:Set(parent.Height)
    
    --table.print(currentOptionsSet, 'slider currentOptionsSet')
    
    -- check if the option has decimal range and apply multiplier
    if optionItemData.custom.inc > 0 and optionItemData.custom.inc < 1 then
       optionItemData.custom.mult = 100
       optionItemData.custom.inc = 0 -- optionItemData.custom.inc * 10
       optionItemData.custom.min = optionItemData.custom.min * 100
       optionItemData.custom.max = optionItemData.custom.max * 100
    end
    
    group.slider = false
    
    --LOG('slider inc ' ..tostring(optionItemData.custom.inc))
    if optionItemData.custom.inc == 0 then
        group.slider = Slider(group, false, 
        optionItemData.custom.min, 
        optionItemData.custom.max, 
        UIUtil.SkinnableFile('/slider02/slider_btn_up.dds'), 
        UIUtil.SkinnableFile('/slider02/slider_btn_over.dds'), 
        UIUtil.SkinnableFile('/slider02/slider_btn_down.dds'), 
        UIUtil.SkinnableFile('/slider02/slider-back_bmp.dds'))    
    else
        group.slider = IntegerSlider(group, false, 
        optionItemData.custom.min, 
        optionItemData.custom.max, 
        optionItemData.custom.inc, 
        UIUtil.SkinnableFile('/slider02/slider_btn_up.dds'), 
        UIUtil.SkinnableFile('/slider02/slider_btn_over.dds'), 
        UIUtil.SkinnableFile('/slider02/slider_btn_down.dds'), 
        UIUtil.SkinnableFile('/dialogs/options-02/slider-back_bmp.dds'))    
    end
    
    group.slider.mult = optionItemData.custom.mult or 1 
    
    --LayoutHelpers.AtLeftTopIn(group.slider, group)
    LayoutHelpers.AtLeftIn(group.slider, group)
    LayoutHelpers.AtVerticalCenterIn(group.slider, group)
    
    
    group.value = UIUtil.CreateText(group, "", 14)
    LayoutHelpers.RightOf(group.value, group.slider)
    
    --LayoutHelpers.AtLeftIn(bg._label, bg, 9)
    --LayoutHelpers.AtTopIn(group.value, group, 2)
    LayoutHelpers.AtVerticalCenterIn(group.value, group)
    
    group.slider.OnValueChanged = function(self, newValue)
        --LOG('slider.OnValueChanged ' ..tostring(newValue) .. ' '.. tostring(newValue / (self.mult or 1)))
        group.value:SetText(math.floor(tostring(newValue)))
    end
    
    group.slider.OnValueSet = function(self, newValue)
        --LOG('slider.OnValueSet ' ..tostring(newValue))
        if optionItemData.update then
           optionItemData.update(self, newValue / (self.mult or 1))
        end
        currentOptionsSet[optionItemData.key] = newValue / (self.mult or 1)
    end
    
    group.slider.OnBeginChange = function(self)
        if optionItemData.beginChange then
           optionItemData.beginChange(self)
        end
    end
    
    group.slider.OnEndChange = function(self)
        if optionItemData.endChange then
           optionItemData.endChange(self)
        end
    end
    
    group.slider.OnScrub = function(self, value)
        --LOG('slider.OnScrub ' ..tostring(value))
        if optionItemData.update then
           optionItemData.update(self,value / (self.mult or 1))
        end
    end
    
    group.OnDestroy = function(self)
        optionItemData.control = nil
        optionItemData.change = nil
    end
    
    optionItemData.control = group.slider
    optionItemData.change = function(control, value, skipUpdate)
        if not skipUpdate then
            control:SetValue(value)
        end
    end
    
    --LOG('slider:SetValue ' .. tostring(currentOptionsSet[optionItemData.key]))
    -- set initial value
    group.slider:SetValue(currentOptionsSet[optionItemData.key] * group.slider.mult)
    
    group.SetCustomData = function(newCustomData, newDefault)
    LOG('---------------slider:SetCustomData '  )
        -- this isn't really correct as it should check the indent, and recreate the control if needed
        -- and set the indent (which isn't exposed in slider, doh!) but this isn't really used
        -- at this point, so it's not worth putting work in to
        group.slider:SetStartValue(newCustomData.min)
        group.slider:SetEndValue(newCustomData.max)
    end
    
    return group
end
function CreateToggle(parent, optionItemData)
    local combo = Combo(parent, 14, 10, nil, nil, "UI_Tab_Click_01", "UI_Tab_Rollover_01")
    combo.Width:Set(250)
    
    --combo.Height:Set(parent.Height)

    combo.Depth:Set(function() return parent.Depth() + 12 end)

    combo.SetCustomData = function(newCustomData, newDefault)
        local itemArray = {}
        local default = 1
        local matchedCurrentValue = false
        combo:ClearItems()
        combo.keyMap = {}
        for index, val in newCustomData.states do
            if currentOptionsSet[optionItemData.key] == val.key then
                default = index
                matchedCurrentValue = true
            end
            itemArray[index] = val.text
            combo.keyMap[index] = val.key
        end
        combo.Key = newDefault
        combo:AddItems(itemArray, default)
        if table.getsize(itemArray) == 1 then
            combo:Disable()
            --LOG('combo disable '  )
        else
            combo:Enable()
        end
        --table.print(itemArray,'combo itemArray')
        --table.print(combo.keyMap,'combo keyMap')
        --table.print(newCustomData.states,'combo states')

     
        -- if we didn't find a match for our current value, we need to set the value to default
        if not matchedCurrentValue then
            currentOptionsSet[optionItemData.key] = newDefault
        end
    end
    
    combo.SetCustomData(optionItemData.custom, optionItemData.default)
   
    combo.OnClick = function(self, index, text, skipUpdate) 
        self.Key = index
        --LOG('combo index ' .. index)
        currentOptionsSet[optionItemData.key] = combo.keyMap[index]
        if optionItemData.update and not skipUpdate then
           optionItemData.update(self,combo.keyMap[index])
        end
    end
    
    combo.OnDestroy = function(self)
		optionItemData.control = nil
		optionItemData.change = nil
    end
    
    optionItemData.control = combo
    optionItemData.change = function(control, value, skipUpdate)
        -- find key in control
        --LOG('combo change ' .. tostring(value))
        for index, key in control.keyMap do
            if key == value then
                -- don't do anything if we're already set to this key
                if control:GetItem() ~= index then
                    control:SetItem(index)
                    control:OnClick(index, nil, skipUpdate)
                    return
                end
            end
        end
    end
    
    return combo
end
function CreateButton(parent, optionItemData)
    local bg = Bitmap(parent, UIUtil.SkinnableFile('/dialogs/options-02/content-btn-line_bmp.dds'))
    bg._button = UIUtil.CreateButtonStd(bg, '/dialogs/standard-small_btn/standard-small', 
        optionItemData.custom.text, 12, 2, 0, "UI_Opt_Mini_Button_Click", "UI_Opt_Mini_Button_Over")
    LayoutHelpers.AtCenterIn(bg._button, bg)
    bg._button.OnClick = function(self, modifiers)
        if optionItemData.update then
            optionItemData.update(self, 0)
        end
    end
	optionItemData.control = bg
    optionItemData.change = function(control, value)
        if optionItemData.update then
            optionItemData.update(control, value)
        end
    end
    bg.OnDestroy = function(self)
		optionItemData.control = nil
		optionItemData.change = nil
    end
    
    bg.SetCustomData = function(newCustomData, newDefault)
        bg._button.label:SetText(newCustomData)
    end
    
    return bg
end

function Create(type, parent, optionItemData)    
    if type == 'slider' then
        return CreateSlider(parent, optionItemData)
    elseif type == 'toggle' then
        return CreateToggle(parent, optionItemData)
    elseif type == 'button' then
        return CreateButton(parent, optionItemData)
    end
    return nil
end

-- this table is keyed with the different types of controls that can be created
-- each key's value is the function that actually creates the type
-- the signature of the function is: fucntion(parent, optionItemData) and should return it's base control
-- note that each control should create a change function that allows the control to have its value changed
-- not that each control should create a SetCustomData(newCustomData, newDefault) function that will initialize the control with new custom data
local controlTypeCreate = {
    toggle = CreateToggle,
    button = CreateButton,
    slider = CreateSlider,
}


function PrintDims(control, name)
 
 LOG('dimensions ' .. tostring(name) ) 

    local dimensions = {
        --    Top = function() return (GetFrame(0).Height() / 2.0) - self._yMin end,
        --    Left = function() return (GetFrame(0).Width() / 2.0) - self._xMin end,
        --    Right = function() return (GetFrame(0).Width() / 2.0) + self._yMin end,
        --    Bottom = function() return (GetFrame(0).Height() / 2.0) + self._xMin end
            Top = function() return (control.Top() )  end,
            Left = function() return (control.Left()  )  end,
            Right = function() return (control.Right()  )  end,
            Bottom = function() return (control.Bottom()  )   end
        }
    LOG('  T='  ..tostring(control.Top())   .. 
        ', L='  ..tostring(control.Left())   .. 
        ', R='  ..tostring(control.Right())  .. 
        ', B='  ..tostring(control.Bottom()) .. 
        ', H='  ..tostring(control.Bottom() - control.Top())  .. 
        ', W='  ..tostring(control.Right() - control.Left()) )
end

function CloseUI()
    if GUI.scroll then
       GUI.scroll:Destroy()
       GUI.scroll = nil
    end

    if GUI.win then
        
        if GUI.win.buttons then
            for key, button in GUI.win.buttons or {} do
                if button then
                   button:Destroy() 
                end
            end 
            GUI.win.buttons = false
        end

        if GUI.win.controls then
            for key, control in GUI.win.controls or {} do
                if control then
                   control:Destroy() 
                end
            end 
            GUI.win.controls = false
        end

       GUI.win:Destroy()
       GUI.win = false
    end
end

function CreateButtons()

    GUI.cancelButton = UIUtil.CreateButtonStd(GUI.win.area, '/widgets02/small', 
    '<LOC _Cancel>', 16)
    LayoutHelpers.AtHorizontalCenterIn(GUI.cancelButton, GUI.win.area, 0)
    LayoutHelpers.AtBottomIn(GUI.cancelButton, GUI.win.area, GUI.margin) 
    Tooltip.AddControlTooltip(GUI.cancelButton, 
        {text = '<LOC _Cancel>', body = 'Cancel any changes to options' })
    
    GUI.applyButton = UIUtil.CreateButtonStd(GUI.win.area, '/widgets02/small', 
    '<LOC _Apply>', 16)
    LayoutHelpers.RightOf(GUI.applyButton, GUI.cancelButton, 0)
    LayoutHelpers.AtBottomIn(GUI.applyButton, GUI.win.area, GUI.margin) 
    Tooltip.AddControlTooltip(GUI.applyButton, 
        {text = '<LOC _Apply>', body = 'Apply any changes to options' })
    
    GUI.resetButton = UIUtil.CreateButtonStd(GUI.win.area, '/widgets02/small', 
    '<LOC _Reset>', 16)
    LayoutHelpers.LeftOf(GUI.resetButton, GUI.cancelButton, 0)
    LayoutHelpers.AtBottomIn(GUI.resetButton, GUI.win.area, GUI.margin) 
    Tooltip.AddControlTooltip(GUI.resetButton, 
        {text = '<LOC _Reset>', body = 'Reset all to default options' })
    

    GUI.applyButton.OnClick = function(self)
        --ChatOptions = table.merged(ChatOptions, tempOptions)
        --Prefs.SetToCurrentProfile("chatoptions", ChatOptions)
        --GUI.bg:OnOptionsSet()
        --GUI.config:Destroy()
        --GUI.config = false
        CloseUI() 
        if GUI.setFunction then GUI.setFunction() end
    end
    GUI.cancelButton.OnClick = function(self)
        CloseUI() 
        if GUI.setFunction then GUI.setFunction() end
    end
    GUI.resetButton.OnClick = function(self)
        CloseUI() 
        if GUI.exitFunction then GUI.exitFunction() end
    end
    
    GUI.buttons = {}
    table.insert(GUI.buttons, GUI.applyButton)
    table.insert(GUI.buttons, GUI.cancelButton)
    table.insert(GUI.buttons, GUI.resetButton)

end

function GetDims(control)
    --margin = margin or 0
    local dimensions = {}
            --    Top = function() return (GetFrame(0).Height() / 2.0) - self._yMin end,
            --    Left = function() return (GetFrame(0).Width() / 2.0) - self._xMin end,
            --    Right = function() return (GetFrame(0).Width() / 2.0) + self._yMin end,
            --    Bottom = function() return (GetFrame(0).Height() / 2.0) + self._xMin end
    --           dimensions.Top = control.Top()
    --           dimensions.Left = control.Left()
    --           dimensions.Right = control.Right()
    --           dimensions.Bottom = control.Bottom()
    --           dimensions.Right = control.Bottom() - control.Top()
    --           dimensions.Bottom = control.Right() - control.Left()

    dimensions.Top = function(margin) return (control.Top() + (margin or 0))  end
    dimensions.Left = function(margin) return (control.Left()  + (margin or 0))  end
    dimensions.Right = function(margin) return (control.Right()  - (margin or 0))  end
    dimensions.Bottom = function(margin) return (control.Bottom() - (margin or 0))   end
    dimensions.Width = function(margin) return (control.Right() - control.Left() - 2*(margin or 0))  end
    dimensions.Height = function(margin) return (control.Bottom() - control.Bottom() - 2*(margin or 0))   end

    return dimensions
end

function CreateBoarder(parent, height)

    local border = Bitmap(parent)
    
    border:SetSolidColor('EA272928') --#EA272928 
    LayoutHelpers.FillParentFixedBorder(border, parent, 2)

    --border.fill = Bitmap(border) 
    --border.fill:SetSolidColor('D0363636') --#D0363636 
    --
    --LayoutHelpers.FillParentFixedBorder(border.fill, border, 2)

    return border
end

function CreateOption2(parent, optionItemData, height, width)
    local container = Bitmap(parent) 

    container._tipText = optionItemData.key
    container:SetAlpha(0.5) 

        
    container:SetSolidColor('FF5E5E5E') --#FF5E5E5E 
    container.Height:Set(height)
    --container.Width:Set(height)
    --LayoutHelpers.AtLeftIn(container, parent, 0)
    LayoutHelpers.AtRightIn(container, parent, 0)

   container.fill = Bitmap(container)
   container.fill:SetSolidColor('EA272928') --#EA272928 
   LayoutHelpers.FillParentFixedBorder(container.fill, container, 2)
   -- container.fill:SetAlpha(0.2) 

   container.tooltip = {text = optionItemData.title, body = optionItemData.tip }
   --Tooltip.AddControlTooltip(container.fill, container.tooltip)
    
    container.label = UIUtil.CreateText(container, optionItemData.title, 16, UIUtil.bodyFont)
    LayoutHelpers.AtVerticalCenterIn(container.label, container)
    LayoutHelpers.AtLeftIn(container.label, container, 15)

    container.HandleEvent = function(self, event)
        if event.Type == 'WheelRotation' then  
            return false
        elseif event.Type == 'MouseEnter'  then 
            self:SetSolidColor(UIUtil.bodyColor) --#D0E14C29 
            PlaySound(Sound({ Cue = "UI_MFD_Rollover", Bank = "Interface" }))
            Tooltip.CreateMouseoverDisplay(self.label, self.tooltip, nil, true)
            --Tooltip.CreateMouseoverDisplay(self, "options_" .. container._tipText, .5, true)
            --self.fill:SetSolidColor(UIUtil.bodyColor) --#D0E14C29 
        elseif event.Type == 'MouseExit' then 
            self:SetSolidColor('FF5E5E5E') --#FF5E5E5E 
            Tooltip.DestroyMouseoverDisplay()
            --self.fill:SetSolidColor('EA272928') --#EA272928 
        end
        return false
    end

    --container.border.Left:Set(function() return parent.Left() end)
    --container.border.Right:Set(function() return (parent.Right() / 2.0) - 2 end)
    --container.border.Height:Set(height)
    --LayoutHelpers.AtTopIn(container.border, container, 0)
    --LayoutHelpers.AtLeftIn(container.border, container, 0)

    
    --container.c = Create(optionItemData.type, container, optionItemData)
    if controlTypeCreate[optionItemData.type] then
        --container.c = Bitmap(container)
        --container.c.Height:Set(height-4)
        --container.c.Left:Set(function() return container.Right() - (GetDims(container).Width()/2.0) end)
        --container.c.Right:Set(function() return container.Right() - 2 end)
        --LayoutHelpers.AtVerticalCenterIn(container.c, container)
        --container.c:SetSolidColor('D05F5E5E') --#D05F5E5E 
    
        container.c = controlTypeCreate[optionItemData.type](container, optionItemData)
        --container.c = Create(optionItemData.type, container, optionItemData)
        --container.border.Left:Set(function() return parent.Left()+ (parent.Width()/2.0) end)
        --container.c =  CreateSlider(container, optionItemData)

        container.c.Left:Set(function() return container.Right() - (GetDims(container).Width() / 2.0) end)
        container.c.Right:Set(function() return container.Right() - 5 end)
        LayoutHelpers.AtVerticalCenterIn(container.c, container)
        
        container.c.HandleEventOrg = container.c.HandleEvent
        container.c.HandleEvent = function(self, event)
            if event.Type == 'WheelRotation' then  
                return false
            elseif event.Type == 'MouseEnter'  then 
                container:HandleEvent(event)
        
                --self:SetSolidColor(UIUtil.bodyColor) --#D0E14C29 
                --self.fill:SetSolidColor(UIUtil.bodyColor) --#D0E14C29 
            elseif event.Type == 'MouseExit' then 
                container:HandleEvent(event)
                --self:SetSolidColor('FF5E5E5E') --#FF5E5E5E 
                --self.fill:SetSolidColor('EA272928') --#EA272928 
            end
            return self:HandleEventOrg(event)
        end

    else
        LOG("Warning: Option item data [" .. optionItemData.key .. "] contains an unknown control type: " .. optionItemData.type .. ". Valid types are")
        for k,v in controlTypeCreate do
            LOG(k)
        end
    end
    
    return container
end

function CreateOption(parent, optionItemData, height)
    local image = '/dialogs/options-02/content-box_bmp.dds'
    --local width, height = GetTextureDimensions(image)

    local width = function() return parent.Width() - 4 end
     
    --PrintDims(parent, 'parent')

  --  local border = Bitmap(parent)
  --  --border.Width:Set(GetDims(parent).Width(2))
  --  --table.print(GetDims(parent),'GetDims')
  --  
  --  border.Height:Set(height)
  --  border:SetSolidColor('D0E14C29') --#D0E14C29 
  --  --LayoutHelpers.AtLeftTopIn(border, parent, 2, 2)
  --  LayoutHelpers.AtLeftIn(border, parent, 2)
  --  LayoutHelpers.AtRightIn(border, parent, 2)
  --  LayoutHelpers.AtTopIn(border, parent, 2)

    --PrintDims(border, 'border')

    local bg = Bitmap(parent, UIUtil.SkinnableFile(image))
    --local bg = Bitmap(border) 
    --bg:SetSolidColor('D0363636') --#D0363636 
    --LayoutHelpers.AtLeftTopIn(bg, border, 2, 2)
    --LayoutHelpers.FillParentFixedBorder(bg, parent, 2)
    
    --PrintDims(bg, 'bg')

    bg._label = UIUtil.CreateText(bg, optionItemData.title, 16, UIUtil.bodyFont)
    LayoutHelpers.AtLeftTopIn(bg._label, bg, 9, 6)
    LayoutHelpers.AtLeftIn(bg._label, bg, 9)
    LayoutHelpers.AtVerticalCenterIn(bg._label, bg)

    --bg._label._tipText = optionItemData.key
    
    --bg._label.HandleEvent = function(self, event)
    --bg.HandleEvent = function(self, event)
    --    if event.Type == 'MouseEnter' then
    --        Tooltip.CreateMouseoverDisplay(self, "options_" .. bg._label._tipText, .5, true)
    --    elseif event.Type == 'MouseExit' then
    --        Tooltip.DestroyMouseoverDisplay()
    --    end
    --end
    local x = (bg.Width() / 2.0) + 40
    -- this is here to help position the control
    --TODO get this data from layout!
    local controlGroup = Bitmap(bg)
    LayoutHelpers.AtLeftTopIn(controlGroup, bg, x, 5)
    controlGroup.Width:Set(bg.Width() - x + 20)
    controlGroup.Height:Set(bg.Height())
    --controlGroup:SetSolidColor('D01C78D9') --#D01C78D9 
    --LayoutHelpers.AtLeftTopIn(controlGroup, bg, 338, 5)
    --controlGroup.Width:Set(252)
    --controlGroup.Height:Set(24)

    if controlTypeCreate[optionItemData.type] then
        --bg._control = controlTypeCreate[optionItemData.type](controlGroup, optionItemData)
    else
        LOG("Warning: Option item data [" .. optionItemData.key .. "] contains an unknown control type: " .. optionItemData.type .. ". Valid types are")
        for k,v in controlTypeCreate do
            LOG(k)
        end
    end
    
    if bg._control then
        --LayoutHelpers.AtCenterIn(bg._control, controlGroup)
        --LayoutHelpers.AtLeftIn(bg._control, bg, (width / 2.0) + 5)
        --LayoutHelpers.AtVerticalCenterIn(bg._control, bg)

    end
    
    --optionKeyToControlMap[optionItemData.key] = bg._control
    
    return bg
end

function CreateUI(specs, options, title, setFunction, exitFunction)
    CloseUI()

    currentOptionsSet = table.copy(options)
    optionsCurrent = options

    if not title then
        title = 'Options'
    end
    local winOptions = {
        showButtonClose = true,
        showButtonPin = false,
        showButtonReset = false,
        showButtonConfig = false
    }

    GUI.setFunction = setFunction
    GUI.exitFunction = exitFunction

    GUI.win = Window(GetFrame(0), title, 
     --icon, pin, config, locl,
        -- nil, nil, nil, nil, nil, 'sui_filer_config', nil, nil, nil)
       --nil, true, true, nil, nil, 'sui_filer_config', nil, windowTextures, nil)
       nil, nil, nil, nil, nil, 'sui_filer_config', nil, nil, winOptions)
 
    GUI.win.OnClose = function(self)  
        -- TODO ask if ignore option changes if any 
        CloseUI() 
    end

    GUI.win:SetWindowAlpha(1)
    GUI.win:SetBackgroundAlpha(1)
    GUI.win:SetMinimumResize(350, 200)

    GUI.win.area = GUI.win:GetClientGroup()
     
    CreateButtons() 

   --  GUI.scroll = Bitmap(GUI.win.area)
   --  GUI.scroll.Left:Set(function() return GUI.win.area.Left() + GUI.margin end)
   --  GUI.scroll.Top:Set(function() return GUI.win.area.Top() + GUI.margin end)
   --  GUI.scroll.Right:Set(function() return GUI.win.area.Right() - GUI.margin end)
   --  --GUI.scroll.Bottom:Set(function() return GUI.win.area.Bottom() - GUI.margin end)
   --  --GUI.scroll.Bottom:Set(function() return GUI.win.area.Bottom() - (GUI.margin + GUI.buttons[1].Height()) end)
   -- -- GUI.scroll.Depth:Set(function() return GUI.win.area.Depth() + 1 end)
   --  
   --  --GUI.scroll.Width:Set(400)
   --  GUI.scroll.Height:Set(200)
   --  GUI.scroll:SetSolidColor('A17E2DA8') --#A17E2DA8 
    
   --local elementWidth, elementHeight = GetTextureDimensions(UIUtil.UIFile('/dialogs/options-02/content-box_bmp.dds'))
   
   local optionWidth = 430 --GUI.win.area.Width() - 2*GUI.margin
   local optionHeight = 40

   GUI.grid = Grid(GUI.win.area, optionWidth, optionHeight, 0, 0)
   
   GUI.grid.Left:Set(function() return GUI.win.area.Left() + GUI.margin end)
   GUI.grid.Top:Set(function() return GUI.win.area.Top() + GUI.margin end)
   GUI.grid.Right:Set(function() return GUI.win.area.Right() - GUI.margin - 30 end)
   --GUI.grid.Bottom:Set(function() return GUI.win.area.Bottom() - GUI.margin end)
   GUI.grid.Bottom:Set(function() return GUI.win.area.Bottom() - (2*GUI.margin + GUI.buttons[1].Height()) end)
   
   local scrollbar = UIUtil.CreateVertScrollbarFor(GUI.grid, 2 )
    
   -- GUI.grid.Height:Set(100)
   -- GUI.grid.Width:Set(200)
    -- remove controls and populate grid
        GUI.grid:DeleteAndDestroyAll(true)
        GUI.grid:AppendCols(1, true)
        --GUI.grid:AppendRows(4, true) 


   --local optCtrl = CreateOption(GUI.scroll, specs[1], optionHeight)
   --local optCtrl = CreateOption2(GUI.grid, specs[1], optionHeight)
   --GUI.grid:SetItem(optCtrl, 1, 1, true)
   --
   --optCtrl2 = CreateOption2(GUI.grid, specs[2], optionHeight)
   --GUI.grid:SetItem(optCtrl2, 1, 2, true)
   
    GUI.grid:AppendRows(table.getsize(specs), true) 
   for row, spec in specs  do
      local optCtrl = CreateOption2(GUI.grid, spec, optionHeight)
      GUI.grid:SetItem(optCtrl, 1, row, true)
   
    end

   --GUI.grid:StretchItems(true)
   GUI.grid:EndBatch()


--   PrintDims(GUI.grid, 'GUI.grid')
--   
--       PrintDims(optCtrl, 'container')
--PrintDims(optCtrl.label, 'container.label')
--PrintDims(optCtrl.c, 'container.c')


end