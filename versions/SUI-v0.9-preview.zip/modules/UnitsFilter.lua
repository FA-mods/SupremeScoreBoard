-- ##########################################################################################
--  File:    /LUA/modules/UnitsFilter.lua
--  Author:  HUSSAR
--  Summary:  
--  Copyright � 2017 HUSSAR - All rights reserved.
-- ##########################################################################################


local Utils         = import('/lua/system/utils.lua')
local UIUtil        = import('/lua/ui/uiutil.lua')
local Tooltip       = import('/lua/ui/game/tooltip.lua')
local TooltipInfo   = import('/lua/ui/help/tooltips.lua').Tooltips
local Popup         = import('/lua/ui/controls/popups/popup.lua').Popup

local Group         = import('/lua/maui/group.lua').Group
local Checkbox      = import('/lua/maui/checkbox.lua').Checkbox
local Bitmap        = import('/lua/maui/bitmap.lua').Bitmap
local Button        = import('/lua/maui/button.lua').Button
local Grid          = import('/lua/maui/grid.lua').Grid 
local Scrollbar     = import('/lua/maui/scrollbar.lua').Scrollbar
local Control       = import('/lua/maui/control.lua').Control
local Window        = import('/lua/maui/window.lua').Window
local Border        = import('/lua/maui/border.lua').Border 
local Dragger       = import('/lua/maui/dragger.lua').Dragger
local StatusBar     = import('/lua/maui/statusbar.lua').StatusBar
local ItemList      = import('/lua/maui/itemlist.lua').ItemList
local EffectHelpers = import('/lua/maui/effecthelpers.lua')
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')

local Prefs         = import('/lua/user/prefs.lua')
local UIMain        = import('/lua/ui/uimain.lua')
local GameCommon    = import('/lua/ui/game/gamecommon.lua')
local GameMain      = import('/lua/ui/game/gamemain.lua')  

local modPath = '/mods/SupremeScoreBoard/' 
local modScripts  = modPath..'modules/'
local modControls = modPath..'controls/'
local modTextures = modPath..'textures/'
local modInfo   = import(modPath..'mod_info.lua')
local log       = import(modScripts..'ext.logging.lua') 
local Timer     = import(modScripts .. 'timer.lua')

local TogglePulsing = import(modScripts .. 'effects.lua').TogglePulsing
local SupremeWindow = import(modControls .. 'SupremeWindow.lua').SupremeWindow
--local UnitAvatar      = import(modScripts .. 'UnitAvatar.lua').CreateUI
 
local UnitsAnalyzer = import('/lua/ui/lobby/UnitsAnalyzer.lua')

--local CHAT_INACTIVITY_TIMEOUT = 15  -- in seconds
--local savedParent = false

local armyUnits = {}

GUI = {
    id = 'SUI_UnitsFilter_win2',
    win = false,  
    config = false,
    avatars = {},
    filters = {},
    overlays = {},
    setup = {}
}

local UnitsStats = import(modScripts .. 'UnitsTracker.lua') 
--GUI.id = 'sui_UnitsFilter_win2'

function SetOptions()
end

--local confgControls = { 'Slider', 'Toggle', 'Title' }
 
local UnitsOptions = import(modScripts .. 'UnitsFilterOptions.lua')

--CreateOptionSpecs()
UnitsOptions.Initialize(GUI)
--import(modScripts .. 'UnitsFilterOptions.lua').Initialize(GUI)
--GUI.options = UnitsOptions.GetOptions(GUI.id)

function CreateMainWindow()
 
    LOG('--- UnitsFilter Create BG'  )
    local mainFrame = GetFrame(0)
    local location = {
        --Top = function() return root.Bottom() - 393 end,
        Top = function() return GetFrame(0).Top() + 250  end,
        Left = function() return GetFrame(0).Right() -375 end,
        Right = function() return GetFrame(0).Right() - 10  end,
        Bottom = function() return GetFrame(0).Bottom() - 200 end
    }
    --local title = 'SUI - Units Filter & Overlays'
    local title = 'Supreme User Interface - Units Filter'

    --local bg = Window(GetFrame(0), '', nil, true, true, nil, nil, 'chat_window', location)
    --local bg = Window(GetFrame(0), '', nil, true, true, nil, nil, 'chat_window2', location)
    local win = SupremeWindow(GetFrame(0), title,
       --icon, pin, config, lock, 
         nil, true, true, nil, nil, GUI.id, location, nil, GUI.options)
        --true, true, nil, nil, 'sui_filter', location)
    --bg.Depth:Set(200)
        
    win:SetWindowAlpha(GUI.options.winAlpha)
    win:SetMinimumResize(360, 200)
    win:SetWindowAlpha(.65)

    --bg.Depth:Set(200)
        
    
    win.Depth:Set(1000)
    --bg:DisableHitTest() 

    return win
    --GUI.win.Depth:Set(UIUtil.consoleDepth) 
    --bg.OnConfigClick = function(self)
    --    --ConfigWindow(GUI.win)
    --end    
    --bg.Show = function(self)
    --    --edit:AcquireFocus()
    --    Control.Show(self)
    --end
    --bg.Hide = function(self)
    --    if UI.config then
    --       UI.config:Destroy()
    --       UI.config = false
    --    end
    --    Control.Hide(self)
    --end
    --GUI.win.OnClose = function(self)
    --    self:Hide()
    --end   
 end
function SetLayout()
    LOG('--- UnitsFilter SetLayout')
    --import(UIUtil.GetLayoutFilename('chat')).SetLayout()
end

function FilterUnits(classes, units)
    local matches = {}
    --local unitsFilter = EntityCategoryFilterDown(classes, units)
    --LOG('unitsFilter ' .. table.getsize(unitsFilter))

    for i, unit in units do
        if unit and not unit:IsDead() then 
            --local found = true 
            --if not unit.isBuilt then
            --    --LOG(' Health ' .. unit.Name .. ' = ' .. unit:GetHealth() .. ' ' ..  unit:GetMaxHealth())
            --    if unit:GetHealth() == unit:GetMaxHealth() then
            --       unit.isBuilt = true
            --       --LOG(' built ' .. unit.Name)
            --    end  
            --else
            --      -- LOG(' built already ' .. unit.Name)
            --end 
            if unit.isBuilt and EntityCategoryContains(classes, unit) then
                table.insert(matches, unit)
            end
        end
    end
    return matches
end

--GUI.options = {}
--GUI.options.groupBy = { faction = true }

local UnitTypes = {
    --{Name="T1 Land Units",  category = categories.LAND * categories.BUILTBYTIER1FACTORY * categories.MOBILE - categories.ENGINEER },
    --{Name="T2 Land Units",  category = categories.LAND * categories.BUILTBYTIER2FACTORY * categories.MOBILE - categories.ENGINEER },
    --{Name="T3 Land Units",  category = categories.LAND * categories.BUILTBYTIER3FACTORY * categories.MOBILE - categories.ENGINEER },
    --{Name="T1 Air Units",   category = categories.AIR * categories.BUILTBYTIER1FACTORY * categories.MOBILE  },
    --{Name="T2 Air Units",   category = categories.AIR * categories.BUILTBYTIER2FACTORY * categories.MOBILE  },
    --{Name="T3 Air Units",   category = categories.AIR * categories.BUILTBYTIER3FACTORY * categories.MOBILE  },
    --{Name="T1 Naval Units", category = categories.NAVAL * categories.BUILTBYTIER1FACTORY * categories.MOBILE  },
    --{Name="T2 Naval Units", category = categories.NAVAL * categories.BUILTBYTIER2FACTORY * categories.MOBILE  },
    --{Name="T3 Naval Units", category = categories.NAVAL * categories.BUILTBYTIER3FACTORY * categories.MOBILE  },
    { Name = "SHIELD",              Category = categories.STRUCTURE * categories.SHIELD },
    { Name = "INTEL",               Category = categories.STRUCTURE * (categories.RADAR + categories.OMNI + categories.SONAR) },
    { Name = "ENERGY PRODUCTION",   Category = categories.STRUCTURE * categories.ENERGYPRODUCTION },
    { Name = "MASS EXTRACTION",     Category = categories.STRUCTURE * (categories.MASSEXTRACTION + categories.MASSSTORAGE) },
    { Name = "FACTORY",             Category = categories.STRUCTURE * categories.FACTORY - categories.MOBILE},
  --{Name="ECO",            Category = categories.STRUCTURE * (categories.MASSEXTRACTION + categories.ENERGYPRODUCTION) },
    -- {Name="Mass extraction", category = categories.MASSEXTRACTION + categories.MASSSTORAGE },
    --{Name="MASSFABRICATION", category = categories.STRUCTURE * categories.MASSFABRICATION },
}
local Sorter = import(modScripts .. 'UnitsSorter.lua')
local SortBy = Sorter.GetSortBy()
-- abilities
local abilities = { 
    DIRECTFIRE = (categories.DIRECTFIRE + categories.SATELLITE + categories.ORBITALSYSTEM),
    INDIRECTFIRE = categories.INDIRECTFIRE,
    --MISSILENAVY = (categories.NUKE + categories.TACTICALMISSILEPLATFORM + categories.SILO - categories.SUBCOMMANDER - categories.COMMAND + categories.xss0303 + categories.xss0202 + categories.xas0306 + categories.ues0202),
    --MISSILE = (categories.NUKE + categories.TACTICALMISSILEPLATFORM + categories.SILO - categories.SUBCOMMANDER - categories.COMMAND),
    ANTIAIR = categories.ANTIAIR,
    ANTINAVY = (categories.ANTINAVY + categories.ANTISUB + categories.xes0102 + categories.xrs0204 + categories.urs0203 ),
    --INTEL = (categories.RADAR + categories.OMNI + categories.SONAR + categories.OPTICS + categories.COUNTERINTELLIGENCE + categories.OVERLAYCOUNTERINTEL),
    INTEL = (categories.RADAR + categories.OMNI + categories.SONAR + categories.OPTICS + categories.SCOUT + categories.INTELLIGENCE + categories.OVERLAYCOUNTERINTEL),
    --DRONES = (categories.SUBCOMMANDER * categories.Pod) + categories.POD, 
    DRONES = categories.POD,
    --DRONESTATION = ((categories.SUBCOMMANDER * categories.Pod) + categories.POD + (categories.STRUCTURE * categories.ENGINEERSTATION)),
    COMMANDERS = (categories.SUBCOMMANDER + categories.COMMAND),
    MASS = (categories.MASSPRODUCTION + categories.MASSEXTRACTION + categories.MASSSTORAGE + categories.MASSFABRICATION),
    ENERGY = (categories.ENERGYPRODUCTION + categories.ENERGYSTORAGE),
    ENGINEERS = (categories.MOBILE * categories.ENGINEER ),
    
}
-- + categories.SILO
abilities.MISSILE = (categories.NUKE + categories.TACTICALMISSILEPLATFORM + categories.SILO)
abilities.MISSILENAVY = (abilities.MISSILE + categories.xss0303 + categories.xss0202 + categories.xas0306 + categories.ues0202)

local overlays = {}
overlays.iconSize = 26 
overlays.iconMargin = 5  
overlays.active = { } 

overlays.specs = { 
    { isActive = false, Strat = 'commander_generic',       ID = 'Commanders',  Name = 'Commanders', },
    { isActive = true, Strat = 'structure_mass',           ID = 'MEX', Name = 'Mass Extractors',  },
    { isActive = true, Strat = '3/land_engineer',         ID = 'EngineersT3', Name = 'T3 Engineers', },
    { isActive = true, Strat = '2/land_engineer',         ID = 'EngineersT2', Name = 'T2 Engineers', },
    { isActive = true, Strat = '1/land_engineer',         ID = 'EngineersT1', Name = 'T1 Engineers', },
    { isActive = false, Strat = '3/factory_generichq',     ID = 'FactoriesT3', Name = 'T3 Factories', },
    { isActive = false, Strat = '2/factory_generichq',     ID = 'FactoriesT2', Name = 'T2 Factories', },
    { isActive = false, Strat = '1/factory_generichq',     ID = 'FactoriesT1', Name = 'T1 Factories', },
    { isActive = true, Strat = '2/structure_missile',     ID = 'TML', Name = 'Tactical Missile Launchers',  },
    { isActive = true, Strat = '3/structure_missile',     ID = 'SML', Name = 'Strategic Missile Launchers',  },
    { isActive = true, Strat = '3/structure_antimissile', ID = 'SMD', Name = 'Strategic Missile Defenses',  },
    { isActive = true, Strat = '3/sub_missile',           ID = 'SMS', Name = 'Strategic Missile Submarines',  },
}

local filters = {}
filters.iconSize = 26 
filters.iconMargin = 5  
filters.size = 26
filters.columns = 12
filters.active = { } 
filters.all = { 

    { isActive = true, Strat = 'factory_generichq',  ID = 'Factories',   Categories = categories.FACTORY * categories.STRUCTURE - categories.MOBILE },
    { isActive = true, Strat = 'structure_engineer', ID = 'Engineer Stations', Categories = categories.ENGINEERSTATION + abilities.DRONES   },
    { isActive = false, Strat = 'structure_generic', ID = 'All Structures',   Categories = categories.STRUCTURE + abilities.DRONES },
    
    { isActive = true,  Strat = 'structure_energy',     ID = 'Energy Structures',     Categories = (categories.STRUCTURE * abilities.ENERGY - categories.SHIELD - abilities.MASS) },
    { isActive = true,  Strat = 'structure_mass',       ID = 'Mass Structures',       Categories = (categories.STRUCTURE * abilities.MASS - categories.SHIELD) },
    { isActive = true,  Strat = 'structure_shield',     ID = 'Shield Structures',    Categories = categories.STRUCTURE * categories.SHIELD },
    { isActive = true,  Strat = 'structure_intel',      ID = 'Intel Structures',     Categories = categories.STRUCTURE * abilities.INTEL + categories.MOBILESONAR },
    { isActive = true,  Strat = 'structure_antinavy',   ID = 'Anti-Navy Structures',  Categories = categories.STRUCTURE * abilities.ANTINAVY  },
    { isActive = true,  Strat = 'structure_antiair',    ID = 'Anti-Air Structures',   Categories = categories.STRUCTURE * abilities.ANTIAIR },
    { isActive = true,  Strat = 'structure_directfire', ID = 'Direct-Fire Structures', Categories = categories.STRUCTURE * abilities.DIRECTFIRE - abilities.MISSILE },
    { isActive = true,  Strat = 'structure_artillery',  ID = 'Artillery Structures',   Categories = categories.STRUCTURE * abilities.INDIRECTFIRE - abilities.MISSILE - categories.DIRECTFIRE},
    { isActive = false, Strat = 'structure_missile',    ID = 'Missile Structures',   Categories = categories.STRUCTURE * (abilities.MISSILE + categories.ANTIMISSILE)},

    { isActive = false, Strat = 'commander_generic', ID = 'Combat Engineers',   Categories = abilities.COMMANDERS  },
    { isActive = false, Strat = 'land_engineer',     ID = 'Civil Engineers',    Categories = abilities.ENGINEERS - abilities.COMMANDERS - abilities.DRONES },
    { isActive = false, Strat = 'land_generic',    ID = 'Land Units',   Categories = categories.MOBILE * categories.LAND  - abilities.ENGINEERS - abilities.COMMANDERS },
    { isActive = false, Strat = 'ship_generic',    ID = 'Naval Units',   Categories = categories.MOBILE * categories.NAVAL - categories.MOBILESONAR },
    { isActive = false, Strat = 'fighter_generic',    ID = 'Air Units', Categories = categories.MOBILE * categories.AIR   - abilities.DRONES },

    { isActive = false, Strat = 'experimental_generic',  ID = 'Tech-4 Units',   Categories = categories.MOBILE * categories.EXPERIMENTAL - abilities.ENGINEERS - abilities.COMMANDERS },
    { isActive = false, Strat = 'tech-3',  ID = 'Tech-3 Units',   Categories = categories.MOBILE * categories.TECH3 - abilities.ENGINEERS - abilities.COMMANDERS - categories.MOBILESONAR },
    { isActive = false, Strat = 'tech-2',  ID = 'Tech-2 Units',   Categories = categories.MOBILE * categories.TECH2 - abilities.ENGINEERS - abilities.COMMANDERS },
    { isActive = false, Strat = 'tech-1',  ID = 'Tech-1 Units',   Categories = categories.MOBILE * categories.TECH1 - abilities.ENGINEERS - abilities.COMMANDERS },
    
    { isActive = true,  Strat = 'dead_avatars', ID = 'Dead Structures/Units', hideDead = true, Categories = false  }, --categories.STRUCTURE + abilities.DRONES },
    
  --  { Strat = 'structure_engineer', ID = 'structure_engineer', Categories = (categories.STRUCTURE * categories.ENGINEERSTATION) + abilities.DRONES  },
  --  { Strat = 'commander_generic', ID = 'commanders', Categories = abilities.COMMANDERS },
  --  { Strat = 'structure_generic', ID = 'structures', Categories = categories.STRUCTURE   },
    
    
  --  { Strat = 'factory_naval',  ID = 'ship_factory',   Categories = categories.NAVAL * categories.FACTORY * categories.STRUCTURE - categories.MOBILE },
  --  { Strat = 'sub_generic',    ID = 'ship_sub',     Categories = categories.NAVAL * categories.MOBILE * categories.SUBMERSIBLE  },
  --  { Strat = 'ship_generic',    ID = 'ship_generic',   Categories = categories.NAVAL * categories.MOBILE - categories.STRUCTURE - categories.MOBILESONAR },
  --  { Strat = 'ship_directfire', ID = 'ship_directfire',Categories = categories.NAVAL * categories.MOBILE * abilities.DIRECTFIRE }, --  - abilities.ANTIAIR
  --  { Strat = 'ship_antiair',    ID = 'ship_antiair',   Categories = categories.NAVAL * categories.MOBILE * abilities.ANTIAIR - abilities.DIRECTFIRE },
  --  { Strat = 'ship_missile',    ID = 'ship_missile',   Categories = categories.NAVAL * categories.MOBILE * abilities.MISSILENAVY   },
  --  { Strat = 'ship_antinavy',    ID = 'ship_antinavy', Categories = categories.NAVAL * categories.MOBILE * abilities.ANTINAVY   },
  --  { Strat = 'ship_shield',    ID = 'ship_shield',     Categories = categories.NAVAL * categories.MOBILE * categories.SHIELD   },
  --  { Strat = 'ship_intel',    ID = 'ship_intel',       Categories = categories.NAVAL * categories.MOBILE * abilities.INTEL - abilities.DIRECTFIRE - abilities.ANTINAVY - abilities.MISSILENAVY - categories.MOBILESONAR },
     
  --  { Strat = 'factory_land',    ID = 'land_factory',   Categories = categories.LAND * categories.FACTORY * categories.STRUCTURE - categories.MOBILE },
  --  { Strat = 'bot_generic',     ID = 'land_bot',       Categories = categories.LAND * categories.MOBILE * categories.BOT  },
  --  { Strat = 'land_generic',    ID = 'land_generic',   Categories = categories.LAND * categories.MOBILE - categories.STRUCTURE  },
  --  { Strat = 'land_directfire', ID = 'land_directfire',Categories = categories.LAND * categories.MOBILE * abilities.DIRECTFIRE - abilities.COMMANDERS - abilities.ANTIAIR },
  --  { Strat = 'land_antiair',    ID = 'land_antiair',   Categories = categories.LAND * categories.MOBILE * abilities.ANTIAIR - abilities.COMMANDERS - abilities.DIRECTFIRE },
  --  { Strat = 'land_missile',    ID = 'land_missile',   Categories = categories.LAND * categories.MOBILE * abilities.MISSILE - abilities.COMMANDERS   },
  --  { Strat = 'ship_antinavy',   ID = 'land_antinavy',  Categories = categories.LAND * categories.MOBILE * abilities.ANTINAVY - abilities.COMMANDERS   },
  --  { Strat = 'land_shield',     ID = 'land_shield',    Categories = categories.LAND * categories.MOBILE * categories.SHIELD - abilities.COMMANDERS   },
  --  { Strat = 'land_intel',      ID = 'land_intel',     Categories = categories.LAND * categories.MOBILE * abilities.INTEL - abilities.COMMANDERS}, --  - abilities.DIRECTFIRE - abilities.ANTINAVY - abilities.MISSILENAVY - abilities.COMMANDERS   },
    
  --  { Strat = 'factory_air',        ID = 'air_factory',     Categories = categories.AIR * categories.FACTORY * categories.STRUCTURE },
  --  { Strat = 'gunship_generic',    ID = 'air_gunship',     Categories = categories.AIR * categories.MOBILE * categories.GROUNDATTACK  },
  --  { Strat = 'fighter_generic',    ID = 'air_generic',     Categories = categories.AIR * categories.MOBILE },
  --  { Strat = 'fighter_directfire', ID = 'air_directfire',  Categories = categories.AIR * categories.MOBILE * abilities.DIRECTFIRE - abilities.ANTIAIR },
  --  { Strat = 'fighter_antiair',    ID = 'air_antiair',     Categories = categories.AIR * categories.MOBILE * abilities.ANTIAIR - abilities.DIRECTFIRE },
  --  { Strat = 'fighter_bomber',     ID = 'air_missile',     Categories = categories.AIR * categories.MOBILE * abilities.MISSILE },
  --  { Strat = 'bomber_antinavy',    ID = 'air_antinavy',    Categories = categories.AIR * categories.MOBILE * abilities.ANTINAVY },
  --  { Strat = 'gunship_transport',  ID = 'air_shield',      Categories = categories.AIR * categories.MOBILE * (categories.SHIELD + categories.TRANSPORTATION) - categories.GROUNDATTACK},
  --  { Strat = 'fighter_intel',      ID = 'air_intel',       Categories = categories.AIR * categories.MOBILE * abilities.INTEL }, --  - abilities.DIRECTFIRE - abilities.ANTINAVY - abilities.MISSILENAVY - abilities.COMMANDERS   },
    

      --{ Strat = 'factory_land',  ID = 'factory_land', Categories = (categories.FACTORY * categories.LAND * categories.STRUCTURE - categories.MOBILE + categories.GATE) },
   -- { Strat = 'factory_land',  ID = 'factory_land', Categories = (categories.FACTORY * categories.LAND * categories.STRUCTURE - categories.MOBILE + categories.GATE) },
   
   -- { Strat = 'land_generic',       ID = 'LAND',   Categories = (categories.LAND  - categories.STRUCTURE - categories.ENGINEER )  },
   --{ Strat = 'ship_generic',       ID = 'NAVAL', Categories = (categories.NAVAL - categories.STRUCTURE - categories.ENGINEER) },
   --{ Strat = 'fighter_generic',    ID = 'AIR',   Categories = (categories.AIR - categories.STRUCTURE - categories.ENGINEER) },
   --
   --
}

GUI.setup.groups = {
    
    { Strat = 'commander_generic', Icon = 'amph', Tech = 'TECH3', Type = 'COMMANDERS', Categories = abilities.COMMANDERS },
    { Strat = 'land_engineer',     Icon = 'amph', Tech = 'TECH3', Type = 'ENGINEERS', Categories = (abilities.ENGINEERS - abilities.COMMANDERS - categories.ENGINEERSTATION - abilities.DRONES)  },
    --{ Strat = 'experimental_generic', Icon = 'amph', Tech = 'TECH4', Type = 'EXP', Categories = categories.EXPERIMENTAL * categories.MOBILE },
   
    { Strat = '1/land_generic', Icon = 'land', Tech = 'TECH1', Type = 'LAND', Categories = (categories.MOBILE * categories.LAND * categories.TECH1 - categories.ENGINEER) },
    { Strat = '2/land_generic', Icon = 'land', Tech = 'TECH2', Type = 'LAND', Categories = (categories.MOBILE * categories.LAND * categories.TECH2 - categories.ENGINEER) },
    { Strat = '3/land_generic', Icon = 'land', Tech = 'TECH3', Type = 'LAND', Categories = (categories.MOBILE * categories.LAND * (categories.TECH3 + categories.EXPERIMENTAL) - categories.ENGINEER) },

    { Strat = '1/ship_generic', Icon = 'sea',  Tech = 'TECH1', Type = 'NAVAL', Categories = (categories.MOBILE * categories.NAVAL * categories.TECH1 - categories.ENGINEER) },
    { Strat = '2/ship_generic', Icon = 'sea',  Tech = 'TECH2', Type = 'NAVAL', Categories = (categories.MOBILE * categories.NAVAL * categories.TECH2 - categories.ENGINEER) },
    { Strat = '3/ship_generic', Icon = 'sea',  Tech = 'TECH3', Type = 'NAVAL', Categories = (categories.MOBILE * categories.NAVAL * (categories.TECH3 + categories.EXPERIMENTAL) - categories.ENGINEER - categories.MOBILESONAR) },
    
    { Strat = '1/fighter_generic', Icon = 'air',  Tech = 'TECH1', Type = 'AIR', Categories = (categories.MOBILE * categories.AIR * categories.TECH1 - categories.ENGINEER) },
    { Strat = '2/fighter_generic', Icon = 'air',  Tech = 'TECH2', Type = 'AIR', Categories = (categories.MOBILE * categories.AIR * categories.TECH2 - categories.ENGINEER) },
    { Strat = '3/fighter_generic', Icon = 'air',  Tech = 'TECH3', Type = 'AIR', Categories = (categories.MOBILE * categories.AIR * (categories.TECH3 + categories.EXPERIMENTAL) - categories.ENGINEER) },
        
    { Strat = 'factory_land',   Icon = 'land', Tech = 'TECH1', Type = 'FACTORIES', Categories = (categories.FACTORY * categories.LAND * categories.STRUCTURE - categories.MOBILE + categories.GATE) },
    { Strat = 'factory_naval',  Icon = 'land', Tech = 'TECH1', Type = 'FACTORIES', Categories = (categories.FACTORY * categories.NAVAL * categories.STRUCTURE - categories.MOBILE) },
    { Strat = 'factory_air',    Icon = 'land', Tech = 'TECH1', Type = 'FACTORIES', Categories = (categories.FACTORY * categories.AIR * categories.STRUCTURE - categories.MOBILE) },
    --{ Strat = 'structure_engineer', Icon = 'land', Tech = 'TECH3', Type = 'DRONES', Categories = (categories.ENGINEERSTATION + categories.Pod + categories.POD - categories.SUBCOMMANDER - categories.ENGINEER )  },
    { Strat = 'structure_engineer', Icon = 'land', Tech = 'TECH3', Type = 'DRONES', Categories =  categories.ENGINEERSTATION + abilities.DRONES  },
    --{ Strat = 'structure_engineer', Icon = 'land', Tech = 'TECH3', Type = 'DRONES', Categories = ((categories.STRUCTURE * categories.ENGINEERSTATION) + (categories.SUBCOMMANDER * categories.Pod) + categories.POD)  },
    
    { Strat = 'structure_missile',    Icon = 'land', Tech = 'TECH3', Type = 'DEFENCE', Categories = categories.STRUCTURE * abilities.MISSILE + categories.ANTIMISSILE  },
    { Strat = 'structure_directfire', Icon = 'land', Tech = 'TECH3', Type = 'DEFENCE', Categories = categories.STRUCTURE * abilities.DIRECTFIRE + abilities.INDIRECTFIRE }, --- abilities.MISSILE - categories.ANTIMISSILE  },
    { Strat = 'structure_antiair',    Icon = 'amph', Tech = 'TECH3', Type = 'DEFENCE', Categories = categories.STRUCTURE * abilities.ANTIAIR   },
    { Strat = 'structure_antinavy',   Icon = 'amph', Tech = 'TECH3', Type = 'DEFENCE', Categories = categories.STRUCTURE * abilities.ANTINAVY  },
    
    { Strat = 'structure_shield', Icon = 'land', Tech = 'TECH3', Type = 'SHIELD', Categories = (categories.STRUCTURE * categories.SHIELD - categories.HYDROCARBON) },
    { Strat = 'structure_intel',  Icon = 'land', Tech = 'TECH3', Type = 'INTEL',  Categories = (categories.STRUCTURE * abilities.INTEL + categories.MOBILESONAR) },
    
    { Strat = 'structure_mass',    Icon = 'land', Tech = 'TECH3', Type = 'MASS',    Categories = (categories.STRUCTURE * abilities.MASS - categories.SHIELD) },
    { Strat = 'structure_energy',  Icon = 'land', Tech = 'TECH3', Type = 'ENERGY',  Categories = (categories.STRUCTURE * abilities.ENERGY - categories.SHIELD + categories.HYDROCARBON) },
    
    
    { Strat = 'structure_generic',  Icon = 'land', Tech = 'TECH1', Type = 'OTHER', AutoHide = true, Categories = categories.STRUCTURE * categories.WALL },
    
     -- + categories.FIELDENGINEER
    --{ Tech = 'TECH2', Type = 'BASE', Name = 'SHIELDS', Categories = categories.STRUCTURE * categories.SHIELD}),
    --{ Tech = 'TECH4', Type = 'EXPERIMENTAL', Categories = categories.EXPERIMENTAL },
  --- DEFENCES
    -- INTEL RADAR SONAR OMNI 
}
Factions = { 
    AEON        = categories.AEON, 
    UEF         = categories.UEF, 
    CYBRAN      = categories.CYBRAN, 
    SERAPHIM    = categories.SERAPHIM  
} 

function InitalizeSetup()
    local techIcons = {
        --TECH1 = UIUtil.UIFile('/game/avatar-engineers-panel/tech-1_bmp.dds'),
        --TECH2 = UIUtil.UIFile('/game/avatar-engineers-panel/tech-2_bmp.dds'),
        --TECH3 = UIUtil.UIFile('/game/avatar-engineers-panel/tech-3_bmp.dds'),
        --TECH4 = UIUtil.UIFile('/game/avatar-engineers-panel/tech-3_bmp.dds'),
        TECH1 = UIUtil.UIFile('/game/construct-tech_btn/t1_btn_up.dds'),
        TECH2 = UIUtil.UIFile('/game/construct-tech_btn/t2_btn_up.dds'),
        TECH3 = UIUtil.UIFile('/game/construct-tech_btn/t3_btn_up.dds'),
        TECH4 = UIUtil.UIFile('/game/construct-tech_btn/t4_btn_up.dds'),
    }
    local techNames = { TECH1 = 'T1', TECH2 = 'T2', TECH3 = 'T2', EXPERIMENTAL = 'T4'}
    local techs = { 'TECH1', 'TECH2', 'TECH3', 'TECH4'}
    local colors = { 
        LAND        = '4F2FF10D',  -- #4F2FF10D
        NAVAL       = '4F0DA8F1',  -- #4F0DA8F1
        AIR         = '78ECE9E9',  -- #78ECE9E9
        SHIELD      = '4F860DF1',  -- #4F9110D4
        INTEL       = '4F860DF1',  -- #4F9110D4
        FACTORIES   = '4F807A7A',  -- #4F9110D4
        DEFENCE     = '4FF10D0D',  -- #4FF10D0D
    }
     
    local row = 0
    for id, group in GUI.setup.groups do 
        group.Faction = 'CYBRAN'
        group.color = colors[group.Type] or '22282729'  -- #22282729
        group.icon  = techIcons[group.Tech]  
        group.isFiltered = false
        group.isMajor = true
        group.id = id --* 100
        group.Name  = group.Tech  .. ' ' .. group.Type

        if not group.SortBy then
            if group.Type == 'FACTORIES' or 
               group.Type == 'ENGINEERS' or 
               group.Type == 'DRONES' then
                group.SortBy = SortBy.ENGINEERING
            elseif group.Type == 'MASS' or 
                   group.Type == 'ENERGY' then
                group.SortBy = SortBy.ECO
            elseif group.Type == 'DEFENCE'  then
                group.SortBy = SortBy.WEAPON

            elseif group.Type == 'INTEL' or
                   group.Type == 'SHIELD' then
                group.SortBy = SortBy.SUPPORT
                
            elseif group.Type == 'COMMANDERS'  then
                group.SortBy = SortBy.UPGRADES
            else
                group.SortBy = SortBy.TECH
            end
        end
    end
    local groupCount = table.getsize(GUI.setup.groups)
    --LOG('--- UnitsFilter setup.groups ' .. groupCount  )

 --   for _, group in GUI.setup.groups do 
 --   
 --       if group.isMajor then
 --
 --           local sortId = 1
 --           for faction, category in Factions do 
 --               if faction ~= 'CYBRAN' then
 --                   local copy = table.copy(group)
 --                   copy.isMajor = false 
 --                   copy.id = copy.id + sortId
 --                   copy.Faction = faction
 --                   copy.Name = faction .. ' ' .. copy.Tech  .. ' ' .. copy.Type
 --                   copy.Categories = category * copy.Categories 
 --                   table.insert(GUI.setup.groups, copy)
 --                   sortId = sortId + 1
 --               end
 --           end  
 --           group.Categories = Factions[group.Faction] * group.Categories 
 --           group.Name  = group.Faction .. ' ' .. group.Tech  .. ' ' .. group.Type
 --       end
 --   end
    GUI.setup.inizalied = true
end

function CreateContainer()
    
    if not GUI.setup.inizalied then
        InitalizeSetup()
    end
    LOG('--- UnitsFilter CreateContainer avatars '  .. table.getsize(GUI.avatars) .. ' '  .. table.getsize(GUI.avatarsMap) ) 
    LOG('--- UnitsFilter CreateContainer groups  '  .. table.getsize(GUI.setup.groups))

    local clientArea = GUI.win:GetClientGroup()
    CreateOverlays(clientArea)
    CreateFilters(clientArea)

    GUI.scroll = Group(clientArea)
    GUI.scroll.Left:Set(function() return clientArea.Left() + 5 end)
    GUI.scroll.Top:Set(function() return clientArea.Top() + filters.bottom + 10 end)
    GUI.scroll.Right:Set(function() return clientArea.Right() - 20 end)
    GUI.scroll.Bottom:Set(function() return clientArea.Bottom() - 1 end)
    GUI.scroll.isUpdated = false
    GUI.scroll.Depth:Set(function() return clientArea.Depth() + 1 end)
    
    UpdateScroll(false)

    if GUI.scroll.groups then
        LOG('--- UnitsFilter scroll.groups ' .. table.getsize(GUI.scroll.groups))
    end

    GUI.scroll.groups = {}

    GUI.scrollbar = UIUtil.CreateLobbyVertScrollbar(GUI.scroll, 1, 0, -5, 10)
    --GUI.scrollbar.Depth:Set(function() return GUI.win.Depth() + 1 end)
    GUI.scrollbar.Depth:Set(function() return GUI.scroll.Depth() + 1 end)
    
    --GUI.scrollbar = UIUtil.CreateVertScrollbarFor(GUI.scroll, 1)
    GUI.scroll.top = 1
    GUI.scroll.range = nil 

    GUI.scroll.GetScrollMax = function(self)
    --TODO
        -- local max = 0  
        -- for index, group in ipairs(GUI.scroll.groups) do
        --     if not group:IsFiltered() then
        --         max = max + 1 --(group.rows or 1)
        --     end
        -- end
        return GUI.scroll.rowsMax or 1
        --return table.getsize(GUI.scroll.avatars) -- GUI.scroll.rows or 1
    end
    -- GetScrollValues called when the scrollbar for the control requires data to size itself, 
    -- GetScrollValues must return 4 values in this order: rangeMin, rangeMax, visibleMin, visibleMax
    -- axis can be "Vert" or "Horz"
    GUI.scroll.GetScrollValues = function(self, axis)
        local max = self:GetScrollMax()
        local bottom = math.min(self.top + GUI.scroll.rows, max)
        return 1, max, self.top, math.min(self.top + GUI.scroll.rows - 1, max)
        --return 0, max, self.top, math.min(self.top + GUI.scroll.rows, max)
    end

    -- called when the scrollbar wants to scroll a specific number of lines (negative indicates scroll up)
    GUI.scroll.ScrollLines = function(self, axis, delta)
        self:ScrollSetTop(axis, self.top + math.floor(delta))
    end
    
    -- called when the scrollbar wants to scroll a specific number of pages (negative indicates scroll up)
    GUI.scroll.ScrollPages = function(self, axis, delta)
        self:ScrollSetTop(axis, self.top + math.floor(delta) * GUI.scroll.rows)
    end
    
    -- called when the scrollbar wants to set a new visible top line
    GUI.scroll.ScrollSetTop = function(self, axis, top)
        top = math.floor(top)
        if top == self.top then return end
        local max = self:GetScrollMax()  --table.getsize(GUI.scroll.groups)
        self.top = math.max( math.min( max - GUI.scroll.rows + 1 , top), 1)
        self:CalcVisible()
    end

    -- called to determine if the control is scrollable on a particular access. Must return true or false.
    GUI.scroll.IsScrollable = function(self, axis)
        return true
    end

    -- determines what controls should be visible or not
    GUI.scroll.CalcVisible = function(self)
        local visible = {}
        GUI.isBusy = true
        GUI.scroll.isUpdated = true
        local top = self.top
        local bottom = self.top + GUI.scroll.rows
        local visibleIndex = 1
        for index, avatar in ipairs(GUI.avatars) do
            --TODO
            
            if avatar.isFiltered then
               avatar:Hide()
                visibleIndex = visibleIndex + 1
            elseif avatar.hideDead then
                --avatar:Hide() 
                 avatar:SetAlpha(0.2)
           
                visibleIndex = visibleIndex + 1 
            
            elseif avatar.gridRow < top or avatar.gridRow >= bottom then 
                --LOG('avatar Hide '  ..  avatar.gridRow .. ' top='  .. top .. ' bottom='  .. bottom )
    
                avatar:Hide() 
                visibleIndex = visibleIndex + 1 
            else
                --table.insert(visible, avatar.Name .. ' at ' .. visibleIndex .. ' ') 
                avatar:Show() 
                avatar:SetAlpha(1)
                --group.Left:Set(self.Left)
                --avatar.Right:Set(self.Right)
                local c = avatar
                local i = (avatar.gridRow  - top) * ( c.Height() + 2)
                --local i = avatar.gridRow
                --avatar.Top:Set(function() return self.Top() + ((i - top) * c.Height()) end)
                avatar.Top:Set(function() return self.Top() + i end)
                --avatar.Top:Set(function() return self.Top() + ((i - top) * c.Height()) end)
                visibleIndex = visibleIndex + 1
            end

        end 
        --LOG('scroll CalcVisible '  .. ' ' .. table.concat(visible) )
        GUI.isBusy = false
    end
    GUI.scroll.CalcVisibleOLD = function(self)
        local visible = {}
        GUI.isBusy = true
        GUI.scroll.isUpdated = true
        local top = self.top
        local bottom = self.top + GUI.scroll.rows
        local visibleIndex = 1
        for index, group in ipairs(GUI.scroll.groups) do
            if group:IsFiltered() then
                group:Hide()
            elseif visibleIndex < top or visibleIndex >= bottom then 
                group:Hide() 
                visibleIndex = visibleIndex + 1
                for _, avatar in group.avatars do
                    avatar:Hide()
                end
            else
                table.insert(visible, group.info.Name) 
                group:Show()
                for _, avatar in group.avatars do
                    avatar:Show()
                end
                --group.Left:Set(self.Left)
                group.Right:Set(self.Right)
                local i = visibleIndex
                local c = group
                group.Top:Set(function() return self.Top() + ((i - top) * c.Height()) end)
                visibleIndex = visibleIndex + 1
            end
        end 
        --LOG('scroll CalcVisible '  .. self:GetScrollMax() .. ' ' .. table.concat(visible) )
        GUI.isBusy = false
    end

    GUI.scroll.OnMouseWheel = function(self, rotation)
        local lines = 1
        if rotation > 0 then
            lines = -1
        end
        GUI.scroll:ScrollLines(nil, lines) 
    end

    GUI.scroll.OldHandleEvent = GUI.scroll.HandleEvent
    GUI.scroll.HandleEvent = function(self, event)
        --LOG('scroll event '  .. event.Type)
        
        if event.Type == "WheelRotation" then
            self:OnMouseWheel(event.WheelRotation)
        end
        return false
        --return HandleMouseWheel(event)
        -- if event.Type == "WheelRotation" then --and self:IsHidden() 
        --     import('/lua/ui/game/worldview.lua').ForwardMouseWheelInput(event)
        --     --LOG('WheelRotation GUI.scroll')
        --     return true
        -- else
        --     --return GUI.scroll.OldHandleEvent(self, event)
        -- end 
        -- --ForwardWorldView(event)
        -- return false
    end
    --local fill = Bitmap(GUI.scrollGroup)
    --fill:SetSolidColor('FF545353') -- #FF545353
    --LayoutHelpers.FillParent(fill, GUI.scrollGroup)
   
    -- GUI.scroll:DisableHitTest()
    
    --CreateGroups()
    AvatarsUpdate()

    UpdateScroll(true) 
end 

-- TODO remove
function ForwardWorldView(event)
    local viewLeft  = import('/lua/ui/game/worldview.lua').viewLeft
    local viewRight = import('/lua/ui/game/worldview.lua').viewRight
    if viewLeft then 
        --LOG('viewLeft event .. ' .. event.Type)
        if event.Type == "WheelRotation" then --and self:IsHidden() 
            --import('/lua/ui/game/worldview.lua').ForwardMouseWheelInput(event)
            --LOG('WheelRotation GUI.scroll')
            --return true
            --viewLeft:HandleEvent(event)
            if viewLeft and viewLeft:HitTest(event.MouseX, event.MouseY) then
                viewLeft:ZoomScale(event.MouseX, event.MouseY, event.WheelRotation, event.WheelDelta)
            elseif viewRight and viewRight:HitTest(event.MouseX, event.MouseY) then
                viewRight:ZoomScale(event.MouseX, event.MouseY, event.WheelRotation, event.WheelDelta)
            end
        else
            --viewLeft:HandleEvent(event)            
            --return GUI.scroll.OldHandleEvent(self, event)
        end
    end
end

function GetSymbolImage(imgName)

    local iconPath = modTextures..'symbols/' .. imgName .. '.dds'
    if DiskGetFileInfo(iconPath) then
            return iconPath
    end 
end 
--overlays.iconSize = 30

function CreateOverlay(parent, info)

    local max = overlays.iconSize - overlays.iconMargin
    local img = import(modScripts..'UnitAvatar.lua').GetStratImage(nil, info.Strat) 
    local w, h = import(modScripts..'UnitAvatar.lua').GetStratSize(img, max) 

    local button = Bitmap(parent)
    button.Height:Set(overlays.iconSize + overlays.iconMargin)
    button.Width:Set(overlays.iconSize) 
    button.info = info 
    button.isActive = info.isActive 
    button:EnableHitTest()

    button.icon = Bitmap(button) 
    button.icon:SetTexture(img) 
    button.icon.Height:Set( h )
    button.icon.Width:Set( w ) 
    button.icon:DisableHitTest()
    LayoutHelpers.AtHorizontalCenterIn(button.icon, button)
    if w < h then
        LayoutHelpers.AtTopIn(button.icon, button, 1)
    else
        LayoutHelpers.AtVerticalCenterIn(button.icon, button, 0)
    end

    button.hover = Bitmap(button) --, img)
    button.hover:SetSolidColor('00727171') --#00727171
    button.hover:DisableHitTest()
    LayoutHelpers.FillParent(button.hover, button)

    button.Toggle = function(self, isActive)
        self.isActive = isActive
        if self.isActive then 
             button:SetSolidColor('E13E3E3E') --#E13E3E3E
             overlays.active[self.info.ID] = true
         else
             button:SetSolidColor('E1B63415') --#E1B63415
             overlays.active[self.info.ID] = nil
        end
        local UnitsOverlays = import(modScripts..'UnitsOverlays.lua').GUI
        if UnitsOverlays and UnitsOverlays.options then
           UnitsOverlays.options.show[self.info.ID] = isActive
        end
    end

    button.HandleEvent = function(self, event)
       if event.Type == 'WheelRotation' then 
           return false
       elseif event.Type == 'MouseEnter'  then 
           self.hover:SetSolidColor('96646464') --#96646464
           --return false
       elseif event.Type == 'MouseExit' then 
           self.hover:SetSolidColor('00727171') --#00727171
           --return false
       elseif event.Type == 'ButtonPress' then
          self:Toggle(not self.isActive)
          return true
       end  
       return true
    end
    local tooltip = {text = info.Name, 
    body = 'Toggle overlays rendered over ' .. info.Name}
    Tooltip.AddControlTooltip(button, tooltip)

    button:Toggle(info.isActive)
    return button
end

function CreateOverlays(parent)
    local x = 4 
    local y = 10
    local c = 0
    overlays.bottom = 0
    for i, info in overlays.specs do
        local toggle = CreateOverlay(parent, info)
        x = ((overlays.iconSize + 2) * c) + 5
        --y = (overlays.iconSize) --+ 10
        c = c + 1
        LayoutHelpers.AtRightTopIn(toggle, parent, x, y)
        table.insert(GUI.overlays, toggle)
    end 
    overlays.bottom = y + overlays.iconSize + overlays.iconMargin 
end

function CreateFilter(parent, info)

    local max = filters.iconSize - filters.iconMargin
    local img = GetSymbolImage(info.Strat) 
    local w, h = import(modScripts..'UnitAvatar.lua').GetStratSize(img, max) 

    local filter = Bitmap(parent)
    filter.isActive = info.isActive 
    filter.ID = info.ID
    filter.Height:Set(filters.iconSize + filters.iconMargin)
    filter.Width:Set(filters.iconSize) 
    filter:EnableHitTest()

    filter.icon = Bitmap(filter)
    filter.icon:SetTexture(img)
    filter.icon.Height:Set(h)
    filter.icon.Width:Set(w) 
    filter.icon:DisableHitTest()
    LayoutHelpers.AtHorizontalCenterIn(filter.icon, filter)
    if w < h then
        LayoutHelpers.AtTopIn(filter.icon, filter, 1)
    else
        LayoutHelpers.AtVerticalCenterIn(filter.icon, filter, 0)
    end

    filter.hover = Bitmap(filter) --, img)
    filter.hover:SetSolidColor('00727171') --#00727171
    filter.hover:DisableHitTest()
    LayoutHelpers.FillParent(filter.hover, filter)

    filter.Toggle = function(self, isActive)
        self.isActive = isActive
        if self.isActive then 
             filter:SetSolidColor('E1B63415') --#E1B63415
             filters.active[self.ID] = info
         else
             filter:SetSolidColor('E13E3E3E') --#E13E3E3E
             filters.active[self.ID] = nil
        end
    end
    filter.HandleEvent = function(self, event)
       if event.Type == 'WheelRotation' then 
           return false
       elseif event.Type == 'MouseEnter'  then 
           filter.hover:SetSolidColor('96B3B3B3') --#96B3B3B3
       elseif event.Type == 'MouseExit' then 
           filter.hover:SetSolidColor('00727171') --#00727171
       elseif event.Type == 'ButtonPress' then
          self:Toggle(not self.isActive)
          AvatarsRefresh()
          return true
       end
       return true
    end
    local tooltip = {text = info.ID, 
    body = 'Toggle avatars representing ' .. info.ID .. ' in this window'}
    Tooltip.AddControlTooltip(filter, tooltip)

    filter:Toggle(filter.isActive)
    return filter
end

function CreateFilters(parent)

    local x = 0
    local y = 0
    local r = 0
    local c = 0

    --local testBtn = UIUtil.CreateButtonWithDropshadow(parent, '/BUTTON/medium/', "T")
    --testBtn.Width:Set(20)
    --testBtn.OnClick = function()
    --    --GUI.isBusy = true
    --    --import(modScripts..'UnitsTracker.lua').TestUnitStats(armyUnits)
    --    --GUI.isBusy = false
    --    --local c = GetCamera('WorldCamera')
    --    --LOG(c:GetTargetZoom() .. ' GetTargetZoom')
    --    --LOG(c:GetMaxZoom().. ' GetMaxZoom')
    --    --LOG(c:GetMinZoom().. ' GetMinZoom')
    --    --LOG(c:GetZoom().. ' GetZoom')
    --    import('/lua/ui/game/avatars.lua').ToggleAvatars(false)
    --end
    --LayoutHelpers.AtLeftIn(testBtn, parent, -30)
    --LayoutHelpers.AtTopIn(testBtn, parent, 7)


    local rows = table.getsize(filters.all) / filters.columns
    rows = rows + 1
    --rows = math.floor(rows + 0.5) 
    filters.height = rows * filters.size
    filters.top = overlays.bottom + 20
    filters.bottom = 0
    --for id, group in GUI.setup.groups do
    for i, info in filters.all  do

        local filter = CreateFilter(parent, info)
        if c >= filters.columns then 
            c = 0
            r = r + 1  
        end
        --LayoutHelpers.AtLeftIn(filter.icon, filter, 0)
        x = (c * (filters.iconSize + 2)) + 5
        y = (r * (filters.iconSize + 2 + filters.iconMargin)) + filters.top
        c = c + 1
        --filter.Right:Set(function() return GUI.scroll.Right() - 5 end)
        LayoutHelpers.AtRightTopIn(filter, parent, x, y)
        table.insert(GUI.filters, filter)
    end 
    filters.bottom = y + filters.iconSize + filters.iconMargin
end 

function CreateGroups()
    local top = 4

    for id, info in GUI.setup.groups do
    
        local group = Group(GUI.scroll)
        group.avatars = {}
        group.avatarsMap = {}
        group.units = {}
        group.unitsCount = 0
        group.info = info
        group.row = id -- TODO remove
        group.IsFiltered = function(self) return self.unitsCount == 0 end
        if not group.partent then
  
        end
        group.HandleEvent = function(self, event)
            if event.Type == 'WheelRotation' then
                local lines = 1
                if event.WheelRotation > 0 then
                    lines = -1
                end
                GUI.scroll:ScrollLines(nil, lines)
                return true
            end
            return false
        end
        --group.Left:Set(function() return GUI.scroll.Right() - 30 - (GUI.options.unitWidth * table.getsize(group.units)) end)
        group.Left:Set(function()  return GUI.scroll.Right() - GUI.options.groupWidth end)
        --group.Left:Set(function()  return GUI.scroll.Left() + 4 end)
        --group.Right:Set(function() return clientArea.Right() - 5 end)
        group.Height:Set(GUI.options.unitSize + 2)
        --group.Width:Set(42)
        LayoutHelpers.AtRightTopIn(group, GUI.scroll, 4, top)
        top = top + GUI.options.unitSize + 1
  
        group.Fill = Bitmap(group)
        --group.Fill:SetSolidColor('6B545353') -- #6B545353
        group.Fill:SetSolidColor(group.info.color) -- #6B545353
        LayoutHelpers.FillParent(group.Fill, group)
        
        group.counter = UIUtil.CreateText(group, '0', GUI.options.counterFontSize, GUI.options.counterFontName)
        group.counter:SetColor('DBE7E0DF') --#DBE7E0DF
        group.counter:SetDropShadow(true)
        --group.counter.Depth:Set(20)
        --group.counter:EnableHitTest()
        --group.counter.Width:Set(GUI.options.groupWidth)
  
        LayoutHelpers.AtRightIn(group.counter, group, 2)
        LayoutHelpers.AtVerticalCenterIn(group.counter, group)
        
        local tooltip = {text = group.info.Name, body = ' TODO ' }
        Tooltip.AddControlTooltip(group, tooltip)
        
        group.config = table.copy(GUI.options)
        group.config.showUnitMinHealthBar = false
        group.config.showUnitAvgHealthBar = false
        group.config.showUnitIcon = false
        group.config.unitStratIconRatio = .7
        group.config.unitWidth = 35
  
        group.symbol = import(modScripts .. 'UnitAvatar.lua').CreateUI(group, group.config)
        LayoutHelpers.AtRightIn(group.symbol, group, 40)
        LayoutHelpers.AtVerticalCenterIn(group.symbol, group)
        
        --group.tooltip = 'right click - zoom to the unit\n' ..
        --                'double click - select all units\n' .. 
        --                'single click - toggle between units starting from a unit with lowest health\n'
                        
        table.insert(GUI.scroll.groups, group) 
         
    end
end
function GetGroupId(unit)

    for i, group in GUI.setup.groups do
        if EntityCategoryContains(group.Categories, unit) then
            return group.id
        end
    end
    -- default to last group
    return table.getsize(GUI.setup.groups) --   -1
end
function GetSortBy(unit)
    --if EntityCategoryContains((categories.ENGINEER + categories.FACTORY), unit) then
    --    return 'idle'
    --end
    if unit.canEngineer then
        return 'idle'
    end
    return nil
end
function GetFilters(unit)

    local matches = {}

    for i, filter in filters.all do
        if filter.Categories and EntityCategoryContains(filter.Categories, unit) then
            matches[filter.ID] = true
        end
    end 
    return matches
end

function AvatarsFilter()
    GUI.isBusy = true
    for i, avatar in GUI.avatars do 
        
        local status = false
        --avatar:Filter(false)
            -- avatar.isFiltered = false
        avatar.hideDead = false

        for fid, filter in filters.active do 

            --LOG('filter ' .. fid .. ' ' .. tostring(filter.hideDead ) .. ' ' .. avatar.unitsCount)

            if filter.hideDead and avatar.unitsCount == 0 then
                avatar.hideDead = true
                status = true
                --avatar:Filter(true) 
                --LOG('filter  ' .. fid .. ' hide')
                break
            elseif avatar.filters[fid] then
                status = true
                -- avatar:Filter(true) 
                break 
            end 
        end

        if avatar.isFilter ~= status then
            GUI.isChanged = true
        end
        avatar:Filter(status) 
    end
    --GUI.isChanged = true
end

function AvatarsSort()

    if not GUI.isChanged then return end
    GUI.isBusy = true
    --LOG('avatar Sorting ' .. table.getsize(GUI.avatars))
    -- for i, avatar in GUI.avatars do 
    --     LOG('avatar Sorting before '  .. avatar.gid .. ' '  .. avatar.Tech .. ' '  .. avatar.Faction .. ' ' .. avatar.Name)
    --     --table.insert(order, avatar.Name ) 
    -- end

    --local sortCurrent = ''
    --for i, avatar in GUI.avatars do 
    --    sortCurrent = sortCurrent .. ', ' .. avatar.uid .. '_' .. avatar.unitsCount 
    --end

    table.sort(GUI.avatars, function(a,b) 

        if a.isFiltered and b.isFiltered then
            --return a.uid < b.uid 
            if a.gid ~= b.gid then
                return a.gid < b.gid 
            else
                return a.uid < b.uid 
            end
        elseif a.isFiltered and not b.isFiltered then
            return false 
        elseif not a.isFiltered and b.isFiltered then
            return true 
        elseif a.gid ~= b.gid then 
            return a.gid < b.gid 
        else
            -- avatars without units on the left
            if a.unitsCount == 0 and b.unitsCount == 0 then
                return a.uid < b.uid 
            -- avatars with units on the right
            elseif a.unitsCount > 0 and b.unitsCount > 0 then
                 if a.Faction ~= b.Faction then 
                     return a.Faction >= b.Faction 
                 else
                    local order = import(modScripts .. 'UnitsSorter.lua').CompareOrder(a,b, a.SortBy, true)
    -- LOG('avatar Sorting order '  .. a.uid .. ' '  .. a.Tech .. ' '  .. a.Faction .. ' ' .. a.Name.. ' = ' .. table.concatkeys(a.CategoriesHash))
    -- LOG('avatar Sorting order '  .. b.uid .. ' '  .. b.Tech .. ' '  .. b.Faction .. ' ' .. b.Name.. ' = ' .. table.concatkeys(b.CategoriesHash))

                    if order ~= 0 then
                        return order
                    else
                        return a.uid < b.uid 
                    end
                 end  
            else 
                return a.unitsCount > b.unitsCount
            end 
        end
    end)
    
    local sortNew = ''
    for i, avatar in GUI.avatars do 
        sortNew = sortNew .. ', ' .. avatar.uid .. '_' .. avatar.unitsCount 
    end

    --if sortNew ~= sortCurrent then
    --    LOG('avatar Sorting changed \n' .. sortCurrent .. '\n' ..  sortNew)
    --    LOG('armyUnits ' .. table.getsize(armyUnits))
    --    local list = ''
    --    for i, unit in armyUnits do 
    --        LOG('armyUnits ' ..  tostring(unit.id) .. ' ' .. tostring(unit.Name) .. ' ' .. tostring(unit.isBuilt) .. ' ' .. tostring(unit.isInitialized) )
    --        --list = list .. '  ' .. unit.uid .. '_' .. unit.Name  .. '\n '
    --    end
    --
    --   -- LOG('avatar Sorting changed \n' .. sortCurrent .. '\n' ..  sortNew.. '\n' ..  list)
    --end

    GUI.isBusy = false
    --GUI.avatars = table.reverse(GUI.avatars)

    -- for i, avatar in GUI.avatars do 
    --     LOG('avatar Sorting after ' .. avatar.gid .. ' '  .. avatar.Tech .. ' '  .. avatar.Faction .. ' '  .. avatar.Name)
    -- end
end

function AvatarsArrange()
    
    if not GUI.isChanged then return end
    GUI.isBusy = true
    --LOG('avatar Arranging ' .. table.getsize(GUI.avatars))
        
      --local avatarsCount = table.getsize(group.avatars)
     --group.rows = 1
     --if avatarsCount > GUI.scroll.columns then
     --   group.rows = math.floor(avatarsCount / GUI.scroll.columns) + 1
     --   LOG('rows ' .. group.rows .. ' height ' .. (group.rows * GUI.options.unitSize ) )
     --end 
     --local height = group.rows * GUI.options.unitSize 
     --group.Height:Set(height + 1)
     local x = 0
     local y = 0
     local row = 0
     local col = 0
     local i = 1
     for _, avatar in GUI.avatars do 
       
        --if not avatar.isFiltered then
            if (i > 1 and avatar.gid ~= GUI.avatars[i-1].gid) or 
               (col > 0 and col >= GUI.scroll.columns) then
                --LOG('group Arranging '  ..  row .. ','  .. col .. ' new group '   )
                col = 0
                row = row + 1
             end

             --x = col * (GUI.options.unitWidth +1)
             x = col * (GUI.options.unitSize + 8)
             y = row * GUI.options.unitSize
         -- .. x .. ','  .. y 
             -- LOG('group Arranging '  .. row .. ','  .. col .. ' - ' .. avatar.group .. ' - '  ..  avatar.uid   .. ' - ' .. avatar.Name )
         
             LayoutHelpers.AtRightIn(avatar, GUI.scroll, x + GUI.options.groupWidth) -- GUI.options.groupWidth + 
             --LayoutHelpers.AtRightIn(avatar, GUI.scroll, x + 5) -- GUI.options.groupWidth + 
             LayoutHelpers.AtTopIn(avatar, GUI.scroll, y)
             avatar.gridRow = row + 1 
             avatar.gridCol = col + 1

             col = col + 1
             
             i = i + 1
        --end
         
     end

     GUI.scroll.rowsMax = row + 1
     GUI.isBusy = false
end

function AvatarsReset()
    
    for _, avatar in GUI.avatars do 
        -- avatar.unitsNew = {}
        avatar.isChanged = false
        for eid, unit in avatar.hash do 
            
            if unit then
                if unit:IsDead() then
                   avatar.isChanged = true
                   avatar.hash[eid] = nil
                end
                if (unit.isUpgrading and not avatar.isUpgrading) or
                   (not unit.isUpgrading and avatar.isUpgrading) then
                   avatar.isChanged = true
                   avatar.hash[eid] = nil
                end
            end
            
        end
    end
end

function AvatarsUpdate()

    if GUI.isBusy then return end
    
    --LOG('AvatarsUpdate ')
    --Timer.Start()

    AvatarsReset()

    --  TODO pass unit filters    
    armyUnits = import(modScripts .. 'UnitsTracker.lua').GetUnits()
    for _, unit in armyUnits do 
        local uid = unit.id
        local eid = unit.eid
        local isUpgrading = false

        if unit.isUpgrading then
            uid = uid .. '_up'
        end
        if not GUI.avatarsMap[uid] and unit.isBuilt then
            local avatar = import(modScripts .. 'UnitAvatar.lua').CreateUI(GUI.scroll, GUI.options)

            avatar.gid = GetGroupId(unit)
            avatar.sortBy = GetSortBy(unit)
            avatar.group = GUI.setup.groups[avatar.gid].Name or '?'
            avatar:Initialize(unit, uid)
            avatar.isChanged = true
            avatar.isUpgrading = unit.isUpgrading
            avatar.isMissleSilo = unit.isMissleSilo
            avatar.filters = GetFilters(unit)
            avatar.hash = {}
            avatar.hash[eid] = unit
             
  --  LOG('avatar Initialize '  .. avatar.gid   .. ' <-- '  ..  unit.Name  .. ' ' .. unit.id  .. ' ' .. table.concatkeys(avatar.CategoriesHash, ' '))

            if avatar.gid == -1 then
                LOG('--- UnitsFilter avatar is MISSING group id ' .. uid .. ' ' .. unit.Name)
            else
                avatar.SortBy = GUI.setup.groups[avatar.gid].SortBy
            end

            table.insert(GUI.avatars, avatar)
            GUI.avatarsMap[uid] = avatar
        end
        
        --if GUI.avatarsMap[uid].gid == -1 then
        --    LOG('avatar is missing group id ' .. uid .. ' ' .. unit.Name)
        --end

        if unit.isBuilt and GUI.avatarsMap[uid] and 
                        not GUI.avatarsMap[uid].isFiltered and
                        not GUI.avatarsMap[uid].hash[eid] then
           GUI.avatarsMap[uid].hash[eid] = unit
           GUI.avatarsMap[uid].isChanged = true 
           -- LOG('avatarsMap changed ' .. GUI.avatarsMap[uid].Name .. ' hash=' .. table.getsize(GUI.avatarsMap[uid].hash) )

            --LOG('avatar hashing unit ' .. uid .. ' ' .. unit.Name .. ' ' .. eid .. ' ' .. GUI.avatarsMap[uid].group)
        end
    end
     
    for _, avatar in GUI.avatars do 
        -- avatar.unitsNew = {}
        if not avatar.isFiltered then
            avatar:UpdateHash()

            if avatar.isChanged then 
               GUI.isChanged = true
               --LOG('avatar changed ' .. avatar.Name .. ' hash=' .. table.getsize(avatar.hash) )
            end
        end
    end

    --AvatarsSort()
    --AvatarsArrange()
    AvatarsRefresh()
    --LOG(' --- units filter '  .. table.getsize(armyUnits) .. Timer.Stop()) 

end
 
function AvatarsRefresh()
    
       AvatarsFilter()
    if GUI.isChanged then
       GUI.isBusy = true
        --LOG('avatar Refresh ' .. table.getsize(GUI.avatars))
       AvatarsSort()
       AvatarsArrange()
       GUI.isChanged = false
       GUI.scroll:CalcVisible()
       GUI.isBusy = false
    end
end
function UpdateGroupsOLD()

  --  for gid, group in GUI.scroll.groups do 
  --
  --      group.unitsNew = FilterUnits(group.info.Categories, armyUnits) 
  --      
  --      local newCount = table.getsize(group.unitsNew)
  --      group.unitsChanged = newCount ~= group.unitsCount 
  --      group.unitsCount = newCount
  --      group.counter:SetText(group.unitsCount)
  --      --group.symbol.units = group.unitsNew
  --      --group.symbol.unitsCount = newCount
  --
  --      if not group.symbol.isReady and newCount > 0 then
  --         group.symbol:Initialize(group.unitsNew[1], group.info.Icon, group.info.Strat)
  --      end
  --      group.symbol:Update(group.unitsNew)
  --
  --      if group.unitsChanged and
  --         group.unitsCount <= 1 then  
  --         GUI.scroll.isUpdated = false
  --         LOG('group Activating '  .. group.info.Name )
  --      end
  --
  --      for _, unit in group.unitsNew do 
  --           
  --          if not group.avatarsMap[unit.id] then
  --           
  --              
  --              local avatar = import(modScripts .. 'UnitAvatar.lua').CreateUI(group, GUI.options)
  --              --avatar:Initialize(unit, group)
  --              group.avatarsMap[unit.id] = avatar
  --              group.avatarsMap[unit.id]:Initialize(unit)
  --              group.isArranged = false
  --              group.isSorted = false 
  --              table.insert(group.avatars, avatar)
  --
  --          end 
  --           
  --          table.insert(group.avatarsMap[unit.id].unitsNew, unit)
  --      end  
  --      
  --      for _, avatar in group.avatars do
  --          local units = group.avatarsMap[avatar.uid].unitsNew  
  --
  --          group.avatarsMap[avatar.uid]:Update(units)
  --          if group.avatarsMap[avatar.uid].unitsChanged and
  --             group.avatarsMap[avatar.uid].unitsCount <= 1 then  
  --             group.isSorted = false
  --             group.isArranged = false
  --          end
  --      end
  --       
  --      if not group.isSorted and group.unitsCount > 0 then
  --          -- sort avatars by number of units and unit type
  --          LOG('group Sorting '  .. group.info.Name)
  --          group.isSorted = true
  --          table.sort(group.avatars, function(a,b) 
  --              --local aUnits = table.getsize(a.unitsCount) -- unitsCount
  --              --local bUnits = table.getsize(b.unitsCount)
  --              -- avatars without units on the left
  --              if a.unitsCount == 0 and b.unitsCount == 0 then
  --
  --                  return a.uid >= b.uid 
  --              -- avatars with units on the right
  --              elseif a.unitsCount > 0 and b.unitsCount > 0 then
  --                   
  --                  if a.Faction ~= b.Faction then 
  --                      return a.Faction >= b.Faction 
  --                  else
  --                      if a.Tech ~= b.Tech then 
  --                          return a.Tech >= b.Tech 
  --                      else
  --                          if a.isPreset and not b.isPreset then
  --                              return true 
  --                          elseif b.isPreset and not a.isPreset then
  --                              return false 
  --                          else
  --                              return a.uid >= b.uid 
  --                          end 
  --                      end  
  --                  end  
  --              else 
  --                  return a.unitsCount > b.unitsCount
  --              end 
  --          end)
  --      end
  --               
  --      if not group.isArranged and group.unitsCount > 0 then
  --          ArrangeGroup(group)
  --      end 
  --  end
  --
  --  if not GUI.scroll.isUpdated then
  --     GUI.scroll:CalcVisible()
  --  end
    --
    
end
function ArrangeGroup(group)
    if not group then return end

     -- arrange avatars by their sort index
     --LOG('group Arranging '  .. group.info.Name )
     group.isArranged = true
     --local avatarsCount = table.getsize(group.avatars)
     --group.rows = 1
     --if avatarsCount > GUI.scroll.columns then
     --   group.rows = math.floor(avatarsCount / GUI.scroll.columns) + 1
     --   LOG('rows ' .. group.rows .. ' height ' .. (group.rows * GUI.options.unitSize ) )
     --end 
     --local height = group.rows * GUI.options.unitSize 
     --group.Height:Set(height + 1)

     for index, avatar in group.avatars do 
         if index == 1 then
             LayoutHelpers.AtRightTopIn(avatar, group, GUI.options.groupWidth, 2)
         --elseif index > GUI.scroll.columns then
         --    LayoutHelpers.Below(avatar, group.avatars[index - GUI.scroll.columns], 1)
         else 
             LayoutHelpers.LeftOf(avatar, group.avatars[index-1], 1)
             --LayoutHelpers.RightOf(avatar, group.avatars[index-1], 2)
         end 
     end
end

function ArrangeGroups()
    for gid, group in GUI.scroll.groups do 
        ArrangeGroup(group)
    end
end

function UpdateScroll(autoScroll)
    local scrollTop = GUI.scroll.Top() + 1  
    local scrollBottom = GUI.scroll.Bottom() + 1  
    local scrollHeight = scrollBottom - scrollTop - 5
    local scrollRows = math.floor(scrollHeight / (GUI.options.unitSize ))
    --LOG('scroll Height ' .. tostring(scrollHeight) .. ' scrollPerPage ' .. GUI.scroll.rows .. ' auto ' .. tostring(autoScroll))
     
     local scrollLeft = GUI.scroll.Left() + 1  
     local scrollRight = GUI.scroll.Right() + 1  
     local scrollWidth = scrollRight - scrollLeft - GUI.options.groupWidth
     
     local scrollColumns = math.floor(scrollWidth / (GUI.options.unitSize + 10 ))
     --LOG('scroll width ' .. tostring(scrollWidth) .. ' columns ' .. GUI.scroll.columns)
       
     if GUI.scroll.columns ~= scrollColumns then
        GUI.scroll.columns = scrollColumns
        -- ArrangeGroups()
        GUI.isChanged = true
        --LOG('scroll Width ' .. tostring(scrollHeight) .. ' colsMax ' .. scrollColumns)
     end

    if GUI.scroll.rows ~= scrollRows then
       GUI.scroll.rows = scrollRows
       GUI.isChanged = true
        --LOG('scroll Height ' .. tostring(scrollHeight) .. ' rowsMax ' .. scrollRows)
    end

    if autoScroll and GUI.isChanged then
        --GUI.scroll:CalcVisible()
        GUI.scroll:ScrollSetTop(nil,2)
        GUI.scroll:ScrollSetTop(nil,1)
    end
end

function CreateConfigControls()

    GUI.config.controls = {}

end

local Configurator = import(modScripts .. 'Configurator.lua')

function CloseConfigWindow()

    Configurator.CloseUI()
    --import(modScripts .. 'Configurator.lua').CloseUI()

  --  if GUI.config then
  --
  --      if GUI.config.controls then
  --
  --          for key, control in GUI.config.controls or {} do
  --              if control then
  --                  control:Destroy() 
  --              end
  --          end 
  --          GUI.config.controls = false
  --      end
  --
  --     GUI.config:Destroy()
  --     GUI.config = false
  --  end
end

function CreateConfigWindow()
    --GUI.isBusy = true
    
    Configurator.CreateUI(GUI.specs, GUI.options)
    --import(modScripts .. 'Configurator.lua').CreateUI(GUI.specs, GUI.options)
     
  --  CloseConfigWindow()
  --
  --  GUI.config = SupremeWindow(GetFrame(0), 'SUI - Unit Filter - Options', 
  --   --icon, pin, config, locl,
  --      -- nil, nil, nil, nil, nil, 'sui_filer_config', nil, nil, nil)
  --     --nil, true, true, nil, nil, 'sui_filer_config', nil, windowTextures, nil)
  --     nil, nil, nil, nil, nil, 'sui_filer_config', nil, nil, nil)
  --
  --  GUI.config:SetWindowAlpha(1)
  --  GUI.config:SetBackgroundAlpha(1)
  --  GUI.config:SetMinimumResize(350, 200)
  --  
  --  GUI.config.Depth:Set(function() return GUI.win.Depth() + 100 end)
  --
  --  GUI.config.OnClose = function(self)  
  --      -- TODO apply options
  --      CloseConfigWindow()
  --      
  --  end
  --
  --  GUI.config.OnResizeSet = function(control)
  --   
  --  end
  --  GUI.config.OnMouseWheel = function(control, event) 
  --      return HandleMouseWheel(event)
  --  end

end

function HandleMouseWheel(event)
    --if event.Type == "WheelRotation" then --and self:IsHidden() 
    --    import('/lua/ui/game/worldview.lua').ForwardMouseWheelInput(event)
    --    --LOG('WheelRotation GUI.win')
    --    return true
    --end
    return false
end

function CreateUI(parent)
    GUI.parent = parent
    LOG('--- UnitsFilter CreateUI '  .. table.getsize(GUI.avatars) .. ' '  .. table.getsize(GUI.avatarsMap) )
        
    if GUI.win then
        CloseUI() 
    end
    GUI.win = CreateMainWindow()

    GUI.win.OnClose = function(self)  
        CloseUI()
    end
    
    --if GUI.win.options.configured then
    --    TogglePulsing(GUI.win._configBtn, true, true, false) 
    --else
    --    TogglePulsing(GUI.win._configBtn, true, true, true) 
    --end
 
     --GUI.win:ApplyWindowOpacity(settings)
     
       -- GUI.win:SetAlpha(.25, true)
       
    GUI.avatars = {}
    GUI.avatarsMap = {}
    GUI.isBusy = false
    GUI.isChanged = true
    
    CreateContainer()

    import(modScripts .. 'UnitsOverlays.lua').CreateUI()
    GameMain.AddBeatFunction(AvatarsUpdate, true, 'AvatarsUpdate')

    GUI.win.OnConfigClick = function(self, checked)
        
        CreateConfigWindow()
        --GUI.isBusy = false 
        GUI.win:SetNeedsFrameUpdate(false)
    end

    GUI.win.OnResize = function(self, x, y, firstFrame)
        GUI.isBusy = true
        if firstFrame then
            self:SetNeedsFrameUpdate(false)
        end 
        UpdateScroll(true) 
        --CreateChatLines()
        --GUI.chatContainer:CalcVisible()
    end
    GUI.win.OnResizeSet = function(self)
        if not self:IsPinned() then
            self:SetNeedsFrameUpdate(true)
        end 
        GUI.isBusy = false 
        LOG('SUI_UnitsFilter Win.OnResizeSet ')
    
        UpdateScroll(true)  
        --RewrapLog()
        --CreateChatLines()
        --GUI.chatContainer:CalcVisible()
        --GUI.chatEdit.edit:AcquireFocus()
    end
    GUI.win.OnMove = function(self, x, y, firstFrame)
        GUI.isBusy = true
        if firstFrame then
            self:SetNeedsFrameUpdate(false)
        end
    end
    GUI.win.OnMoveSet = function(self)
        --GUI.chatEdit.edit:AcquireFocus()
        if not self:IsPinned() then
            self:SetNeedsFrameUpdate(true)
        end
        GUI.isBusy = false 
    end
   -- GUI.win.OnMouseWheel = function(self, rotation)
   --     
   --     --local newTop = GUI.chatContainer.top - math.floor(rotation / 100)
   --     --GUI.chatContainer:ScrollSetTop(nil, newTop)
   --      return false
   -- end 
  --  GUI.win.OnOptionsSet = function(self)
  --      --GUI.chatContainer:Destroy()
  --      --GUI.chatContainer = false
  --      --for i, v in GUI.chatLines do
  --      --    v:Destroy()
  --      --end
  --      --GUI.win:SetAlpha(ChatOptions.win_alpha, true)
  --      --GUI.chatLines = {}
  --      --CreateChatLines()
  --      --RewrapLog()
  --      --GUI.chatContainer:CalcVisible()
  --      --GUI.chatEdit.edit:AcquireFocus()
  --      if not GUI.win.pinned then
  --          GUI.win.curTime = 0
  --          GUI.win:SetNeedsFrameUpdate(true)
  --      end
  --  end
  --  GUI.win.OnHideWindow = function(self, hidden)
  --      if not hidden then
  --          --for i, v in GUI.chatLines do
  --          --    v:SetNeedsFrameUpdate(false)
  --          --end
  --      end
  --  end
  --  
  --  GUI.win.curTime = 0
  --  GUI.win.pinned = false
  --  GUI.win.OnFrame = function(self, delta)
  --      --self.curTime = self.curTime + delta
  --      --if self.curTime > ChatOptions.fade_time then
  --      --    ToggleChat()
  --      --end
  --      if delta > 10 then
  --          LOG('Filter OnFrame ' .. tostring(delta))
  --      end
  --  end
  --  GUI.win.OnPinCheck = function(self, checked)
  --      GUI.win.pinned = checked
  --      GUI.win:SetNeedsFrameUpdate(not checked)
  --      GUI.win.curTime = 0
  --      --GUI.chatEdit.edit:AcquireFocus()
  --      if checked then
  --          Tooltip.AddCheckboxTooltip(GUI.win._pinBtn, 'chat_pinned')
  --      else
  --          Tooltip.AddCheckboxTooltip(GUI.win._pinBtn, 'chat_pin')
  --      end
  --  end
   

      GUI.win.OldHandleEvent = GUI.win.HandleEvent
      GUI.win.HandleEvent = function(self, event)
           --  import('/lua/ui/game/worldview.lua'):HandleEvent(event)
           
           return HandleMouseWheel(event)
           --if event.Type == "WheelRotation" then --and self:IsHidden() 
           --     LOG('SUI_UnitsFilter Win.HandleEvent... ' .. event.Type)
           --    import('/lua/ui/game/worldview.lua').ForwardMouseWheelInput(event) 
           --    return true
           --else
           --      return false
           --    --return GUI.win.OldHandleEvent(self, event)
           --end
       end 

  --  Tooltip.AddButtonTooltip(GUI.win._closeBtn, 'chat_close')
  --  Tooltip.AddControlTooltip(GUI.win._closeBtn, 'chat_close')
  --  Tooltip.AddControlTooltip(GUI.win._configBtn, 'chat_config')
  --  Tooltip.AddCheckboxTooltip(GUI.win._pinBtn, 'chat_pin')
    
    --CreateChatLines()
    --RewrapLog()
    --GUI.chatContainer:CalcVisible()
    --ToggleChat()
     
     --TODO test config changes
      --CreateConfigWindow()
 end
 
function CloseUI()
    --if not GUI.win:IsHidden() then
    --    ToggleUI()
    --end
    --if GUI.options then
    --   GUI.options:Destroy()
    --   GUI.options = nil
    --end   
    
    LOG('--- UnitsFilter CloseUI ' .. table.getsize(GUI.overlays) )
    
    GUI.isBusy = true
    GameMain.RemoveBeatFunction(AvatarsUpdate, 'AvatarsUpdate')
    import(modScripts .. 'UnitsOverlays.lua').CloseUI()

    CloseConfigWindow()

    for _, toggle in GUI.overlays or {} do
        toggle:OnDestroy() 
    end
    GUI.overlays = {}

    for _, toggle in GUI.filters or {} do
        toggle:OnDestroy() 
    end
    GUI.filters = {}

    for uid, avatar in GUI.avatars or {} do
        avatar:Destroy() 
        --GUI.avatars[uid] = nil
        --if avatar then avatar:Destroy() avatar = nil end
    end
    for _, avatar in GUI.avatarsMap or {} do
        avatar:Destroy() 
    end
      GUI.avatars = nil 
      GUI.avatarsMap = nil 
    --for gid, group in GUI.scroll.groups do
    -- 
    --    for _, avatar in group.avatars do
    --        avatar:Destroy() 
    --        --avatar = nil 
    --    end
    --    for _, avatar in group.avatarsMap do
    --        avatar:Destroy() 
    --        --avatar = nil 
    --    end
    --    group.avatars = nil 
    --    group.avatarsMap = nil 
    --    group:Destroy()
    --    group = nil
    --end   


    if GUI.scroll then
       GUI.scroll.groups = nil
       GUI.scroll:Destroy()
       GUI.scroll = nil
    end
     
    if GUI.win then
       GUI.win:Destroy()
       GUI.win = nil
    end
end


function ToggleUI()
    if GUI.win:IsHidden() then
        --if GetFocusArmy() ~= -1 then
            GUI.win:Show()
            --GUI.chatEdit.edit:AcquireFocus()
            if not GUI.win.pinned then
                GUI.win:SetNeedsFrameUpdate(true)
                GUI.win.curTime = 0
            end
            --for i, v in GUI.chatLines do
            --    v:SetNeedsFrameUpdate(false)
            --    v:Show()
            --    v.OnFrame = nil
            --end
        --end
    else
        GUI.win:Hide()
        --GUI.chatEdit.edit:AbandonFocus()
        GUI.win:SetNeedsFrameUpdate(false)
    end
end