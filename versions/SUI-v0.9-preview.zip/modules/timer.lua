
--local GetTime = CurrentTime
local GetTime = GetSystemTimeSeconds
--local GetTime = GetGameTimeSeconds
local tasks = {}

local timeStart = nil
--- Starts timer to check how long a process is taking, useful for optimization
function Start(name)
    if not name then name = 'task' end

    if not tasks[name] then
        tasks[name] = {} 
        tasks[name].count = 0
        tasks[name].total = 0
    end
    tasks[name].start = GetTime()

    --timeStart = GetTime()  
end

--- Stops timer and returns how much time a process took from calling TimerStart()
function Stop(name)
    if not name then name = 'task' end

    if not tasks[name] then
        tasks[name] = {}  
        tasks[name].count = 0
        tasks[name].total = 0
    end

    tasks[name].stop = 0 
    if tasks[name].start then 
       tasks[name].stop  = GetTime() - tasks[name].start 
       tasks[name].start = GetTime() -- reset time start
       tasks[name].total = tasks[name].total + tasks[name].stop
       tasks[name].count = tasks[name].count + 1
    end 
    local stats = string.format(" in %0.9f seconds ", tasks[name].stop) .. tasks[name].count

    if tasks[name].count >= 10 then
       tasks[name].average = tasks[name].total / tasks[name].count
       tasks[name].count = 0
       tasks[name].total = 0
       stats = stats ..  string.format(" avg %0.9f seconds", tasks[name].average)
    end

    --local timeStop = 0
    --if timeStart then 
    --   timeStop  = GetTime() - timeStart 
    --   timeStart = GetTime() -- reset time start
    --end 
    --return string.format(" in %0.5f seconds", timeStop)
    return stats
end

function Test()
    LOG('--- timer test --- \n' 
        .. tostring(GetSystemTime()) .. ' GetSystemTime ' 
        .. tostring(GetSystemTimeSeconds()) .. ' GetSystemTimeSeconds \n'
        .. tostring(GetGameTime()) .. ' GetGameTime ' 
        .. tostring(GetGameTimeSeconds()) .. ' GetGameTimeSeconds \n'
        .. tostring(GameTime())  .. ' GameTime ' 
        .. tostring(GameTick())  .. ' GameTick ')

end
