-- AKA mciallunits.lua in SET mod

local EnhanceCommon = import('/lua/enhancementcommon.lua')

local modPath = '/mods/SupremeScoreBoard/'
local modScripts  = modPath..'modules/'
local Selector   = import(modScripts .. 'UnitsSelector.lua')
local ScoreBoard = import(modScripts .. 'score_board.lua')
local Timer = import(modScripts .. 'timer.lua')
--local GetScore = import(modPath .. 'modules/mciscore.lua').GetScore
  
 
--local Select = import('/mods/common/select.lua')
--local Score = import('/mods/common/score.lua')

local current_army = nil
local units = { all = {}, cached = { }, infos = {} }
local unitsTotal = 0
local assisting ={}
local cached = {}
local cachedSize = 0

local last_reset = 0
local last_cached = 0
local acu = false

function InitBuildStats()
    return { 
        total = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },  
        engineers = {
            --ALL = { max = 0, used = 0, delta = 0, idle = {}, busy = {} },
            STATIONS = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            DRONES   = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            COMMS    = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            TECH1    = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            TECH2    = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            TECH3    = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
        }, 
        factories = {
            --ALL   = { max = 0, used = 0, delta = 0, idle = {}, busy = {} },
            NAVAL = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            LAND  = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            GATE  = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
            AIR   = { max = 0, used = 0, idle = 0, idleUnits = {}, busyUnits = {} },
        }, 
    }
end
local stats = { 
    build = InitBuildStats(), 
    --mass = { }, 
}
local gate = false 
local factory = false
local eng = false
local scu = false 
local drone = false

function GetCommandType(unit)
    local action = 'Idle'
    local commands = unit:GetCommandQueue()    
    if table.getsize(commands) > 0 then
        action = commands[1].type -- check only first command
    end
    return action
end

function GetMissilesCount(unit)
    local missiles = 0
    if unit.isMissleSilo then
        local data = unit:GetMissileInfo()
        if data then
            missiles = missiles + (data.tacticalSiloStorageCount or 0)
            missiles = missiles + (data.nukeSiloStorageCount or 0)
            --LOG(tostring( unit.isMissleSilo) .. ' ' .. unit.id .. ' ' .. missiles)
        end 
    end
--     nukeSiloBuildCount=0,
--INFO:   nukeSiloMaxStorageCount=0,
--INFO:   nukeSiloStorageCount=0,
--INFO:   tacticalSiloBuildCount=0,
--INFO:   tacticalSiloMaxStorageCount=10,
--INFO:   tacticalSiloStorageCount=1
--INFO: }
    return missiles
end
function GetMissilesMax(unit)
    local missiles = 0
    if unit.isMissleSilo then
        local data = unit:GetMissileInfo()
        if data then
            missiles = missiles + (data.tacticalSiloMaxStorageCount or 0)
            missiles = missiles + (data.nukeSiloMaxStorageCount or 0)
            --LOG(tostring( unit.isMissleSilo) .. ' ' .. unit.id .. ' ' .. missiles)
        end 
    end
    return missiles
end
function GetUpgadesUsage(unit)
    local usage = {}
    usage.massConsumed = 0 
    usage.massProduced = unit.bp.Economy.ProductionPerSecondMass or 0
    usage.energyConsumed = 0  
    usage.energyProduced = unit.bp.Economy.ProductionPerSecondEnergy or 0
    if unit.isCommander then
        local upgradesActive = EnhanceCommon.GetEnhancements(unit:GetEntityId())
        --upgradesActive = table.hash(upgradesActive)
        --for enhName, enh in unit.bp.Enhancements do
        --    if upgradesActive[enhName] then
        --       usage.energy = usage.energy - (enh.MaintenanceConsumptionPerSecondEnergy or 0)
        --       usage.energy = usage.energy + (enh.ProductionPerSecondEnergy or 0)
        --       usage.mass = usage.mass - (enh.ProductionPerSecondMass or 0)
        --    end 
        --end
        for _, enhName in upgradesActive or {} do
            local enh = unit.bp.Enhancements[enhName]
            if enh then
               usage.energyConsumed = usage.energyConsumed + (enh.MaintenanceConsumptionPerSecondEnergy or 0)
               usage.energyProduced = usage.energyProduced + (enh.ProductionPerSecondEnergy or 0)
                
               usage.massConsumed = usage.massConsumed + (enh.MaintenanceConsumptionPerSecondMass or 0)
               usage.massProduced = usage.massProduced + (enh.ProductionPerSecondMass or 0)
            end 
        end
    end
    return usage
end

function UpdateUnits()
    Selector.Hidden(function()
        unitsTotal = table.getsize(units.all)
        units.all = {}
        UISelectionByCategory("ALLUNITS", false, false, false, false)
        for _, unit in GetSelectedUnits() or {} do
            local id = unit:GetEntityId()
            units.all[id] = unit
        end
        --LOG('units_stats UpdateUnits ' .. unitsTotal .. ' -> ' .. table.getsize(units.all))
    end)
end

local function PrintBuild()
 
    LOG(' ')
  -- if acu then
   --    table.print(acu:GetCommandQueue(), 'acu') 
   --
   --end
   if scu then
        -- local bp = unit:GetBlueprint()
          --if  scu:GetEconData().massProduced > 2 then
          --   table.print(scu, 'scu') 
          --   --EnhancementPresetAssigned      
          --end
          local bp = scu:GetBlueprint()
            local upgradeUsage = bp.Economy.ProductionPerSecondEnergy or 0
            local upgradesActive = EnhanceCommon.GetEnhancements(scu:GetEntityId())
            upgradesActive = table.hash(upgradesActive)

            for enhName, enh in bp.Enhancements do
                if upgradesActive[enhName] then
                   upgradeUsage = upgradeUsage + (enh.MaintenanceConsumptionPerSecondEnergy or 0)
                   upgradeUsage = upgradeUsage - (enh.ProductionPerSecondEnergy or 0)
                end 
            end

            LOG('scu:usage ' .. upgradeUsage ..  ' '   .. scu:GetEconData().energyRequested  )
   
        LOG('scu:IsIdle ' .. repr(scu:IsIdle() ) )
     LOG('scu:GetWorkProgress ' .. repr(scu:GetWorkProgress() ) )
       table.print(scu:GetEconData(), 'scu GetEconData')  
       table.print(scu:GetCommandQueue(), 'scu GetCommandQueue')  
   end
   if eng then
          LOG('eng:IsIdle ' .. repr(eng:IsIdle() ) )
     LOG('eng:GetWorkProgress ' .. repr(eng:GetWorkProgress() ) )
       table.print(eng:GetEconData(), 'eng GetEconData')  
       table.print(eng:GetCommandQueue(), 'eng GetCommandQueue')  
   end
   
   if drone then
          LOG('drone:IsIdle ' .. repr(drone:IsIdle() ) )
     LOG('drone:GetWorkProgress ' .. repr(drone:GetWorkProgress() ) )
       table.print(drone:GetEconData(), 'drone GetEconData')  
       table.print(drone:GetCommandQueue(), 'drone GetCommandQueue')  
   end 
   
 --  if factory then
 --      LOG('factory:IsIdle ' .. repr(factory:IsIdle() ) )
 --    LOG('factory:GetWorkProgress ' .. repr(factory:GetWorkProgress() ) )
 --      table.print(factory:GetEconData(), 'factory GetEconData') 
 --      table.print(factory:GetCommandQueue(), 'factory GetCommandQueue') 
 --
 --  end

        LOG('BUILD ' .. stats.build.total.used .. ' / ' ..  stats.build.total.max .. ' '
         .. table.getsize(stats.build.total.idleUnits)  .. ' ' 
         .. table.getsize(stats.build.total.busyUnits) )  

    for key, tbl in stats.build.engineers do        
        LOG(key .. ' ' .. tbl.used .. ' / ' ..  tbl.max .. ' '
         .. table.getsize(tbl.idleUnits)  .. ' ' 
         .. table.getsize(tbl.busyUnits) ) 
    end 
    for key, tbl in stats.build.factories do        
        LOG(key .. ' ' .. tbl.used .. ' / ' ..  tbl.max .. ' '
         .. table.getsize(tbl.idleUnits)  .. ' ' 
         .. table.getsize(tbl.busyUnits) ) 
    end 
end

local function UpdateTable(buildTable, unit, buildRate, isIdle)
    if isIdle then
        table.insert(buildTable.idleUnits, unit) 
    else
        table.insert(buildTable.busyUnits, unit) 
        buildTable.used = buildTable.used + buildRate
    end
    buildTable.max = buildTable.max + buildRate
    buildTable.idle = buildTable.max - buildTable.used
    
end
 
local function UpdateBuildFactory(unit, buildRate, isIdle)
    UpdateTable(stats.build.total, unit, buildRate, isIdle)
     
    if EntityCategoryContains(categories.GATE, unit) then
        UpdateTable(stats.build.factories.GATE, unit, buildRate, isIdle)
        gate = unit
    
    elseif EntityCategoryContains(categories.LAND, unit) then
        UpdateTable(stats.build.factories.LAND, unit, buildRate, isIdle)
        factory = unit    
    elseif EntityCategoryContains(categories.AIR, unit) then
        UpdateTable(stats.build.factories.AIR, unit, buildRate, isIdle)    
    elseif EntityCategoryContains(categories.NAVAL, unit) then
        UpdateTable(stats.build.factories.NAVAL, unit, buildRate, isIdle)
    end  
end

local function UpdateBuildEngineer(unit, buildRate, isIdle)
   
    UpdateTable(stats.build.total, unit, buildRate, isIdle)
     
    if EntityCategoryContains(categories.COMMAND, unit) then
        UpdateTable(stats.build.engineers.COMMS, unit, buildRate, isIdle)
        acu = unit
    elseif EntityCategoryContains(categories.SUBCOMMANDER, unit) then
        UpdateTable(stats.build.engineers.COMMS, unit, buildRate, isIdle)
        scu = unit
    elseif EntityCategoryContains(categories.POD, unit) then
        UpdateTable(stats.build.engineers.DRONES, unit, buildRate, isIdle)
        drone = unit
    elseif EntityCategoryContains(categories.ENGINEERSTATION, unit) then
        UpdateTable(stats.build.engineers.STATIONS, unit, buildRate, isIdle)
    elseif EntityCategoryContains(categories.TECH1, unit) then
        UpdateTable(stats.build.engineers.TECH1, unit, buildRate, isIdle)
    elseif EntityCategoryContains(categories.TECH2, unit) then
        UpdateTable(stats.build.engineers.TECH2, unit, buildRate, isIdle)
    elseif EntityCategoryContains(categories.TECH3, unit) then
        UpdateTable(stats.build.engineers.TECH3, unit, buildRate, isIdle)
        eng = unit
    end 
end

-- abilities
local abilities = { 
    DIRECTFIRE = (categories.DIRECTFIRE + categories.SATELLITE + categories.ORBITALSYSTEM),
    INDIRECTFIRE = categories.INDIRECTFIRE,
    --MISSILENAVY = (categories.NUKE + categories.TACTICALMISSILEPLATFORM + categories.SILO - categories.SUBCOMMANDER - categories.COMMAND + categories.xss0303 + categories.xss0202 + categories.xas0306 + categories.ues0202),
    --MISSILE = (categories.NUKE + categories.TACTICALMISSILEPLATFORM + categories.SILO - categories.SUBCOMMANDER - categories.COMMAND),
    ANTIAIR = categories.ANTIAIR,
    ANTINAVY = (categories.ANTINAVY + categories.ANTISUB + categories.xes0102 + categories.xrs0204 + categories.urs0203 ),
    --INTEL = (categories.RADAR + categories.OMNI + categories.SONAR + categories.OPTICS + categories.COUNTERINTELLIGENCE + categories.OVERLAYCOUNTERINTEL),
    INTEL = (categories.RADAR + categories.OMNI + categories.SONAR + categories.OPTICS + categories.SCOUT + categories.INTELLIGENCE + categories.OVERLAYCOUNTERINTEL),
    --DRONES = (categories.SUBCOMMANDER * categories.Pod) + categories.POD, 
    DRONES = categories.POD,
    --DRONESTATION = ((categories.SUBCOMMANDER * categories.Pod) + categories.POD + (categories.STRUCTURE * categories.ENGINEERSTATION)),
    COMMANDERS = (categories.SUBCOMMANDER + categories.COMMAND),
    MASS = (categories.MASSPRODUCTION + categories.MASSEXTRACTION + categories.MASSSTORAGE + categories.MASSFABRICATION),
    ENERGY = (categories.ENERGYPRODUCTION + categories.ENERGYSTORAGE),
    ENGINEERS = (categories.MOBILE * categories.ENGINEER ),
}

abilities.ANTINUKES = (categories.STRUCTURE * categories.SILO * (categories.TECH3 + categories.EXPERIMENTAL))
abilities.NUKES = ((categories.STRUCTURE + categories.NAVAL) *  categories.NUKE)
abilities.TMLS = (categories.STRUCTURE * categories.TACTICALMISSILEPLATFORM) + (abilities.COMMANDERS * categories.SILO)

local function IsMissleSilo(unit)
    if units.infos[unit.id].isMissleSilo == nil then 
       units.infos[unit.id].isMissleSilo = EntityCategoryContains(abilities.ANTINUKES + abilities.NUKES + abilities.TMLS, unit)
       --units.infos[unit.id].isMissleSilo = (unit.bp.CategoriesHash['STRUCTURE'] and unit.bp.CategoriesHash['SILO'] and unit.bp.CategoriesHash['TECH3']) or 
       --                                    ( unit.bp.CategoriesHash['STRUCTURE'] or  unit.bp.CategoriesHash['STRUCTURE']
    end
    return units.infos[unit.id].isMissleSilo
end

local function IsCommander(unit)
    if units.infos[unit.id].isCommander == nil then 
       units.infos[unit.id].isCommander = EntityCategoryContains((categories.COMMAND + categories.SUBCOMMANDER), unit)
    end
    return units.infos[unit.id].isCommander
end
local function IsFactory(unit)
    if units.infos[unit.id].isFactory == nil then 
       units.infos[unit.id].isFactory = EntityCategoryContains((categories.FACTORY * categories.STRUCTURE), unit)
    end
    --EntityCategoryContains(categories.FACTORY, unit)    
    return units.infos[unit.id].isFactory
end 
local function IsEngStation(unit)
    if units.infos[unit.id].isEngStation == nil then 
       units.infos[unit.id].isEngStation = EntityCategoryContains(categories.STRUCTURE, unit) and 
                                           EntityCategoryContains(categories.ENGINEERSTATION, unit)
    end    
    return units.infos[unit.id].isEngStation
end
local function IsEngineer(unit)
    if units.infos[unit.id].isEngineer == nil then 
       units.infos[unit.id].isEngineer = EntityCategoryContains(categories.ENGINEER, unit)
    end
    return units.infos[unit.id].isEngineer
end
local function IsDrone(unit)
    if units.infos[unit.id].isDrone == nil then 
       units.infos[unit.id].isDrone = EntityCategoryContains((categories.POD + categories.Pod), unit)
    end
    return units.infos[unit.id].isDrone
end
local function IsMassExtractor(unit)
    if units.infos[unit.id].isMassExtractor == nil then 
       units.infos[unit.id].isMassExtractor = EntityCategoryContains(categories.STRUCTURE * categories.MASSEXTRACTION, unit)
    end
    return units.infos[unit.id].isMassExtractor
end
local function IsUpgradeable(unit)
    if units.infos[unit.id].isUpgradeable == nil then 
       units.infos[unit.id].isUpgradeable = unit.bp.General.UpgradesTo and  
                                            unit.bp.General.UpgradesTo ~= ''
       --LOG('IsUpgradeable ' .. unit.id  .. ' (' .. tostring(units.infos[unit.id].isUpgradeable)
       -- .. ') UpgradesTo=' .. tostring(unit.bp.General.UpgradesTo) .. ',' ..  ' ' .. unit.Name)
    end
    return units.infos[unit.id].isUpgradeable
end

local function IsUpgrading(unit)
    
     --LOG('IsUpgrading ' .. unit.Name  .. ' ' .. tostring(unit.isUpgradeable) .. ' ' .. GetCommandType(unit))

    if not unit.isUpgradeable then return false end 

    local focus = unit:GetFocus()
    if not focus or focus:IsDead() then return false end 

    --LOG('IsUpgrading ' .. unit.id  .. ' -> ' .. focus:GetUnitId())

    -- LOG('IsUpgrading '  .. unit.Name .. ' ' .. unit.id   .. ' -> ' .. focus:GetUnitId() .. ' ' .. tostring(unit.bp.General.UpgradesTo))

    --if focus:GetUnitId() ~= unit.bp.General.UpgradesTo then return false end 
     
    local progress = unit:GetWorkProgress() 

    --LOG('IsUpgrading ' .. unit.id  .. ' -> ' .. focus:GetUnitId() .. ' ' .. tostring(progress))


    if progress and progress > 0 and progress < 1 then

        if unit.bp.General.UpgradesTo == focus:GetUnitId()  then return true end 

        if unit.bp.CategoriesHash['STRUCTURE'] == focus.bp.CategoriesHash['STRUCTURE']  then 
            return true 
        end 
        --if unit.bp.CategoriesHash['MOBILE'] == focus.bp.CategoriesHash['MOBILE']  then 
        --    return true 
        --end 
       --return   true --unit.bp.General.UpgradesTo == focus:GetUnitId()
    end
     
    return false
end


function IsPaused(unit)

    local isPaused = false
    if not unit.sameProgress then
        unit.sameProgress = 0 
    end 
   
    unit.currentProgress = unit:GetWorkProgress()
    if unit.currentProgress > 0 and 
       unit.currentProgress <= unit.lastProgress then 
       unit.sameProgress = unit.sameProgress + 1
    else  
       unit.sameProgress = 0
       isPaused = false
    end
    unit.lastProgress = unit.currentProgress 
    
    if unit.sameProgress >= 100 then  
        if unit.id == testUID then 
            LOG('IsEngineering ' .. unit.id .. ' IsPaused '   )
        end 
        isPaused = true
    end
    return isPaused 
end
local testUID = 'TEST uel0105' --url0301_Stealth urs0304 uel0301_Engineer xrb0304 urb2305

-- is unit engineering: building/assisting/repair/reclaiming but not paused
local function IsEngineering(unit)

    if not unit.canEngineer then 
       if unit.id == testUID then 
          LOG('IsEngineering ' .. unit.id .. ' cannot produce')
       end
       return false 
    end

    local action = GetCommandType(unit)
    unit.action = action 
     
    if unit.isEngineer then
        if action == 'Reclaim' or 
           action == 'Attack' or 
           action == 'Move' or 
           action == 'AggressiveMove' or
           action == 'Patrol' then -- on reclaim route
            return true
        --elseif action == 'Reclaim' then 
        --    return true
        elseif action == 'Repair' or -- Repairing
               action == 'Script' or -- Upgrading/Enhancing
               action == 'AssistCommander' or -- drone 
               action == 'Guard' or -- Assisting
               action == 'Tactical' or  
               action == 'Nuke' or  
               action == 'Idle' or -- check if TML SCU building TML while idle
               action == 'BuildMobile' then
         
            local energyUsed = unit:GetEconData().energyRequested 
            if action == 'Script' then -- unit.isCommander then 
                energyUsed = energyUsed - GetUpgadesUsage(unit).energyConsumed
            end  

            --if unit.id == testUID then
            --    LOG('IsEngineering ' .. tostring(energyUsed > 0) .. ' ' .. tostring(unit:IsIdle()) .. ' '.. unit.id .. ' ' .. tostring(action) .. ' ' .. tostring(energyUsed))
            --    --table.print(unit:GetEconData(), ' unit:GetEconData()')
            --    --table.print(unit.bp.Economy, ' unit.bp.Economy')
            --end

            unit.energyUsed = energyUsed
            return energyUsed > 0 or not unit:IsIdle() -- engineering only when unit is consuming energy
        end

        -- if unit.id == testUID then
        --     LOG('IsEngineering ' .. unit.id .. ' ' .. tostring(action) .. ' ' .. tostring(unit:IsIdle()))
        --     --table.print(unit:GetEconData(), ' unit:GetEconData()')
        --     --table.print(unit.bp.Economy, ' unit.bp.Economy')
        -- end

        return not unit:IsIdle()

    elseif unit.isFactory then

        --local commands = unit:GetCommandQueue()    
        --if table.getsize(commands) > 1 then
        --    --action = commands[1].type -- check only first command
        --    return true
        --end
        if unit:IsIdle() then
            return false
        end
        local energyUsed = unit:GetEconData().energyRequested  
        return energyUsed > 0 -- engineering only when unit is consuming energy 

    elseif unit.isMissleSilo then
        local energyUsed = unit:GetEconData().energyRequested  
        return energyUsed > 0 -- engineering only when unit is consuming energy 

    elseif unit.isUpgradeable then
        --TODO
        return unit:GetWorkProgress() > 0 --false
    end


--    if action == 'Reclaim' or 
--       action == 'Guard' or -- Assisting
--       action == 'Repair' or -- Repairing
--       action == 'Patrol' then -- on reclaim route
--        return true
--
--    elseif unit.isFactory or
--           unit.isMissleSilo or
--           --unit.isEngStation or
--           unit.isUpgradeable or
--           action == 'Script' or -- Upgrading/Enhancing
--           action == 'AssistCommander' or -- drone
--           action == 'Idle' or -- units building nukes/tml
--           action == 'BuildMobile'  then
--        -- check if paused
--
--  --        if not unit.sameProgress then
--  --            unit.sameProgress = 0
--  --        end 
--  
--  --        unit.currentProgress = unit:GetWorkProgress()
--  --        if unit.currentProgress > 0 and 
--  --           unit.currentProgress <= unit.lastProgress then 
--  --           unit.sameProgress = unit.sameProgress + 1
--  --        else  
--  --           unit.sameProgress = 0
--  --           unit.isPaused = false
--  --        end
--  --        unit.lastProgress = unit.currentProgress 
--  
--  --        if unit.sameProgress >= 100 then  
--  --           unit.isPaused = true
--  --            if unit.id == testUID then 
--  --              LOG('IsEngineering ' .. unit.id .. ' IsPaused '   )
--  --            end
--  --            return false 
--  --        end
--
--        local ecoData = unit:GetEconData() 
--        local energyUsed = ecoData.energyRequested 
--        local upgradeUsage = GetUpgadesUsage(unit).energyConsumed
--       
--        if energyUsed > 0 and upgradeUsage > 0 then
--            energyUsed = energyUsed - upgradeUsage
--        end  
--
--        return energyUsed > 0 -- engineering only when unit is consuming energy
--
--    elseif (unit.isEngineer or unit.isCommander) and
--           (action == 'Attack' or 
--            action == 'Move' or 
--            action == 'AggressiveMove') then 
--        return true --false
--
--    
--    end

    return false
end

local function CanEngineer(unit)
    if units.infos[unit.id].canEngineer == nil then 
       units.infos[unit.id].canEngineer = unit.isEngineer or 
            unit.isFactory or unit.isEngStation or unit.isMissleSilo or unit.isUpgradeable
    end
    return units.infos[unit.id].canEngineer 
end

UnitTypes = {

    FACTORY     = { Strat = 'factory_generichq', Icon = 'land', Categories =  categories.STRUCTURE * categories.FACTORY },
    SHIELD      = { Strat = 'structure_shield', Icon = 'land', Categories =  categories.STRUCTURE * categories.SHIELD },
    COMMANDER   = { Strat = 'commander_generic', Icon = 'land', Categories =  categories.SUBCOMMANDER + categories.COMMAND },
    ENGINEER    = { Strat = 'land_engineer', Icon = 'land', Categories =  categories.ENGINEER - categories.SUBCOMMANDER - categories.COMMAND },
    LAND        = { Strat = 'land_generic', Icon = 'land', Categories = (categories.LAND  * categories.MOBILE - categories.ENGINEER) },
    NAVAL       = { Strat = 'ship_generic', Icon = 'sea',  Categories = (categories.NAVAL * categories.MOBILE - categories.ENGINEER) },
    AIR         = { Strat = 'fighter_generic', Icon = 'air', Categories = (categories.AIR * categories.MOBILE - categories.ENGINEER) },
    
    STRUCTURE   = { Strat = 'structure_generic', Icon = 'land', Categories = (categories.STRUCTURE - categories.FACTORY - categories.SHIELD) },
    
   --{Name="ECO",            Category = categories.STRUCTURE * (categories.MASSEXTRACTION + categories.ENERGYPRODUCTION) },
    -- {Name="Mass extraction", category = categories.MASSEXTRACTION + categories.MASSSTORAGE },
    --{Name="MASSFABRICATION", category = categories.STRUCTURE * categories.MASSFABRICATION },
} 

function GetUnitType(unit)

    if units.infos[unit.id].Type ~= nil then
       --LOG(' cache Type ' .. unit.id .. ' ' .. tostring(units.infos[unit.id].Type  ))
       return units.infos[unit.id].Type  
    end
    local value = 'UNKNOWN'
    for id, Type in UnitTypes do
        if EntityCategoryContains(Type.Categories, unit) then
            value = id 
            break
        end
    end 
    --LOG(' units ' .. unit.id .. ' ' .. value)
    units.infos[unit.id].Type = value
    return value
end
function GetUnitTech(unit)

    if units.infos[unit.id].Tech ~= nil then
       --LOG(' cache Tech ' .. unit.id .. ' ' .. tostring(units.infos[unit.id].Tech  ))
        return units.infos[unit.id].Tech  
    end

    local tech = 'T4' -- assume ACU is T4
    if unit.bp.CategoriesHash['TECH1'] then
        tech = 'T1'
    elseif unit.bp.CategoriesHash['TECH2'] then --EntityCategoryContains(categories.TECH2, unit) then
        tech = 'T2'
    elseif unit.bp.CategoriesHash['TECH3']  then
        tech = 'T3' 
    elseif unit.bp.CategoriesHash['EXPERIMENTAL'] then
        tech = 'T4'
    end

    units.infos[unit.id].Tech = tech
        
    --LOG(' units ' .. unit.id .. ' ' .. tech)

    return tech
end
function GetUnitFaction(unit)
    
    if units.infos[unit.id].Faction ~= nil then
       --LOG(' cache Faction ' .. unit.id .. ' ' .. tostring(units.infos[unit.id].Faction  ))
       return units.infos[unit.id].Faction  
    end

    local faction = 'OTHER'
    if EntityCategoryContains(categories.AEON, unit) then
        faction = 'AEON'
    elseif EntityCategoryContains(categories.UEF, unit) then
        faction = 'UEF'
    elseif EntityCategoryContains(categories.CYBRAN, unit) then
        faction = 'CYBRAN'
    elseif EntityCategoryContains(categories.SERAPHIM, unit) then
        faction = 'SERAPHIM'
    end

    --LOG(' units ' .. unit.id .. ' ' .. tostring(faction))
       
    units.infos[unit.id].Faction = faction
    return faction
end
function GetUnitBlueprint(unit)
    local bp = units.infos[unit.id].bp

    if bp == nil then
       bp = unit:GetBlueprint() 
       
       if bp.CategoriesHash == nil then
          bp.CategoriesHash = table.hash(bp.Categories)
       end
       units.infos[unit.id].bp = bp
    end
     
    return bp
end

local TechLevels = {TECH1 = 1, TECH2 = 2, TECH3 = 3, EXPERIMENTAL = 4} --, COMMAND = 4}
function GetUnitName(unit)

    if units.infos[unit.id].Name ~= nil then
       return units.infos[unit.id].Name  
    end
    
    local techLevel = false 
    for tech, level in TechLevels do
        if unit.bp.CategoriesHash[tech] then
            techLevel = level
            break
        end
    end  

    local value = ''
    if techLevel then
        value = LOCF("T%d %s", techLevel, unit.bp.Description)
    else
        value = LOC(unit.bp.Description)
    end

    if unit.bp.CategoriesHash['RESEARCH'] then
        value = value .. ' (HQ)'
    elseif unit.bp.CategoriesHash['SUPPORTFACTORY'] then
        value = value .. ' (SUPPORT)'
    end
    --LOG(' units ' .. unit.id .. ' ' .. value)
     
    units.infos[unit.id].Name = value
    return value
end
-- get unit's all upgrades or only active/built upgrades
function GetUnitUpgrades(unit, all) 
    local enhancements = {}
    if all then
        for name, enh in unit.bp.Enhancements do
            if name ~= 'Slots' then
                enhancements[name] = enh  
            end 
        end
    else
        local active = table.hash(EnhanceCommon.GetEnhancements(unit:GetEntityId()))
        for name, enh in unit.bp.Enhancements do
            if active[name] then
                enhancements[name] = enh  
            end 
        end
    end
    return enhancements
end 
function TestFunction()
    local count = 0
    Timer.Start('without hash')    
    for i, unit in units.all do
        if EntityCategoryContains(categories.ENGINEER, unit) then
            count = count + 1
        end
    end 
    
    LOG(' --- units stats '  .. count .. ' ENGINEERS ' .. Timer.Stop('without hash')) 
    count = 0
    Timer.Start('with hash')
    for i, unit in units.all do
        if unit.bp and unit.bp.CategoriesHash['ENGINEER'] then
            count = count + 1
        end
    end 
    LOG(' --- units stats '  .. count .. ' ENGINEERS ' .. Timer.Stop('with hash')) 

end
-- update units constants
function TestUnitStats(testUnits)

    TestFunction()

  --  units.infos = {}
  --  Timer.Start()
  --  for i, unit in testUnits do
  --      unit.isUpdated = false
  --      UpdateUnitStats(unit)
  --  end 
  --  LOG(' --- units stats '  .. table.getsize(testUnits) .. Timer.Stop()) 
  
end 

-- initialize units constants
function InitializeUnitStats(unit)

    if unit.isInitialized then --LOG(' units updated ' .. tostring( unit.id)) 
        return 
    end 

    --Timer.Start()
    if not unit.id then unit.id = unit:GetUnitId() end
    if not unit.eid then unit.eid = unit:GetEntityId() end

    if units.infos[unit.id] == nil then
       units.infos[unit.id] = {}
        --   LOG(' units init  ' .. unit.id)
    end

    unit.bp = GetUnitBlueprint(unit)
    if not unit.bp.CategoriesHash then
        unit.bp.CategoriesHash = table.hash(unit.bp.Categories)
    end
       
    unit.Creator = unit:GetCreator()
    unit.Tech = GetUnitTech(unit)
    unit.Name = GetUnitName(unit) 
    unit.Type = GetUnitType(unit)
    unit.Faction = GetUnitFaction(unit)
    
    unit.isUpgradeable = IsUpgradeable(unit)
    unit.isEngStation = IsEngStation(unit)
    unit.isCommander = IsCommander(unit)
    unit.isEngineer =  IsEngineer(unit)
    unit.isDrone = IsDrone(unit)
    unit.isFactory = IsFactory(unit)
    unit.isMissleSilo = IsMissleSilo(unit)
    unit.isMassExtractor = IsMassExtractor(unit)

    unit.missilesMax = GetMissilesMax(unit)
    unit.missiles = 0

    unit.canEngineer = CanEngineer(unit)
    --unit.canProduce = unit.canEngineer or unit.isMissleSilo or unit.isUpgradeable
    unit.isEngineering = IsEngineering(unit) 

     --     LOG(' units infos  ' .. unit.id .. ' ' .. unit.Tech .. ' ' .. unit.Name  .. ' ' .. unit.Type)
   --if not unit.bp then unit.bp = GetUnitBlueprint(unit) end
  -- if unit.Tech == nil then unit.Tech = GetUnitTech(unit) end
  -- if unit.Name == nil then unit.Name = GetUnitName(unit) end
  -- if unit.Type == nil then unit.Type = GetUnitType(unit) end
   --if unit.Faction == nil then unit.Faction = GetUnitFaction(unit) end
   
   if units.infos[unit.id].isPreset == nil then
      units.infos[unit.id].isPreset = EntityCategoryContains(categories.ISPREENHANCEDUNIT, unit)
      --LOG(' units ' .. unit.id .. ' IsPreset ' .. tostring(units.infos[unit.id].isPreset ))
   
   end
   unit.isPreset = units.infos[unit.id].isPreset 
   --if EntityCategoryContains(categories.ISPREENHANCEDUNIT, unit) then
   --    unit.isPreset = true 
   --end
    --table.print(units.infos, 'units.infos +++ ')
   --LOG(' --- units init  ' .. unit.id .. ' ' .. unit.eid .. ' ' .. unit.Name )
     
   unit.isInitialized = true 
   --LOG(' --- units stats '  .. unit.id .. ' ' .. unit.Name .. Timer.Stop()) 
end 

-- update units constants
function UpdateUnitStats(unit)
    -- update constants only once
    InitializeUnitStats(unit)

    if not unit.isBuilt then
        local builder =  ' none'
        if unit:GetCreator() then
            builder = ' Creator ' .. unit:GetCreator():GetWorkProgress()
        end

        --LOG(' --- units Health ' .. unit.Name .. ' = ' .. unit:GetHealth() .. ' ' ..  unit:GetMaxHealth()  ..  tostring(builder) )

        if unit:GetHealth() == unit:GetMaxHealth() or not unit:GetCreator() then
           -- LOG(' --- units built ' .. unit.id .. ' ' .. unit.eid .. ' ' .. unit.Name )
           unit.isBuilt = true
           --units.infos[unit.id] = {}
           --InitializeUnitStats(unit)
         end
    end 
    -- check if unit is taking damage 200 100

    if unit.isBuilt and unit.isInitialized then
         unit.currentHealth = unit:GetHealth()

         if unit.updatesHealth == nil or 
            unit.updatesHealth > 0 then
            unit.updatesHealth = 0
             local attackers = GetValidAttackingUnits()
             local attackersCount = table.getsize(attackers)

             if unit.lastHealth > unit.currentHealth then
                unit.isAttacked = true
                
                --LOG('isAttacked ' .. unit.Name .. ' '  .. attackersCount  ..' ' .. tostring( unit.lastHealth) .. ' -> ' .. unit.currentHealth)
             else
                --if unit.isAttacked and attackersCount > 0 then
                --    local bp = attackers[1]:GetBlueprint()
                --    LOG('isAttacked was '.. tostring(attackers[1].oldowner)  .. ' ' .. tostring(bp.General.FactionName) .. ' '.. tostring(bp.Display.IconName) )
                ----    LOG('isAttacked not' .. unit.Name .. ' ' .. tostring( unit.lastHealth) .. ' -> ' .. unit.currentHealth)
                --end

                unit.isAttacked = false
             end
             unit.lastHealth = unit:GetHealth()
         else 
            unit.updatesHealth = unit.updatesHealth + 1
         end 
          
         unit.isEngineering = IsEngineering(unit)
         unit.isUpgrading = IsUpgrading(unit)
         unit.missiles = GetMissilesCount(unit)
          
    end
     
    -- table.print(units.infos, 'units.infos --- ')
    
end

local function UpdateBuild(unit)

    buildRate = unit:GetBuildRate() or 0
    isIdle = not unit.isEngineering --and not unit:IsMoving() 
    --INFO: acu    1      type = "Reclaim"  AggressiveMove  
    -- acu    1      type = "Guard" Assist  BuildMobile


    if EntityCategoryContains(categories.FACTORY, unit) then
        UpdateBuildFactory(unit, buildRate, isIdle)
    elseif EntityCategoryContains(categories.ENGINEER, unit) then
        UpdateBuildEngineer(unit, buildRate, isIdle)
        --TODO add drones/eng stations
    end
end
local function InitCache()

    --units.cached = {}
    units.cached.all = {}
    units.cached.size = 0
end


local function UpdateCache()
   -- Timer.Start('UpdateCache')

    InitCache()
    assisting = {}
    local buildRate = 0
    
    stats.build = InitBuildStats() 

    for id, unit in units.all do
        if not unit:IsDead() then

            UpdateUnitStats(unit)
            UpdateBuild(unit)
            table.insert(units.cached.all, unit)

            local focus = unit:GetFocus()
            if focus and not focus:IsDead() then
                UpdateUnitStats(focus)
                local focusId = focus:GetEntityId()
                if not units.all[focusId] then
                    units.all[focusId] = focus
                    
                    table.insert(units.cached.all, focus)
                end

                buildRate = unit:GetBuildRate() or 0
    
                --if EntityCategoryContains(categories.ENGINEER, unit) then
                if unit.isEngineer then
                    if not assisting[focusId] then
                        assisting[focusId] = {engineers = {}, build_rate = 0}
                    end

                    table.insert(assisting[focusId]['engineers'], unit)
                    assisting[focusId]['build_rate'] = assisting[focusId]['build_rate'] + buildRate
                end
            end
        end
    end
    
    units.cached.size = table.getsize(units.cached.all) 
    --PrintBuild()

    --LOG('units_stats UpdateCache ' .. cachedSize .. ' -> ' .. table.getsize(units.cached))
   --  LOG(' --- units stats '  .. table.getsize(units.all) ..' units ' .. Timer.Stop('UpdateCache')) 
   
end

local ticksUpdate = 10
local ticksForce = 50
local forceUpdate = true

local function CheckCache()
    local current_tick = GameTick()
    local army = GetFocusArmy()

    if army ~= current_army then
        last_cached = 0
        last_reset = 0
        current_army = army
        InitCache()
        forceUpdate = true
    end

    if army ~= -1 and current_tick - 10 >= last_cached then
        local score = ScoreBoard.GetData()
        local n = score[army].general.currentunits.count

        if forceUpdate then
           forceUpdate = false
           UpdateUnits()
           last_reset = current_tick

        elseif current_tick - 50 > last_reset and (not n or n > table.getsize(units.cached.all)) then
            UpdateUnits()
            last_reset = current_tick
        end

        UpdateCache()
        last_cached = current_tick
    end
end

function GetUnits(filter, update)
    -- default to always update unit cache
    if update == nil or update then
       CheckCache()
       units.cached.all = ValidateUnitsList(units.cached.all)
       units.cached.size = table.getsize(units.cached.all)
    end

    if filter then
        return EntityCategoryFilterDown(filter, units.cached.all) or {}
    else
        return units.cached.all
    end
end


function GetUnitStats()
    CheckCache()
    return stats
end

function Data(unit)
    local bp = unit:GetBlueprint()
    local data = {
        is_idle = unit:IsIdle(),
        econ = unit:GetEconData()
    }

    if bp.Economy.ProductionPerSecondMass > 0 and data['econ']['massProduced'] > bp.Economy.ProductionPerSecondMass then
        data['bonus'] = data['econ']['massProduced'] / bp.Economy.ProductionPerSecondMass
    else
        data['bonus'] = 1
    end

    if not data['is_idle'] then
        local focus = unit:GetFocus()
        data['assisters']  = 0
        data['build_rate'] = bp.Economy.BuildRate

        if focus then
            local focus_id = focus:GetEntityId();

            if assisting[focus_id] then
                data['assisting'] = table.getsize(assisting[focus_id]['engineers'])
                data['build_rate'] = data['build_rate'] + assisting[focus_id]['build_rate']
            end
        end
    end

    return data
end

 ------------------------------------------ 
--TODO remove old unit selector
--usage 
-- local GetAllUnits = import(modPath .. 'modules/UnitsTracker.lua').GetAllUnits
 
local oldSelection = nil
local isAutoSelection = false
local allUnits = {}
local lastFocusedArmy = 0

function GetUnitsCount(armyID)
    local score = ScoreBoard.GetData()
    if not score then return 0 end
    if table.getsize(score) == 0 then return 0 end
    if not score[armyID] then return 0 end
    return score[armyID].general.currentunits.count
end

function SelectBegin()
    oldSelection = GetSelectedUnits() or {}
    isAutoSelection = true
end
function SelectEnd()
    SelectUnits(oldSelection)
    isAutoSelection = false
end

function AddSelection()
    for _, unit in (GetSelectedUnits() or {}) do
        allUnits[unit:GetEntityId()] = unit
    end
end

function ResetSelection()
    local previousUnits = GetSelectedUnits() or {}
    isAutoSelection = true
    UISelectionByCategory("ALLUNITS", false, false, false, false)
    AddSelection()
    SelectUnits(previousUnits)
    isAutoSelection = false
end

local updatingSelection = false
function ForceSelection(oldUnitsCount)
    WaitSeconds(3) --1
    --local newTargetUnitCount = ScoreBoard.GetData()[GetFocusArmy()].general.currentunits.count
    local newUnitsCount = GetUnitsCount(GetFocusArmy())
    -- if after 10 seconds we are not loosing units and the unit count is still larger we have to do a reset
    if newUnitsCount >= oldUnitsCount and 
       newUnitsCount > table.getsize(allUnits) then
       -- print("SSB mod: New units detected, selecting units...")
        WaitSeconds(0.5) --0.5
        ResetSelection()
    end
    updatingSelection = false
end

function UpdateAllUnits()
    if GetFocusArmy() ~= lastFocusedArmy then
        ResetSelection()
        lastFocusedArmy = GetFocusArmy()
    end

    AddSelection() 
    -- add focused (building or assisting)
    for _, unit in allUnits do
        if not unit:IsDead() and unit:GetFocus() and not unit:GetFocus():IsDead() then
            allUnits[unit:GetFocus():GetEntityId()] = unit:GetFocus()
        end
    end    
    -- remove dead
    for entityid, unit in allUnits do
        if unit:IsDead() then
            allUnits[entityid] = nil
        end
    end    
    -- emergency reset
    --local targetNumOfUnits = ScoreBoard.GetData()[GetFocusArmy()].general.currentunits.count
    local newUnitsCount = GetUnitsCount(GetFocusArmy())
    if not updatingSelection and (newUnitsCount > table.getsize(allUnits)) then
        updatingSelection = true
        ForkThread(ForceSelection, newUnitsCount)
    end
end
function GetAllUnits()
    return allUnits
end

function IsAutoSelection()
    return isAutoSelection
end
