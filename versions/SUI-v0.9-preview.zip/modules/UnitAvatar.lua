-- ##########################################################################################
--  File:    /LUA/modules/UnitsAvatar.lua
--  Author:  HUSSAR
--  Summary:  
--  Copyright � 2017 HUSSAR - All rights reserved.
-- ##########################################################################################

local Utils     = import('/lua/system/utils.lua')
local UIUtil    = import('/lua/ui/uiutil.lua')

local GameCommon  = import('/lua/ui/game/gamecommon.lua')
local Tooltip     = import('/lua/ui/game/tooltip.lua')
local TooltipInfo = import('/lua/ui/help/tooltips.lua').Tooltips
local Popup       = import('/lua/ui/controls/popups/popup.lua').Popup

local Group     = import('/lua/maui/group.lua').Group
local Checkbox  = import('/lua/maui/checkbox.lua').Checkbox
local Bitmap    = import('/lua/maui/bitmap.lua').Bitmap
local Button    = import('/lua/maui/button.lua').Button
local Grid      = import('/lua/maui/grid.lua').Grid 
local Scrollbar = import('/lua/maui/scrollbar.lua').Scrollbar
local Control   = import('/lua/maui/control.lua').Control
local Window    = import('/lua/maui/window.lua').Window
local Border    = import('/lua/maui/border.lua').Border 
local Dragger   = import('/lua/maui/dragger.lua').Dragger 
--local StatusBar = import('/lua/maui/statusbar.lua').StatusBar
local EffectHelpers = import('/lua/maui/effecthelpers.lua')
local LayoutHelpers = import('/lua/maui/layouthelpers.lua')

--local AvatarsClickFunc = import('/lua/ui/game/avatars.lua').ClickFunc
 
local modPath = '/mods/SupremeScoreBoard/' 
local modScripts  = modPath..'modules/'
local modControls = modPath..'controls/'
local modTextures = modPath..'textures/'

local StatusBar = import(modControls .. 'StatusBar.lua').StatusBar
local TogglePulsing = import(modScripts .. 'effects.lua').TogglePulsing

function AvatarsClickFunc(self, event)
    if event.Type == 'MouseEnter' then
        if self.tooltipKey and not self.tooltip then
            self.tooltip = ToolTip.CreateExtendedToolTip(self, TooltipInfo[self.tooltipKey].title, TooltipInfo[self.tooltipKey].description)
            LayoutHelpers.LeftOf(self.tooltip, self)
            self.tooltip:SetAlpha(0, true)
            self.tooltip:SetNeedsFrameUpdate(true)
            self.tooltip.OnFrame = function(self, deltaTime)
                self:SetAlpha(math.min(self:GetAlpha() + (deltaTime * 3), 1), true)
                if self:GetAlpha() == 1 then
                    self:SetNeedsFrameUpdate(false)
                end
            end
        end
    elseif event.Type == 'MouseExit' then
        if self.tooltip then
            self.tooltip:Destroy()
            self.tooltip = nil
        end
        self.curIndex = 1
    elseif event.Type == 'ButtonPress' then

        --local units = self.units
        --if event.Modifiers.Alt then
        --    LOG('event.Modifiers.Alt ' ..  event.Type)
        --    units = self.unitsDamaged
        --end

        if self.units and self.unitsCount > 0 then
            if not self.units[self.curIndex] then
                self.curIndex = 1
            end
            -- check if selection should start from the 1st unit
            if table.getsize(GetSelectedUnits()) == 0 then
                self.curIndex = 1
            end
            local selection = { }

            if event.Modifiers.Ctrl then
                for id, unit in self.units do 
                    if  self.curIndex ~= id and unit:GetHealth() < 0.5 then
                        self.curIndex = id break
                    end
                end
                table.insert(selection, self.units[self.curIndex])

            elseif event.Modifiers.Shift then
                table.insert(selection, self.units[self.curIndex])
                for _, unit in GetSelectedUnits() or {} do
                    table.insert(selection, unit)
                end
            else 
                table.insert(selection, self.units[self.curIndex])
            end

            if event.Modifiers.Right and self.units[self.curIndex] then
                UISelectAndZoomTo(self.units[self.curIndex])
            end
            SelectUnits(selection) 
            self.curIndex = self.curIndex + 1
            return true
        end
    elseif event.Type == 'ButtonDClick' then
        if self.units and self.unitsCount > 0 then
            --if not self.units[self.curIndex] then
                self.curIndex = 1
            --end
            --if event.Modifiers.Left then
                local selection =  { } --self.units

                if event.Modifiers.Ctrl then
                    for _, unit in self.units do 
                        if unit:GetHealth() < 0.5 then
                            table.insert(selection, unit)
                        end
                    end   
                    --LOG('selection Ctrl ' .. table.getsize(selection) )
                elseif event.Modifiers.Shift then
                    selection = self.units
                    --selection = GetSelectedUnits() or {}
                    for _, unit in GetSelectedUnits() or {} do
                        table.insert(selection, unit)
                    end
                    --LOG('selection Shift ' .. table.getsize(selection) )
                else 
                    selection = self.units
                    --LOG('selection Else ' .. table.getsize(selection) )
                end
                --SelectUnits(selection)
            --else
            if event.Modifiers.Right then
                --local selection = self.units
                -- if event.Modifiers.Shift then
                --     --local selection = GetSelectedUnits() or {}
                --     for _, unit in GetSelectedUnits() or {} do
                --         table.insert(selection, unit)
                --     end
                --     UISelectAndZoomTo(self.units[self.curIndex])
                --     --SelectUnits(selection)
                -- else
                --     --SelectUnits(self.units)
                -- end
                if selection[1] then
                
                    UISelectAndZoomTo(selection[1])
                end
                    --UISelectAndZoomTo(self.units[self.curIndex])
                --SelectUnits(selection)
            end
            SelectUnits(selection)
            --self.curIndex = self.curIndex + 1
            return true
        end
    end
end

function CreateText(parent, txt, fontSize, fontName, bgColor)
    bgColor = bgColor or '6B000000'

    local txtUI = UIUtil.CreateText(parent, txt, fontSize, fontName, true)

    txtUI.bg = Bitmap(parent)
    txtUI.bg:SetSolidColor(bgColor) -- #6B000000
    txtUI.bg.Top:Set(function() return txtUI.Top() - 0 end)
    txtUI.bg.Left:Set(function() return txtUI.Left() - 1 end)
    txtUI.bg.Right:Set(function() return txtUI.Right() + 1 end)
    txtUI.bg.Bottom:Set(function() return txtUI.Bottom() + 0 end)
    txtUI.bg.Depth:Set(function() return parent.Depth() + 1 end)
    
    txtUI.Depth:Set(function() return txtUI.bg.Depth() + 1 end)
    
    txtUI.OrgSetAlpha = txtUI.SetAlpha
    txtUI.SetAlpha = function(self, value) 
        txtUI:OrgSetAlpha(value) 
        txtUI.bg:SetAlpha(value) 
    end

    txtUI.OrgDisableHitTest = txtUI.DisableHitTest
    txtUI.DisableHitTest = function(self) 
        txtUI:OrgDisableHitTest() 
        txtUI.bg:DisableHitTest() 
    end

    txtUI.OrgEnableHitTest = txtUI.EnableHitTest
    txtUI.EnableHitTest = function(self) 
        txtUI:OrgEnableHitTest() 
        txtUI.bg:EnableHitTest() 
    end
    return txtUI 
end
 
function UpdateBar(statusBar, value, solidFill)
    if not statusBar then return end
    if not value then value = .1 end
    if value == 0 then 
        statusBar:SetAlpha(0)
    elseif solidFill then
        statusBar:SetAlpha(1, true)
        statusBar:SetValue(value)
        statusBar._bar:SetSolidColor('FFD69F1E') -- #FFD69F1E
    else 
        local oldValue = statusBar._value()
        statusBar:SetValue(value)
        statusBar:SetAlpha(1, true) 

        if value ~= oldValue then
            local path = modTextures .. 'bars/'
            if statusBar._vertical then
                path = path .. 'vertical/'
            end
            if value > .75 then
                statusBar._bar:SetSolidColor('FF82B81D') -- #FF82B81D
                --statusBar._bar:SetTexture(path .. 'health-bar-green.dds')
                --statusBar._bar:SetTexture(UIUtil.SkinnableFile('/game/avatar/health-bar-green.dds'))
            elseif value > .5 then
                statusBar._bar:SetSolidColor('FFD69F1E') -- #FFD69F1E
            elseif value > .3 then
                statusBar._bar:SetSolidColor('FFD6641E') -- #FFD6641E
                --statusBar._bar:SetTexture(path .. 'health-bar-yellow.dds')
                --statusBar._bar:SetTexture(UIUtil.SkinnableFile('/game/avatar/health-bar-yellow.dds'))
            elseif value > 0 then
                statusBar._bar:SetSolidColor('FFCE1818') -- #FFCE1818
                --statusBar._bar:SetTexture(path .. 'health-bar-red.dds')
                --statusBar._bar:SetTexture(UIUtil.SkinnableFile('/game/avatar/health-bar-red.dds'))
            end
        end
    end
end
function GetHealthRatio(unit)
    if not unit then return 0 end
    local maxHealth = unit:GetMaxHealth()
    if not maxHealth or 
           maxHealth == 0 then 
           return 0 
    end 
    return unit:GetHealth() / maxHealth
end
function GetBackgroundImage(icon) 
    local validIcons = {land = true, air = true, sea = true, amph = true}
    if validIcons[icon] then
        return UIUtil.UIFile('/icons/units/'..icon..'_up.dds')
    else
        return UIUtil.UIFile('/icons/units/land_up.dds')
    end 
end

local StratIcons = import('/modules/straticons.lua')

function GetStratGeneric(unit)
    local types = import(modScripts .. 'UnitsTracker.lua').UnitTypes

    if unit and types[unit.Type] then
        local iconPath = '/textures/ui/icons_strategic/' .. types[unit.Type].Strat .. '.dds'
        if DiskGetFileInfo(iconPath) then
            return iconPath
        end
    end
    
    return '/textures/ui/icons_strategic/structure_generic.dds'
end
function GetStratSize(stratImage, maxWidth) 
 
    local stratWidth, stratHeight = GetTextureDimensions(stratImage)
    local stratRatio = stratHeight / stratWidth
            
    stratWidth  = math.min(stratWidth, maxWidth)
    stratHeight = stratRatio * stratWidth

   -- if string.find(stratImage, 'factory_' ) then
   --     --stratWidth  = math.max(stratWidth, stratHeight)
    --    stratHeight = stratWidth + 6 --math.max(stratWidth, stratHeight)
    --end

    return stratWidth, stratHeight
end
function GetStratImage(unit, overrideIcon) 
 
    if overrideIcon then
        local iconPath = '/textures/ui/icons_strategic/' .. overrideIcon .. '.dds'
        if DiskGetFileInfo(iconPath) then
            --LOG('GetStratImage' .. iconPath)
            return iconPath
        end 
    else
        local iconName = unit.bp.StrategicIconName
        iconName = StratIcons.aSpecificStratIcons[unit.id] or 
                   StratIcons.aStratIconTranslationFull[iconName]
        if iconName then
           iconName = '/textures/ui/icons_strategic/' .. iconName .. '.dds'
           if DiskGetFileInfo(iconName) then
                --LOG('GetStratImage' .. iconName)
                return iconName
           end
        end 
    end
    return GetStratGeneric(unit) 
end
function AnimationBitmap(parent)
    local bmp = Bitmap(parent)
    bmp.isAnimating = false
    bmp.Play = function(self)
        if self.isAnimating then return end
        self.isAnimating = true
        self:SetAlpha(1)
        self:Show()
        self:SetNeedsFrameUpdate(true)
        self.time = 0
        --self.OnFrame = function(control, time)
        --    control.time = control.time + (time * 4)
        --    control.a = MATH_Lerp( math.sin(control.time), -.5, .5, 0.3, 0.5)
        --    control.a = math.min(control.a, 0.4)
        --    control:SetAlpha(control.a)
        --end
        self.OnFrame = function(control, delta)
            --control.time = control.time + math.pi * 0.05
            --control.delta = math.sin(control.time)
                control.time = control.time + math.pi * 0.05
                control:SetAlpha(MATH_Lerp( math.sin(control.time), -1.0, 1.0, 0.0, 0.5))
            --control.time = control.time + 1
            --if math.mod(control.time, 10) == 0 then
            --    control:SetAlpha(.3)
            --else
            --    control:SetAlpha(1)
            --end
        end
    end         
    bmp.Stop = function(self)
        self.isAnimating = false
        self:SetAlpha(1)
        self:SetNeedsFrameUpdate(false)
    end
    return bmp
end



local borderSize = 2

local Factions = { 
    AEON     = { Color = 'FF2FF10D' },  -- #FF2FF10D 
    UEF      = { Color = 'FF0DA8F1' },  -- #FF0DA8F1 
    SERAPHIM = { Color = 'FFF7CF0D' },  -- #FFF7CF0D 
    CYBRAN   = { Color = 'FFF10D0D' },  -- #FFF10D0D 
    OTHER    = { Color = 'FF8D8D8D' },  -- #FF8D8D8D 
}
 
function CreateUI(parent, options)
    local img = UIUtil.SkinnableFile('/game/avatar-factory-panel/avatar-s-e-f_bmp.dds')
    local barSize = options.unitHealthBarSize --8 --8
    local height = options.unitSize --or 46
    local width  = options.unitSize + 10 --or 58  
    local idleSize = options.unitSize * (options.unitIdlesIconRatio or 0.2)

    if not options.showUnitAvgHealthBar then
        barSize = 2
    end
    local avatar = Bitmap(parent, img)
    avatar.options = options 
    avatar.parent = parent
    avatar.info = {}
    avatar.units = {}
    avatar.unitsNew = {}
    avatar.unitsCount = 0
    avatar.isActive = false
    avatar.isReady = false
    avatar.stratWidth  = height * (options.unitStratIconRatio or 0.4) 
    avatar.stratHeight = height * (options.unitStratIconRatio or 0.4) 
    avatar.Depth:Set(function() return parent.Depth() + 1 end)
    
    avatar.Height:Set(height)
    avatar.Width:Set(width)
    avatar:SetAlpha(1)     
    --avatar:SetSolidColor('FF212020') --#FF212020
    
    avatar.terrains = Bitmap(avatar) 
    avatar.terrains.Height:Set(height-borderSize)
    avatar.terrains.Width:Set(width-borderSize)
    avatar.terrains:DisableHitTest()
    LayoutHelpers.AtLeftTopIn(avatar.terrains, avatar, 1, 1)

    avatar.inactive = Bitmap(avatar) --AnimationBitmap(avatar)
    avatar.inactive.Height:Set(height-borderSize)
    avatar.inactive.Width:Set(width-borderSize)
    avatar.inactive:SetSolidColor('FF0E0D0D') --#FF0E0D0D
    avatar.inactive:SetAlpha(0)
    avatar.inactive:DisableHitTest()
    avatar.inactive.TogglePulsing = TogglePulsing
    LayoutHelpers.AtLeftTopIn(avatar.inactive, avatar, 1, 1)
    --avatar.terrains.Depth:Set(1)


    --avatar.marker = Bitmap(avatar)
    --avatar.marker:SetTexture(UIUtil.UIFile('/game/avatar/pulse-bars_bmp.dds'))
    --avatar.marker.Height:Set(height+6)
    --avatar.marker.Width:Set(width+6)
    --avatar.marker:Hide()
    --LayoutHelpers.AtLeftTopIn(avatar.marker, avatar, -3, -3)
    ----avatar.marker.Depth:Set(100)
    --avatar.marker:Hide()
    --avatar.marker:DisableHitTest()

    avatar.unitIcon = Bitmap(avatar)
    avatar.unitIcon.Height:Set(height-barSize-2)
    avatar.unitIcon.Width:Set(height-barSize)
    avatar.unitIcon:DisableHitTest() 
    LayoutHelpers.AtLeftTopIn(avatar.unitIcon, avatar, 8, 2)
    
    avatar.hover = Bitmap(avatar)
    avatar.hover.Height:Set(height-borderSize)
    avatar.hover.Width:Set(width-borderSize)
    avatar.hover:SetSolidColor('0A8A8A8A') --#0A8A8A8A
    avatar.hover:SetAlpha(1)
    avatar.hover:DisableHitTest()
    LayoutHelpers.AtLeftTopIn(avatar.hover, avatar, 1, 1)

    avatar.progress = StatusBar(avatar, 0, 1, true, false, nil, nil, true, false) 
    avatar.progress.Width:Set(options.unitProgressBarSize)
    avatar.progress.Height:Set(height-barSize-6)
    avatar.progress:SetAlpha(1) 
    LayoutHelpers.AtLeftIn(avatar.progress, avatar, 2)
    LayoutHelpers.AtBottomIn(avatar.progress, avatar, barSize+2)

    avatar.healthAvgBar = StatusBar(avatar, 0, 1, false, false, nil, nil, true, true) 
    avatar.healthAvgBar.Width:Set(width-4)
    avatar.healthAvgBar.Height:Set(barSize)
    avatar.healthAvgBar:SetAlpha(0)
    avatar.healthAvgBar:DisableHitTest()
    LayoutHelpers.AtLeftIn(avatar.healthAvgBar, avatar, 2)
    LayoutHelpers.AtBottomIn(avatar.healthAvgBar, avatar, 0) 

    avatar.healthMinBar = StatusBar(avatar, 0, 1, false, false, nil, nil, true, true) 
    avatar.healthMinBar.Width:Set(width-4)
    avatar.healthMinBar.Height:Set(barSize)
    avatar.healthMinBar:SetAlpha(0)
    avatar.healthMinBar:DisableHitTest()
    LayoutHelpers.AtLeftIn(avatar.healthMinBar, avatar, 2)  
    LayoutHelpers.AtBottomIn(avatar.healthMinBar, avatar, 0) 

    avatar.count = CreateText(avatar, '', options.counterFontSize, options.counterFontName, '6B000000')
    avatar.count:SetColor('ffffffff') --#ffffffff
    avatar.count:DisableHitTest()
    LayoutHelpers.AtRightIn(avatar.count, avatar, 3) 
    LayoutHelpers.AtBottomIn(avatar.count, avatar, barSize + 1)
    
    avatar.overlay = Bitmap(avatar)  
    avatar.overlay.Height:Set(height)
    avatar.overlay.Width:Set(width)
    avatar.overlay:SetSolidColor('1B646464') --#1B646464 
    avatar.overlay:EnableHitTest()     
    avatar.overlay.Depth:Set(function() return avatar.Depth() + 1 end)
    LayoutHelpers.AtLeftTopIn(avatar.overlay, avatar, 0, 0)

    avatar.stratIcon = Bitmap(avatar)
    avatar.stratIcon:SetTexture('/textures/ui/common/game/strategicicons/icon_structure_generic_rest.dds')
    avatar.stratIcon.Height:Set(20)
    avatar.stratIcon.Width:Set(20)  
    avatar.stratIcon:DisableHitTest()
    --avatar.stratIcon:EnableHitTest()
    LayoutHelpers.AtLeftIn(avatar.stratIcon, avatar, options.unitProgressBarSize+2)  
    LayoutHelpers.AtTopIn(avatar.stratIcon, avatar, 0)

    avatar.missiles = CreateText(avatar.overlay, '?', options.missilesFontSize, options.missilesFontName, '6B000000')
    avatar.missiles:SetColor('FFFF7505') --#FFFF7505   
    avatar.missiles:SetAlpha(1)  
    avatar.missiles:EnableHitTest()
    avatar.missiles.TogglePulsing = TogglePulsing
    --avatar.missiles.Depth:Set(function() return avatar.overlay.Depth() + 1 end)
    LayoutHelpers.AtRightIn(avatar.missiles, avatar.overlay, 3) 
    LayoutHelpers.AtTopIn(avatar.missiles, avatar.overlay, 5)
    
    avatar.damaged = Bitmap(avatar.overlay)
    avatar.damaged.Width:Set(width-4)
    avatar.damaged.Height:Set(barSize+4)
    avatar.damaged:SetAlpha(1)
    avatar.damaged:SetSolidColor('2AAE29E1') --#2AAE29E1 
    avatar.damaged:EnableHitTest()
    --avatar.damaged.Depth:Set(function() return avatar.Depth() + 2 end)
    LayoutHelpers.AtLeftIn(avatar.damaged, avatar.overlay, 2)
    LayoutHelpers.AtBottomIn(avatar.damaged, avatar.overlay, 0) 

    avatar.idleIcon = Bitmap(avatar.overlay)
    avatar.idleIcon.Height:Set(idleSize)
    avatar.idleIcon.Width:Set(idleSize) 
    avatar.idleIcon:SetAlpha(0)
    avatar.idleIcon:SetTexture('/textures/ui/common/game/idle_mini_icon/idle_icon.dds') 
    avatar.idleIcon:EnableHitTest()
    avatar.idleIcon.TogglePulsing = TogglePulsing
    --avatar.idleIcon.Depth:Set(function() return avatar.overlay.Depth() + 1 end)
    LayoutHelpers.AtLeftIn(avatar.idleIcon, avatar.overlay, options.unitProgressBarSize)  
    LayoutHelpers.AtBottomIn(avatar.idleIcon, avatar.overlay, barSize-6)
     
    --avatar.damageIcon = Bitmap(avatar.overlay)
    --avatar.damageIcon.Height:Set(idleSize)
    --avatar.damageIcon.Width:Set(idleSize) 
    --avatar.damageIcon:SetAlpha(1)
    ----avatar.damageIcon:SetTexture(modTextures..'symbols/dead_avatars.dds') 
    --avatar.damageIcon:SetTexture(modTextures..'faction_cybran.dds') 
    --avatar.damageIcon:EnableHitTest()
    ----LayoutHelpers.AtLeftTopIn(avatar.idleIcon, avatar, height-25, 0)
    --LayoutHelpers.AtLeftIn(avatar.damageIcon, avatar.overlay, 1)  
    --LayoutHelpers.AtBottomIn(avatar.damageIcon, avatar.overlay, barSize+1)
    --
    --avatar.damageColor = Bitmap(avatar.damageIcon)
    --avatar.damageColor:SetSolidColor('ffff2600') --#ffff2600'
    --avatar.damageColor.Depth:Set(function() return avatar.damageIcon.Depth() - 1 end)
    --avatar.damageColor:DisableHitTest()
    --LayoutHelpers.FillParent(avatar.damageColor, avatar.damageIcon)

    --avatar.IsFiltered = function(self) return self.unitsCount == 0 end
    avatar.isFiltered = false

    avatar.Filter = function(self, status) 
        avatar.isFiltered = status
        if avatar.isFiltered then
           -- LOG('avatar.Filter on ')
           --avatar.hover:SetSolidColor('98DE1C1C') --#98DE1C1C
        else
            --avatar.hover:SetSolidColor('008A8A8A') --#008A8A8A
            --LOG('avatar.Filter off ')
        end
    end

    avatar.SetHightlight = function(self, toggle) 
        if toggle then
            --LOG('avatar.SetHightlight on ')
            avatar.hover:SetSolidColor('6DC8C8C8') --#6DC8C8C8
        else
            --LOG('avatar.SetHightlight off')
            avatar.hover:SetSolidColor('008A8A8A') --#008A8A8A
        end
    end
   
    avatar.HandleEvent = function(self, event)
        if event.Type == 'WheelRotation' then 
            avatar.parent:OnMouseWheel(event.WheelRotation)
            return true
        elseif event.Type == 'MouseEnter'  then
            --LOG('avatar.HandleEvent ' .. event.Type)
            avatar:SetHightlight(true)
        elseif event.Type == 'MouseExit' then
            --LOG('avatar.HandleEvent ' .. event.Type)
            avatar:SetHightlight(false)
        end
        return true
    end
    
    avatar.overlay.HandleEvent = function(self, event)
        if event.Type == 'MouseEnter' or 
           event.Type == 'MouseExit' then 
            --LOG('avatar.HandleEvent overlay ' .. event.Type)
            return avatar:HandleEvent(event)
        elseif event.Type == 'ButtonPress'  or 
               event.Type == 'ButtonDClick' then
            AvatarsClickFunc(avatar, event) 
            return true
        end
        return false
    end

    avatar.damaged.HandleEvent = function(self, event)
        if event.Type == 'MouseEnter' or 
           event.Type == 'MouseExit' then 
             --LOG('HandleEvent damaged ' .. event.Type)
            return avatar:HandleEvent(event)
        elseif event.Type == 'ButtonPress'  or 
               event.Type == 'ButtonDClick' then 
            AvatarsClickFunc(avatar.damaged, event)
            return true
        end
        return false
    end

    avatar.idleIcon.HandleEvent = function(self, event)
        if event.Type == 'MouseEnter' or 
           event.Type == 'MouseExit' then 
        --LOG('avatar.HandleEvent idleIcon ' .. event.Type)
            return avatar:HandleEvent(event) 
        elseif event.Type == 'ButtonPress'  or 
               event.Type == 'ButtonDClick' then 
            AvatarsClickFunc(avatar.idleIcon, event)
            return true 
        end
        return false
    end

    avatar.missiles.HandleEvent = function(self, event)
        if event.Type == 'MouseEnter' or 
           event.Type == 'MouseExit' then
            return avatar:HandleEvent(event)
        elseif event.Type == 'ButtonPress'  or 
               event.Type == 'ButtonDClick' then 
            AvatarsClickFunc(avatar.missiles, event)
            return true
        end
        return false
    end 

    avatar.Initialize = function(self, unit, uid, bgIcon, startIcon) 
        avatar.isReady = true
        --local unit = units[1]
        avatar.bp = unit.bp or unit:GetBlueprint()
        avatar.CategoriesHash = unit.bp.CategoriesHash or table.hash(unit.bp.Categories)
        --avatar.uid = unit.id
        avatar.uid = uid
        avatar.isMissleSilo = unit.isMissleSilo
        avatar.isCommander = unit.isCommander
        avatar.isFactory = unit.isFactory
        avatar.isEngineer = unit.isEngineer
        avatar.canEngineer = unit.canEngineer
        avatar.Name = unit.Name
        avatar.Tech = unit.Tech
        avatar.Type = unit.Type 
        avatar.isPreset = unit.isPreset  
        avatar.Faction = unit.Faction  
        avatar.unitsNew = {}
              
   -- LOG('avatar Initialize '  ..  unit.Name  .. ' ' .. table.getsize(avatar.CategoriesHash) .. ' '  ..  table.concatkeys(avatar.CategoriesHash) )
        
        local tooltipBody = 'right click - zoom to the unit\n' ..
                            'double click - select all units\n' .. 
                            'single click - toggle between units starting from a unit with lowest health\n'
        --tooltipBody = avatar.group .. '\n\n'.. table.concatkeys(avatar.CategoriesHash, '\n')
        
        local tooltip = {text = unit.Name .. ' ' ..uid, body = tooltipBody }
        Tooltip.AddControlTooltip(avatar.overlay, tooltip)
        
        tooltip = {text = unit.Name, body = 'Select units with missiles: TMLs or NUKEs' }
        Tooltip.AddControlTooltip(avatar.missiles, tooltip)
        
        tooltip = {text = unit.Name, body = 'Select units that are idle' }
        Tooltip.AddControlTooltip(avatar.idleIcon, tooltip)
        
        tooltip = {text = unit.Name, body = 'Select units that have at least 50% damage' }
        Tooltip.AddControlTooltip(avatar.damaged, tooltip)
       
        --avatar:Setup(bp.General.Icon, unit.id, unit.bp.StrategicIconName) 
        if avatar.isMissleSilo then
            --LOG('avatar Initialize isMissleSilo ' .. avatar.Name) 
           avatar.missiles:EnableHitTest()
           avatar.missiles:SetAlpha(1) 
        else  
           avatar.missiles:DisableHitTest()
           avatar.missiles:SetAlpha(0) 
        end

        if avatar.canEngineer then
           -- LOG('avatar Initialize canEngineer ' .. avatar.Name) 
           avatar.idleIcon:EnableHitTest()
           avatar.idleIcon:SetAlpha(1) 
        else  
           avatar.idleIcon:DisableHitTest()
           avatar.idleIcon:SetAlpha(0) 
        end

        if avatar.options.showUnitBackground then
            local bgImage = GetBackgroundImage(bgIcon or avatar.bp.General.Icon)  
            avatar.terrains:SetTexture(bgImage) 
        end

        if avatar.options.showUnitStrat then
        
            local stratImage = GetStratImage(unit, startIcon) 
            if stratImage then 

                local stratWidth, stratHeight = GetStratSize(stratImage, avatar.stratWidth) 

                --local stratWidth, stratHeight = GetTextureDimensions(stratImage)
                --local stratRatio = stratHeight / stratWidth
                --
                --stratWidth  = math.min(stratWidth, avatar.stratWidth)
                --stratHeight = stratRatio * stratWidth

                --avatar.stratWidth  = math.max(stratWidth, 25)
                --avatar.stratHeight = math.max(stratHeight, 25)
      
                --avatar.stratIcon.Height:Set(stratHeight * 0.75)
                --avatar.stratIcon.Width:Set(stratWidth * 0.75)

                avatar.stratIcon.Height:Set(stratHeight)
                avatar.stratIcon.Width:Set(stratWidth)
                avatar.stratIcon:SetTexture(stratImage)

                -- special adjustment for commanders because they have too big strategic icon
                if avatar.isCommander then
                    avatar.stratIcon.Height:Set(stratHeight * 0.8)
                    avatar.stratIcon.Width:Set(stratWidth * 0.8)
                    LayoutHelpers.AtTopIn(avatar.stratIcon, avatar, 2)
                end
            else
               -- avatar.stratIcon:SetSolidColor('00000000')-- #00000000
                avatar.stratIcon:SetSolidColor('EEE42020') -- #EEE42020
            end
        end 


        if not avatar.options.showUnitIcon then
            LayoutHelpers.AtHorizontalCenterIn(avatar.stratIcon, avatar)
        else
            -- if Factions[unit.Faction] then
            --     avatar:SetSolidColor(Factions[unit.Faction].Color)  
            -- else
            --     avatar:SetSolidColor('EEE420DC')  --#EEE420DC
            --     --avatar:SetSolidColor(Factions['OTHER'].Color)
            -- end

            -- set the icon that corresponds to the unit
            local unitIcons = { GameCommon.GetCachedUnitIconFileNames(avatar.bp) }
            avatar.unitIcon:SetTexture(unitIcons[1])

            if unit.isPreset then
                --avatar.unitIcon.Height:Set(height-2)
                --avatar.unitIcon.Width:Set(width-2)
                --LayoutHelpers.AtLeftTopIn(avatar.unitIcon, avatar, 1, 1)
                avatar.terrains:SetAlpha(0) 
                --avatar.terrains:SetSolidColor('FF080808') --#FF080808
    --LayoutHelpers.AtLeftIn(avatar.unitIcon, avatar, 10)  
    --LayoutHelpers.AtTopIn(avatar.unitIcon, avatar, 0)
                
                avatar.unitIcon.Height:Set(height+4)
                avatar.unitIcon.Width:Set(width+8)
                LayoutHelpers.AtLeftTopIn(avatar.unitIcon, avatar, -4, -2)
            end 
        end

    end

    avatar.SetActivation = function(self, isActive)
        avatar.isActive = isActive
        
        if avatar.isActive then
            avatar.inactive:SetAlpha(0)

            --avatar.missiles:SetAlpha(1)
            --avatar.missiles.bg:SetAlpha(1)
            --avatar.count.bg:SetAlpha(1)
            avatar.count:SetAlpha(1)

            avatar.terrains:SetAlpha(1)
            avatar.unitIcon:SetAlpha(1)
            avatar.stratIcon:SetAlpha(1)
            
            if avatar.options.showUnitAvgHealthBar then
                avatar.healthAvgBar:SetAlpha(1, true)
            end

        else 
            avatar.idleIcon:TogglePulsing(false) 

            avatar.inactive:TogglePulsing(false) 
            avatar.inactive:SetSolidColor('FF0E0D0D') --#FF0E0D0D
            avatar.inactive:SetAlpha(1)
            
            avatar.missiles:SetAlpha(0)
            avatar.count:SetAlpha(0)
        
            avatar.terrains:SetAlpha(0)
            avatar.unitIcon:SetAlpha(.6)
            avatar.stratIcon:SetAlpha(.6)
          
            avatar.healthMinBar:SetAlpha(0, true)
            avatar.healthAvgBar:SetAlpha(0, true)
            avatar.progress:SetAlpha(0, true)

            --LOG('avatar inactive '  ..  avatar.Name  .. ' ' .. avatar.uid )
        end 
    end
    
    avatar.UpdateStatusBars = function(self, healthMin, healthAvg, maxProgress)

        if avatar.options.showUnitAvgHealthBar then
            UpdateBar(avatar.healthAvgBar, healthAvg)
        end
        if avatar.options.showUnitMinHealthBar then
            if avatar.unitsCount == 1 or healthMin >= healthAvg then 
                avatar.healthMinBar:SetAlpha(0, true)
            else 
                avatar.healthMinBar:SetAlpha(.5, true)
                UpdateBar(avatar.healthMinBar, healthMin)
            end  
            
        end
         
        if maxProgress > 0 and maxProgress < 1 then
            UpdateBar(avatar.progress, maxProgress, true)
        else
            avatar.progress:SetAlpha(0, true)
        end
    end
       
    avatar.UpdateHash = function(self)
        local units = {}
        for eid, unit in avatar.hash do  
            if unit then
               table.insert(units, unit)
            end
        end

        units = import(modScripts..'UnitsSorter.lua').SortUnitsByStatus(units)
        avatar:Update(units)
    end

    avatar.UpdateMissiles = function(self)
        if not avatar.isMissleSilo or not avatar.options.showUnitMissiles then 
            return 
        end
        
        local missilesCount = 0
        for _, unit in avatar.units do 

            if unit.isMissleSilo and unit.missiles > 0 then
                missilesCount = missilesCount + unit.missiles
                table.insert(avatar.missiles.units, unit) 
            end 
        end

        if missilesCount > 0 then
            --avatar.missiles:SetAlpha(1)
            avatar.missiles:SetText(missilesCount) 
            avatar.missiles.unitsCount = table.getsize(avatar.missiles.units)

            if avatar.missiles.count < missilesCount then
               avatar.missiles.count = missilesCount
               --if not avatar.missiles.isPulsing then 
                    avatar.missiles:TogglePulsing(true, true) 
               -- end
            end
            --if avatar.isIdle then
            --    avatar.missiles:SetColor('FFFF7505') -- '#FFFF7505
            --else
                avatar.missiles:SetColor('FF0DEF25') -- '#FF0DEF25
            --end

        elseif avatar.isMissleSilo and missilesCount == 0 then 
            avatar.missiles:TogglePulsing(false) 
            avatar.missiles:SetAlpha(1)
            avatar.missiles.count = 0
            avatar.missiles.unitsCount = 0
            avatar.missiles:SetText(missilesCount) 
         
            --if avatar.isIdle then
            --    avatar.missiles:SetColor('FFFF3505') -- '#FFFF3505
            --else
                avatar.missiles:SetColor('FFFF7505') -- '#FFFF7505
            --end
        end
    end

    avatar.UpdateHealth = function(self, units)
        if not avatar.options.showUnitMinHealthBar and 
           not avatar.options.showUnitAvgHealthBar then 
            avatar.healthMinBar:SetAlpha(0, true)
            avatar.healthAvgBar:SetAlpha(0, true)
            return 
        end
        
        local healthRatio = 0 
        local healthMin = 1 
        local healthAvg = 0
        
        
        for _, unit in avatar.units do 
            healthRatio = GetHealthRatio(unit)
            healthMin = math.min(healthRatio, healthMin)  
            healthAvg = healthAvg + healthRatio

            if healthRatio < 0.75 then
                table.insert(avatar.damaged.units, unit) 
            end 
            
            if unit.isAttacked then
               avatar.isAttacked = true 
            end 
        end
        
        healthAvg = healthAvg / avatar.unitsCount
        avatar.damaged.unitsCount = table.getsize(avatar.damaged.units) 

        if avatar.options.showUnitAvgHealthBar then
            UpdateBar(avatar.healthAvgBar, healthAvg)
        end
        if avatar.options.showUnitMinHealthBar then
            if avatar.unitsCount == 1 or healthMin >= healthAvg then 
                avatar.healthMinBar:SetAlpha(0, true)
            else 
                avatar.healthMinBar:SetAlpha(.5, true)
                UpdateBar(avatar.healthMinBar, healthMin)
            end
        end

        if avatar.isAttacked then 
           avatar.inactive:SetSolidColor('C7EC3535') --#C7EC3535
           avatar.inactive:TogglePulsing(true, false, true) 
        else
           avatar.inactive:SetSolidColor('FF0E0D0D') --#FF0E0D0D
           avatar.inactive:TogglePulsing(false) 
        end
    end

    avatar.UpdateIdle = function(self)
        if not avatar.canEngineer then 
            avatar.progress:SetAlpha(0, true)
            avatar.idleIcon:SetAlpha(0, true)
            return 
        end
         
        local idleCount = 0
        local maxProgress = nil

        for _, unit in avatar.units do 
            if unit.canEngineer then 
                if not unit.isEngineering then 
                    table.insert(avatar.idleIcon.units, unit) 
                else 
                    if maxProgress < unit:GetWorkProgress() then
                       maxProgress = unit:GetWorkProgress()
                    end
                end
            end 
        end

        if not avatar.options.showUnitIdle then 
            avatar.idleIcon:SetAlpha(0, true) 
        else 
            avatar.idleIcon.unitsCount = table.getsize(avatar.idleIcon.units)
            avatar.isIdle = avatar.idleIcon.unitsCount > 0
            if avatar.isIdle then
                --LOG('unitsIdle ' .. avatar.Name ..  ' ' .. tostring(unitsIdle) ..' ' ..  tostring(GetIsPaused(avatar.units)))
                --maxProgress = nil -- this will hide progress bar
                if not avatar.idleIcon.isEnabled then 
                    avatar.idleIcon:TogglePulsing(true, false)
                end
            else
                --if avatar.idleIcon.isEnabled then 
                    avatar.idleIcon:TogglePulsing(false)
                --end
            end
        end

        if not avatar.options.showUnitProgressBar then 
            avatar.progress:SetAlpha(0, true) 
        else 
            if maxProgress > 0 and maxProgress < 1 then
                UpdateBar(avatar.progress, maxProgress, true)
            else
                avatar.progress:SetAlpha(0, true)
            end
        end
    end

    avatar.Update = function(self, units)
         
        local newCount = table.getsize(units)
        avatar.unitsChanged = newCount ~= avatar.unitsCount 
        avatar.unitsCount = newCount 
        avatar.units = units
        avatar.unitsNew = {}
        avatar.damaged.units = {}
        avatar.missiles.units = {}
        avatar.idleIcon.units = {}
        avatar.isAttacked = false 

        --avatar.count:SetText(avatar.unitsCount) 

        if avatar.isFiltered then
            return
        end

        if newCount == 0 then

             
            avatar:SetActivation(false)
            --if not avatar.isChanged then
            --    return -- skip updating
            --end
        else 
        
            if not avatar.isActive then
                avatar:SetActivation(true)
            end
            
            avatar.count:SetText(avatar.unitsCount) 
            
        --    local healthRatio = 0 
        --    local healthMin = 1 
        --    local healthAvg = 0
        --    local missilesCount = 0
        --
        --    local idleCount = 0
        --    local maxProgress = nil
            --avatar.isAttacked = false 
            --avatar.missiles.units = {}
            --avatar.idleIcon.units = {}

        --    for _, unit in avatar.units do 
        --        --healthRatio = GetHealthRatio(unit)
        --        --healthMin = math.min(healthRatio, healthMin)  
        --        --healthAvg = healthAvg + healthRatio
        --        --
        --        --if healthRatio < 0.75 then
        --        --    table.insert(avatar.damaged.units, unit) 
        --        --end 
        --
        --        --if unit.isAttacked then
        --        --   avatar.isAttacked = true 
        --        --end 
        --
        --        --if unit.isMissleSilo and unit.missiles > 0 then
        --        --    missilesCount = missilesCount + unit.missiles
        --        --    table.insert(avatar.missiles.units, unit) 
        --        --end 
        --
        --        --if unit.canEngineer then 
        --        --    if not unit.isEngineering then 
        --        --        table.insert(avatar.idleIcon.units, unit) 
        --        --    else 
        --        --        if maxProgress < unit:GetWorkProgress() then
        --        --           maxProgress = unit:GetWorkProgress()
        --        --        end
        --        --    end
        --        --end 
        --    end

            --avatar.damaged.unitsCount = table.getsize(avatar.damaged.units) 
        --    avatar.idleIcon.unitsCount = table.getsize(avatar.idleIcon.units)
        --
        --    avatar.isIdle = avatar.idleIcon.unitsCount > 0
        --
        --    if avatar.isIdle then
        --        --LOG('unitsIdle ' .. avatar.Name ..  ' ' .. tostring(unitsIdle) ..' ' ..  tostring(GetIsPaused(avatar.units)))
        --        --maxProgress = nil -- this will hide progress bar
        --        if not avatar.idleIcon.isEnabled then 
        --            avatar.idleIcon:TogglePulsing(true, false)
        --        end
        --    else
        --        --if avatar.idleIcon.isEnabled then 
        --            avatar.idleIcon:TogglePulsing(false)
        --        --end
        --    end

            avatar:UpdateMissiles()
            avatar:UpdateHealth()  
            avatar.UpdateIdle()

          --  if avatar.options.showUnitMissiles then
          --      if missilesCount > 0 then
          --          --avatar.missiles:SetAlpha(1)
          --          avatar.missiles:SetText(missilesCount) 
          --          avatar.missiles.unitsCount = table.getsize(avatar.missiles.units)
          --
          --          if avatar.missiles.count < missilesCount then
          --             avatar.missiles.count = missilesCount
          --             --if not avatar.missiles.isPulsing then 
          --                  avatar.missiles:TogglePulsing(true, true) 
          --             -- end
          --          end
          --          --if avatar.isIdle then
          --          --    avatar.missiles:SetColor('FFFF7505') -- '#FFFF7505
          --          --else
          --              avatar.missiles:SetColor('FF0DEF25') -- '#FF0DEF25
          --          --end
          --
          --      elseif avatar.isMissleSilo and missilesCount == 0 then 
          --          avatar.missiles:TogglePulsing(false) 
          --          avatar.missiles:SetAlpha(1)
          --          avatar.missiles.count = 0
          --          avatar.missiles.unitsCount = 0
          --          avatar.missiles:SetText(missilesCount) 
          --       
          --          --if avatar.isIdle then
          --          --    avatar.missiles:SetColor('FFFF3505') -- '#FFFF3505
          --          --else
          --              avatar.missiles:SetColor('FFFF7505') -- '#FFFF7505
          --          --end
          --      end
          --  end 

         --   if avatar.isAttacked then 
         --       avatar.inactive:SetSolidColor('C7EC3535') --#C7EC3535
         --       
         --       avatar.inactive:TogglePulsing(true, false, true) 
         --   else
         --       avatar.inactive:SetSolidColor('FF0E0D0D') --#FF0E0D0D
         --       avatar.inactive:TogglePulsing(false) 
         --   end

            --healthAvg = healthAvg / avatar.unitsCount
              
            --avatar:UpdateStatusBars(healthMin, healthAvg, maxProgress)
             
        end
    end

    return avatar
end
