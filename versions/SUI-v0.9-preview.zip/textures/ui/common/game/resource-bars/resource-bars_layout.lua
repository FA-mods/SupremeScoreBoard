layout = {
	['mini-energy-bar_bmp'] = {left = 0, top = 0, width = 160, height = 15, },
	['mini-energy-bar-back_bmp'] = {left = 0, top = 0, width = 160, height = 16, },
	['mini-mass-bar_bmp'] = {left = 0, top = 0, width = 160, height = 15, },
	['mini-mass-bar-back_bmp'] = {left = 0, top = 0, width = 160, height = 16, },
}
