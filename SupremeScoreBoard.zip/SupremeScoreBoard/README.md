# SupremeScoreBoard (UI) mod (v1.2)

This repository contains implementation of a User Interface mod for Supreme Commander FA game. This mod can be used with FAF client (http://www.faforever.com)

#Features:
http://forums.faforever.com/viewtopic.php?f=41&t=10887

#Installation
Download content of this repository to your "Mods" folder for Supreme Commander FA game, e.g.
C:\Users\USER_NAME\Documents\My Games\Gas Powered Games\Supreme Commander Forged Alliance\Mods\

or

Download from the vault in FAF client 
